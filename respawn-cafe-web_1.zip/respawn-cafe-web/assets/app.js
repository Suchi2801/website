/* ============================================================
   CUSTOMER APP — home · booking wizard · menu & cart · my bookings
   Hash router, no framework, no build step.
   ============================================================ */
(function () {
  "use strict";
  const E = Engine, $ = (s, r = document) => r.querySelector(s), $$ = (s, r = document) => [...r.querySelectorAll(s)];
  let db = Store.load(CONFIG);

  const state = {
    view: "home",
    stationTypeId: null, dateStr: E.dateKey(new Date()), pickedSlots: [], stationCount: 1,
    addonIds: [], coupon: "", step: 1, hold: null, holdTimer: null,
    cart: {}, cartCoupon: "", orderType: "DINE_IN", tableId: null,
    dietFilter: "ALL", menuCat: "ALL",
    loginMode: "phone", loginStep: 1, loginId: "", loginDemoCode: "", loginName: "",
    redeem: 0, cartRedeem: 0, afterLogin: null,
  };
  const save = () => Store.save(db);

  // current signed-in customer, or null
  const me = () => (db.session?.userId ? db.customers.find((c) => c.id === db.session.userId) : null);
  const member = () => (me() ? Store.memberInfo(db, me().id) : null);

  // ---------- helpers ----------
  const toast = (msg, kind = "") => {
    const t = document.createElement("div");
    t.className = "toast " + kind; t.textContent = msg;
    t.setAttribute("role", "status");
    $("#toasts").appendChild(t);
    setTimeout(() => { t.style.opacity = "0"; setTimeout(() => t.remove(), 300); }, 3400);
  };
  const esc = (s) => String(s ?? "").replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
  const dayName = (d) => ["SUN", "MON", "TUE", "WED", "THU", "FRI", "SAT"][d.getDay()];
  const monName = (d) => ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"][d.getMonth()];
  const nice = (iso) => { const d = E.parseLocal(iso); return `${d.getDate()} ${monName(d)}, ${E.hhmm(iso)}`; };
  const st = (id) => db.settings.stationTypes.find((t) => t.id === id);

  function modal(title, bodyHtml, opts = {}) {
    const m = document.createElement("div");
    m.className = "mask";
    m.innerHTML = `<div class="modal" role="dialog" aria-modal="true" aria-label="${esc(title)}">
      <div class="mh"><h3>${esc(title)}</h3><button class="x" aria-label="Close">&times;</button></div>
      <div class="mb">${bodyHtml}</div></div>`;
    m.addEventListener("click", (e) => { if (e.target === m || e.target.classList.contains("x")) close(); });
    const close = () => { m.remove(); document.body.style.overflow = ""; opts.onClose && opts.onClose(); };
    document.body.appendChild(m); document.body.style.overflow = "hidden";
    m._close = close;
    return m;
  }

  /* Anything that needs an identity now routes through real sign-in. */
  function needIdentity(cb) {
    if (me()) return cb();
    state.afterLogin = cb;
    toast("Sign in first — it takes 20 seconds and earns you points.", "warn");
    go("login");
  }

  function doVerify() {
    const code = $$("[data-otp]").map((x) => x.value).join("");
    const r = Store.verifyLogin(db, code, state.loginName);
    save();
    const e = $("#loerr");
    if (!r.ok) { if (e) { e.className = "err"; e.textContent = r.error; } return; }
    state.loginStep = 1; state.loginDemoCode = ""; state.loginId = "";
    toast(`Welcome${r.customer.name ? ", " + r.customer.name.split(" ")[0] : ""}! ★ ${r.customer.points} points`, "ok");
    const next = state.afterLogin;
    state.afterLogin = null;
    if (next) { render(); next(); } else go(r.customer.name ? "rewards" : "profile");
  }

  // ---------- router ----------
  function go(v) { location.hash = "#" + v; }
  function route() {
    const h = (location.hash || "#home").slice(1);
    state.view = h.split("?")[0] || "home";
    if (state.view === "book" && !state.stationTypeId) state.step = 1;
    render();
    window.scrollTo({ top: 0, behavior: "instant" });
  }
  window.addEventListener("hashchange", route);

  // ---------- render ----------
  function renderHeaderPill() {
    const host = $("#hdrpill");
    if (!host) return;
    const m = member();
    host.innerHTML = m
      ? `<a class="ptspill" href="#rewards" title="${esc(m.tier.name)} member">★ <b>${m.points.toLocaleString("en-IN")}</b> pts</a>`
      : `<a class="ptspill" href="#login">Sign in</a>`;
  }

  function render() {
    Store.expireHolds(db); save();
    $$(".navlink").forEach((a) => a.classList.toggle("on", a.dataset.v === state.view));
    const v = state.view;
    const el = $("#app");
    if (v === "home") el.innerHTML = viewHome();
    else if (v === "book") el.innerHTML = viewBook();
    else if (v === "menu") el.innerHTML = viewMenu();
    else if (v === "mine") el.innerHTML = viewMine();
    else if (v === "login") el.innerHTML = viewLogin();
    else if (v === "rewards") el.innerHTML = viewRewards();
    else if (v === "profile") el.innerHTML = viewProfile();
    else if (v === "info") el.innerHTML = viewInfo();
    else el.innerHTML = viewHome();
    bind();
    renderCartBar();
    renderHeaderPill();
  }

  // ---------- HOME ----------
  function liveOccupancy() {
    const now = E.localISO(new Date());
    return db.settings.stationTypes.map((t) => {
      const pool = db.stations.filter((s) => s.stationTypeId === t.id && s.active !== false);
      const maint = pool.filter((s) => s.status === "MAINTENANCE").length;
      const busy = pool.filter((s) => {
        if (s.status === "MAINTENANCE") return false;
        return db.bookingStations.some((bs) => {
          if (bs.stationId !== s.id) return false;
          const b = db.bookings.find((x) => x.id === bs.bookingId);
          return b && E.BLOCKING.includes(b.status) && bs.startAt <= now && bs.endAt > now;
        });
      }).length;
      return { type: t, total: pool.length, busy, maint, free: pool.length - busy - maint };
    });
  }

  function viewHome() {
    const B = db.settings.brand;
    const occ = liveOccupancy();
    const h = db.settings.hours.find((x) => x.day === new Date().getDay());
    const items = db.menuItems.filter((i) => i.bestseller).slice(0, 4);
    return `
    <section class="hero"><div class="wrap">
      <div class="tag">${esc(B.city)} · Gaming Café &amp; Kitchen</div>
      <h1>${esc(B.name)}</h1>
      <p class="lead">${esc(B.tagline)} — ${db.stations.length} stations, a full kitchen, and slots you can lock in from your phone.</p>
      <div class="row wrap mt16">
        <button class="btn pri" data-go="book">Book a station</button>
        <button class="btn" data-go="menu">Order food</button>
      </div>
      <div class="livebar">
        ${occ.map((o) => `<span class="livepill"><i class="dot ${o.free === 0 ? "busy" : o.free <= 1 ? "some" : ""}"></i>
          ${esc(o.type.name)} · <b>${o.free}</b> of ${o.total} free now</span>`).join("")}
        <span class="livepill"><i class="dot ${h && !h.closed ? "" : "busy"}"></i>
          ${h && !h.closed ? `Open today ${h.open}–${h.close}` : "Closed today"}</span>
      </div>
    </div></section>

    <section class="section"><div class="wrap">
      <h2>Rates &amp; rigs</h2>
      <p class="muted sm">Tap a station type to see live availability. Happy hour is 30% off, weekdays 12–3 PM.</p>
      <div class="grid g3 mt16">
        ${db.settings.stationTypes.map((t) => {
          const o = occ.find((x) => x.type.id === t.id);
          return `<button class="card hov stype" data-type="${t.id}">
            <span class="ic">${t.icon || "🎮"}</span>
            <h3>${esc(t.name)}</h3>
            <div class="rate">${E.fmt(E.toPaise(t.hourly))}<small>/hour</small></div>
            <div class="sm muted">${esc(t.specs || "")}</div>
            <div class="xs dim mt8">${o.total} units · seats ${t.seats} · ${o.free} free right now</div>
          </button>`;
        }).join("")}
      </div>
    </div></section>

    <section class="section" style="background:var(--bg2);border-top:1px solid var(--line);border-bottom:1px solid var(--line)">
      <div class="wrap">
        <div class="row"><h2 style="margin:0">From the kitchen</h2>
          <button class="btn sm ghost" style="margin-left:auto" data-go="menu">Full menu →</button></div>
        <div class="grid g4 mt16">
          ${items.map((i) => `<div class="card"><div class="row gap8">
            <span class="dietdot ${i.diet === "NON_VEG" ? "nonveg" : "veg"}"></span>
            <b class="sm">${esc(i.name)}</b></div>
            <div class="xs muted mt8">${esc(i.description)}</div>
            <div class="row mt8"><b>${E.fmt(i.pricePaise)}</b>
            <button class="btn xs food" style="margin-left:auto" data-add="${i.id}">Add</button></div></div>`).join("")}
        </div>
      </div>
    </section>

    <section class="section"><div class="wrap grid g2">
      <div class="card"><h3>Visit us</h3>
        <p class="sm muted">${esc(B.address)}</p>
        <p class="sm">📞 <a href="tel:${esc(B.phone)}">${esc(B.phone)}</a><br>
           💬 <a href="https://wa.me/${esc(B.whatsapp.replace(/\D/g, ""))}">WhatsApp us</a><br>
           ✉️ <a href="mailto:${esc(B.email)}">${esc(B.email)}</a></p>
        <table class="tbl mt8">${db.settings.hours.map((x) => `<tr><td class="sm">${["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"][x.day]}</td>
          <td class="sm right mono">${x.closed ? "Closed" : x.open + "–" + x.close}</td></tr>`).join("")}</table>
      </div>
      <div class="card"><h3>House rules</h3>
        <ul class="sm muted" style="padding-left:18px;line-height:1.9">
          <li>Arrive 5 minutes early — sessions start on the clock.</li>
          <li>Free cancellation up to 4 hours before. 50% back inside 1–4 hours.</li>
          <li>No-show after ${db.settings.booking.noShowGraceMinutes} minutes releases your station.</li>
          <li>Outside food isn't allowed — our kitchen delivers to your seat.</li>
          <li>Under-18s can't book sessions starting after ${db.settings.booking.minorCurfewHour}:00.</li>
          <li>We rent hardware time. No betting, wagering, or cash prize pools.</li>
        </ul>
        <button class="btn sm mt8" data-go="info">Terms, privacy &amp; refunds</button>
      </div>
    </div></section>`;
  }

  // ---------- BOOK ----------
  function viewBook() {
    const steps = ["Station", "Date", "Time", "Pay"];
    const bar = `<div class="steps">${steps.map((s, i) => `<div class="${state.step === i + 1 ? "on" : state.step > i + 1 ? "done" : ""}">${i + 1}. ${s}</div>`).join("")}</div>`;
    let body = "";
    if (state.step === 1) body = stepStation();
    else if (state.step === 2) body = stepDate();
    else if (state.step === 3) body = stepSlots();
    else body = stepPay();
    return `<section class="section"><div class="wrap" style="max-width:920px">${bar}${body}</div></section>`;
  }

  function stepStation() {
    return `<h2>What are you playing on?</h2>
    <p class="muted sm">Pick a rig, then how many you need.</p>
    <div class="grid g2 mt16">
      ${db.settings.stationTypes.map((t) => {
        const n = db.stations.filter((s) => s.stationTypeId === t.id && s.status !== "MAINTENANCE").length;
        return `<button class="card hov stype ${state.stationTypeId === t.id ? "sel" : ""}" data-type="${t.id}">
          <span class="ic">${t.icon}</span><h3>${esc(t.name)}</h3>
          <div class="rate">${E.fmt(E.toPaise(t.hourly))}<small>/hr</small></div>
          <div class="sm muted">${esc(t.specs)}</div>
          <div class="xs dim mt8">${n} available · ${t.seats} seat${t.seats > 1 ? "s" : ""} each</div>
        </button>`;
      }).join("")}
    </div>
    ${state.stationTypeId ? `
      <div class="card mt16">
        <label class="f">How many ${esc(st(state.stationTypeId).name)}s?</label>
        <div class="row wrap gap8">
          ${[1, 2, 3, 4, 5, 6].map((n) => `<button class="chip ${state.stationCount === n ? "on" : ""}" data-count="${n}">${n}</button>`).join("")}
        </div>
        <div class="hint">Booking more than one keeps your group together — it's all-or-nothing, so you never get split up.</div>
      </div>
      <button class="btn pri block mt16" data-step="2">Choose a date →</button>` : ""}`;
  }

  function stepDate() {
    const days = [];
    for (let i = 0; i <= db.settings.booking.advanceDays; i++) {
      const d = new Date(); d.setDate(d.getDate() + i);
      const key = E.dateKey(d);
      const open = E.slotsForDate(key, db.settings).length > 0;
      days.push({ d, key, open });
    }
    return `<h2>Which day?</h2>
    <p class="muted sm">${esc(st(state.stationTypeId).name)} × ${state.stationCount} · bookable ${db.settings.booking.advanceDays} days ahead.</p>
    <div class="datestrip mt16">
      ${days.map((x) => `<button class="dcell ${state.dateStr === x.key ? "on" : ""} ${x.open ? "" : "closed"}"
        ${x.open ? "" : "disabled aria-disabled=true"} data-date="${x.key}">
        <div class="dw">${dayName(x.d)}</div><div class="dd">${x.d.getDate()}</div><div class="dm">${monName(x.d)}</div></button>`).join("")}
    </div>
    <div class="row mt16"><button class="btn ghost" data-step="1">← Back</button>
      <button class="btn pri grow" data-step="3">See times →</button></div>`;
  }

  function stepSlots() {
    const stations = db.stations.filter((s) => s.stationTypeId === state.stationTypeId && s.active !== false);
    const a = E.availability({
      dateStr: state.dateStr, stations, stationTypes: db.settings.stationTypes,
      bookingStations: db.bookingStations, bookings: db.bookings, settings: db.settings,
    });
    if (!a.slots.length) return `<div class="card center"><h3>We're closed that day</h3>
      <button class="btn mt16" data-step="2">Pick another date</button></div>`;

    // Aggregate view: for each slot, how many stations of this type are free?
    const agg = a.slots.map((slot, i) => {
      let free = 0, gone = 0, held = 0, live = 0, other = null, price = 0;
      for (const s of stations) {
        const c = a.grid[s.id][i]; price = c.pricePaise;
        if (c.state === "AVAILABLE") free++;
        else if (c.state === "BOOKED") gone++;
        else if (c.state === "HELD") held++;
        else if (c.state === "IN_PROGRESS") live++;
        else other = c.state;
      }
      return { ...slot, free, gone, held, live, other, pricePaise: price, index: i };
    });

    const cls = (c) => {
      if (c.other && c.free === 0 && c.gone === 0 && c.held === 0 && c.live === 0)
        return c.other === "PAST" ? "past" : c.other === "MAINTENANCE" ? "maint" : c.other === "BUFFER" ? "buf" : "shut";
      if (c.free >= state.stationCount) return state.pickedSlots.includes(c.start) ? "pick" : "free";
      if (c.live > 0) return "live";
      if (c.held > 0 && c.gone === 0) return "held";
      return "gone";
    };
    const label = (c, k) => {
      if (k === "pick") return "PICKED";
      if (k === "free") return c.free + " free";
      if (k === "held") return "HOLDING";
      if (k === "live") return "IN USE";
      if (k === "gone") return "SOLD OUT";
      if (k === "maint") return "REPAIR";
      if (k === "past") return "GONE";
      if (k === "buf") return "CLEANUP";
      return "CLOSED";
    };

    const picked = [...state.pickedSlots].sort();
    const contiguous = picked.every((s, i) => i === 0 || s === E.addMin(picked[i - 1], db.settings.booking.slotMinutes));
    const hours = picked.length * (db.settings.booking.slotMinutes / 60);

    let sum = "";
    if (picked.length) {
      const type = st(state.stationTypeId);
      const slots = picked.map((s) => ({ start: s, end: E.addMin(s, db.settings.booking.slotMinutes) }));
      const pr = E.priceBooking({ stationType: type, slots, stationCount: state.stationCount, addonIds: [], settings: db.settings });
      sum = `<div class="sticky-sum">
        <div><div class="xs dim">${hours}h × ${state.stationCount} ${esc(type.name)}</div>
        <div class="tot">${E.fmt(pr.gamingPaise)}<span class="xs dim"> + tax</span></div></div>
        <button class="btn pri grow" data-step="4" ${contiguous ? "" : "disabled"}>
          ${contiguous ? "Continue →" : "Pick back-to-back slots"}</button></div>`;
    }

    return `<h2>${new Date(state.dateStr + "T00:00").toDateString()}</h2>
    <p class="muted sm">${esc(st(state.stationTypeId).name)} × ${state.stationCount}. Tap consecutive slots to build your session
      (${db.settings.booking.minHours}–${db.settings.booking.maxHours} hours).</p>

    <div class="gridscroll mt16">
      <table class="slots"><tbody><tr>
        <th>Availability<small>${stations.length} units</small></th>
        ${agg.map((c) => {
          const k = cls(c);
          const dis = k !== "free" && k !== "pick";
          return `<td><button class="slot ${k}" ${dis ? "disabled aria-disabled=true" : ""} data-slot="${c.start}"
            aria-label="${E.hhmm(c.start)} ${label(c, k)}">
            <span class="p">${E.hhmm(c.start)}</span>
            <span class="l">${dis && k === "gone" ? "✕ " : ""}${label(c, k)}</span>
            ${k === "free" || k === "pick" ? `<span class="xs" style="opacity:.7">${E.fmt(c.pricePaise)}</span>` : ""}
          </button></td>`;
        }).join("")}
      </tr></tbody></table>
    </div>

    <div class="legend">
      <span><i style="background:rgba(52,211,153,.25)"></i>Available</span>
      <span><i style="background:#1b2029"></i>Sold out</span>
      <span><i style="background:#1e1a33"></i>Someone's checking out</span>
      <span><i style="background:#2a1c10"></i>In use now</span>
      <span><i style="background:#1a1616"></i>Under repair</span>
    </div>

    <details class="card mt16"><summary class="sm" style="cursor:pointer;font-weight:700">Per-station view (${stations.length} units)</summary>
      <div class="gridscroll mt16"><table class="slots">
        <thead><tr><th>Station</th>${a.slots.map((s) => `<th>${E.hhmm(s.start)}</th>`).join("")}</tr></thead>
        <tbody>${stations.map((s) => `<tr><th>${esc(s.label)}<small>${s.status === "MAINTENANCE" ? esc(s.maintenanceNote || "repair") : ""}</small></th>
          ${a.grid[s.id].map((c) => {
            const k = { AVAILABLE: "free", BOOKED: "gone", HELD: "held", IN_PROGRESS: "live", MAINTENANCE: "maint", PAST: "past", BUFFER: "buf", CLOSED: "shut" }[c.state];
            return `<td><div class="slot ${k}" style="cursor:default;min-height:38px">
              <span class="l">${k === "free" ? "free" : k === "gone" ? "✕" : k === "held" ? "hold" : k === "live" ? "live" : k === "maint" ? "🔧" : "–"}</span></div></td>`;
          }).join("")}</tr>`).join("")}</tbody></table></div>
    </details>

    <div class="row mt16"><button class="btn ghost" data-step="2">← Change date</button>
      ${picked.length ? `<button class="btn ghost" data-clear="1">Clear selection</button>` : ""}
      <button class="btn sm ghost" data-waitlist="1" style="margin-left:auto">Nothing free? Join waitlist</button></div>
    ${sum}`;
  }

  function stepPay() {
    const type = st(state.stationTypeId);
    const picked = [...state.pickedSlots].sort();
    const start = picked[0];
    const hours = picked.length * (db.settings.booking.slotMinutes / 60);
    const slots = picked.map((s) => ({ start: s, end: E.addMin(s, db.settings.booking.slotMinutes) }));
    const pr = E.priceBooking({ stationType: type, slots, stationCount: state.stationCount, addonIds: state.addonIds, settings: db.settings });
    const mm = member();
    const tot = E.totals({
      gamingPaise: pr.gamingPaise, addonPaise: pr.addonPaise, couponCode: state.coupon, kind: "GAMING",
      memberPercent: mm ? mm.discountPercent : 0, redeemPoints: state.redeem, settings: db.settings,
    });
    const P = db.settings.payments;

    return `<h2>Review &amp; pay</h2>
    <div class="grid g2 mt16">
      <div class="col">
        <div class="card">
          <div class="row"><b>${esc(type.name)} × ${state.stationCount}</b><span class="badge b-info" style="margin-left:auto">${hours}h</span></div>
          <div class="sm muted mt8">${nice(start)} → ${E.hhmm(E.addMin(start, hours * 60))}</div>
          <div class="xs dim mt8">${esc(type.specs)}</div>
        </div>

        <div class="card"><label class="f">Add-ons</label>
          ${db.settings.addons.map((a) => `<label class="check"><input type="checkbox" data-addon="${a.id}" ${state.addonIds.includes(a.id) ? "checked" : ""}>
            <span class="grow">${esc(a.name)}</span><b>${E.fmt(E.toPaise(a.price))}</b></label>`).join("")}
        </div>

        ${(() => {
          const m = member();
          if (!m) return `<div class="card"><div class="row"><span style="font-size:20px">★</span>
            <div class="grow"><b class="sm">Sign in to earn points</b>
              <div class="xs muted">This booking would earn you points and could take up to 15% off.</div></div>
            <button class="btn sm pri" data-go="login">Sign in</button></div></div>`;
          const bill = pr.gamingPaise + pr.addonPaise;
          const cap = E.maxRedeemable(m.points, bill, db.settings);
          const willEarn = E.pointsEarned({ gamingPaise: bill, tier: m.tier, settings: db.settings });
          return `<div class="card accent">
            <div class="row"><span class="tierpill t-${m.tier.id}">${esc(m.tier.name)}</span>
              <span class="sm" style="margin-left:auto">★ <b class="acc">${m.points}</b> pts · ${E.fmt(m.valuePaise)}</span></div>
            ${m.discountPercent ? `<div class="perk mt8"><i>✓</i><span><b class="acc">${m.discountPercent}% ${esc(m.tier.name)} discount</b> applied automatically</span></div>` : ""}
            <div class="perk"><i>+</i><span>You'll earn <b class="acc">${willEarn.points} points</b> on this booking${willEarn.bonus ? ` (incl. +${willEarn.bonusPct}% tier bonus)` : ""}</span></div>
            ${cap.points > 0 ? `
              <div class="field mt16"><label class="f" for="rdm">Use points — up to ${cap.points} (${db.settings.loyalty.maxRedeemPercent}% of the bill)</label>
                <div class="row gap8">
                  <input id="rdm" type="number" min="0" max="${cap.points}" step="10" value="${state.redeem}">
                  <button class="btn" data-applyrdm="1">Apply</button>
                  ${state.redeem ? `<button class="btn ghost" data-clearrdm="1">Clear</button>` : ""}
                </div>
                ${state.redeem ? `<div class="sm mt8" style="color:var(--ok)">✓ ${state.redeem} points off — saving ${E.fmt(E.redeemValuePaise(state.redeem, db.settings))}</div>` : ""}
              </div>`
              : `<div class="hint">${esc(cap.reason || "No points available to redeem on this bill.")}</div>`}
          </div>`;
        })()}

        <div class="card"><label class="f" for="cpn">Coupon</label>
          <div class="row gap8"><input id="cpn" type="text" placeholder="FIRST50" value="${esc(state.coupon)}" style="text-transform:uppercase">
            <button class="btn" data-applycpn="1">Apply</button></div>
          ${tot.couponError ? `<div class="err">${esc(tot.couponError)}</div>` : ""}
          ${tot.coupon ? `<div class="sm" style="color:var(--ok);margin-top:6px">✓ ${esc(tot.coupon.code)} — ${esc(tot.coupon.note)}</div>` : ""}
          <div class="hint">Try FIRST50 or WEEKDAY20</div>
        </div>
      </div>

      <div class="col">
        <div class="card">
          <h3>Bill</h3>
          <table class="tbl">
            ${pr.lines.map((l) => `<tr><td class="sm">${esc(l.label)}${l.rules.length ? `<br><span class="xs dim">${esc(l.rules.join(" + "))}</span>` : ""}</td>
              <td class="right sm mono">${E.fmt(l.paise)}</td></tr>`).join("")}
            ${pr.addonLines.map((l) => `<tr><td class="sm">${esc(l.label)}</td><td class="right sm mono">${E.fmt(l.paise)}</td></tr>`).join("")}
            <tr><td class="sm"><b>Subtotal</b></td><td class="right sm mono"><b>${E.fmt(tot.subtotalPaise)}</b></td></tr>
            ${tot.couponPaise ? `<tr><td class="sm" style="color:var(--ok)">Coupon ${esc(tot.coupon?.code || "")}</td><td class="right sm mono" style="color:var(--ok)">−${E.fmt(tot.couponPaise)}</td></tr>` : ""}
            ${tot.memberPaise ? `<tr><td class="sm" style="color:var(--ok)">${esc(mm.tier.name)} member ${tot.memberPercent}%</td><td class="right sm mono" style="color:var(--ok)">−${E.fmt(tot.memberPaise)}</td></tr>` : ""}
            ${tot.pointsPaise ? `<tr><td class="sm" style="color:var(--ok)">${tot.redeemPoints} points redeemed</td><td class="right sm mono" style="color:var(--ok)">−${E.fmt(tot.pointsPaise)}</td></tr>` : ""}
            ${tot.taxRegistered ? tot.taxBreakup.map((t) => `<tr><td class="xs dim">${esc(t.label)} @ ${t.percent}%${db.settings.tax.interState ? "" : " (CGST+SGST)"}</td>
              <td class="right xs mono dim">${E.fmt(t.taxPaise)}</td></tr>`).join("") : `<tr><td class="xs dim">Not GST registered — no tax charged</td><td></td></tr>`}
            ${tot.roundOffPaise ? `<tr><td class="xs dim">Round off</td><td class="right xs mono dim">${tot.roundOffPaise > 0 ? "+" : ""}${E.fmt(tot.roundOffPaise)}</td></tr>` : ""}
            <tr><td><b style="font-size:16px">Total</b></td><td class="right"><b class="mono" style="font-size:17px;color:var(--accent)">${E.fmt(tot.totalPaise)}</b></td></tr>
          </table>
        </div>

        <div class="card">
          <label class="f">Pay with</label>
          <button class="btn pri block" data-pay="UPI">📱 UPI — GPay / PhonePe / Paytm</button>
          <button class="btn block mt8" data-pay="CARD">💳 Card / Netbanking / Wallet</button>
          ${P.allowManualUpi ? `<button class="btn block mt8" data-pay="MANUAL">🔗 Show UPI QR (I'll enter the UTR)</button>` : ""}
          ${P.allowPayAtCounter ? `<button class="btn block mt8 ghost" data-pay="COUNTER">🏪 Pay at the counter</button>` : ""}
          <div class="hint">${P.gateway === "MOCK"
            ? "Demo mode — no real money moves. Swap <code>payments.gateway</code> to RAZORPAY in config.js and add a server to go live."
            : "Secured by Razorpay."}</div>
        </div>

        <div class="card sm muted">
          Free cancellation until 4 hours before. 50% refunded 1–4 hours before. Nothing inside the last hour.
          No-shows are released after ${db.settings.booking.noShowGraceMinutes} minutes.
        </div>
      </div>
    </div>
    <div class="row mt16"><button class="btn ghost" data-step="3">← Change time</button></div>`;
  }

  // ---------- payment ----------
  function doPay(method) {
    const picked = [...state.pickedSlots].sort();
    if (!picked.length) return toast("Pick a time slot first.", "bad");
    needIdentity(() => {
      const hours = picked.length * (db.settings.booking.slotMinutes / 60);
      const c = me();
      const r = Store.holdBooking(db, {
        stationTypeId: state.stationTypeId, stationCount: state.stationCount,
        startISO: picked[0], hours, addonIds: state.addonIds, couponCode: state.coupon,
        customerId: c.id, name: c.name, phone: c.phone, email: c.email,
        redeemPoints: state.redeem, source: "WEB",
      });
      if (!r.ok) {
        save(); toast(r.errors[0] || "That slot just went.", "bad");
        state.pickedSlots = []; state.step = 3; render(); return;
      }
      save();
      const b = db.bookings.find((x) => x.id === r.bookingId);

      if (method === "COUNTER") {
        Store.markPayAtCounter(db, b.id); save();
        return showTicket(b.id, "Reserved — pay at the counter");
      }
      if (method === "MANUAL") return manualUpi(b);

      // mock gateway
      const m = modal("Confirm payment", `
        <div class="center">
          <div class="xs dim">PAYING</div>
          <div style="font-family:var(--display);font-size:2.2rem;font-weight:700;color:var(--accent)">${E.fmt(b.totalPaise)}</div>
          <div class="sm muted">${esc(b.code)} · ${method === "UPI" ? "UPI" : "Card"}</div>
        </div>
        <div class="card mt16 sm muted">Test gateway. In production this opens Razorpay Checkout, and the booking
          is only confirmed after your server verifies the signature <b>and</b> the webhook arrives.</div>
        <button class="btn pri block mt16" id="psucc">Simulate successful payment</button>
        <button class="btn block mt8 danger" id="pfail">Simulate failure</button>
        <div class="hint center">Your slot is held for ${db.settings.booking.holdMinutes} minutes.</div>`);
      $("#psucc", m).onclick = () => {
        Store.confirmPayment(db, b.id, { method, idempotencyKey: "web_" + b.id }); save();
        m._close(); showTicket(b.id, "Payment successful");
      };
      $("#pfail", m).onclick = () => {
        m._close(); toast("Payment failed — your slot is still held for a few minutes.", "warn"); render();
      };
    });
  }

  function manualUpi(b) {
    const B = db.settings.brand;
    const uri = `upi://pay?pa=${encodeURIComponent(B.upiId)}&pn=${encodeURIComponent(B.name)}&am=${(b.totalPaise / 100).toFixed(2)}&cu=INR&tn=${encodeURIComponent(b.code)}`;
    const m = modal("Pay by UPI", `
      <div class="center">
        <div class="xs dim">AMOUNT</div>
        <div style="font-family:var(--display);font-size:2rem;font-weight:700;color:var(--accent)">${E.fmt(b.totalPaise)}</div>
        <div class="qrbox mt16">
          <div class="vpa">${esc(B.upiId)}</div>
          <div class="code">${esc(b.code)}</div>
          <div class="xs dim mt8">put this code in the payment note</div>
        </div>
        <p class="sm muted mt16">Pay <b>${esc(B.upiId)}</b> and put <b>${esc(b.code)}</b> in the note.
        <a href="${uri}">Open a UPI app</a> if you're on your phone.</p>
      </div>
      <div class="field mt16"><label class="f" for="utr">UPI reference / UTR number</label>
        <input id="utr" type="text" inputmode="numeric" placeholder="12 digits from your payment app"></div>
      <button class="btn pri block" id="usub">Submit for verification</button>
      <div class="hint">Staff verify this at the counter. Your slot stays held until they do.</div>`);
    $("#usub", m).onclick = () => {
      const utr = $("#utr", m).value.trim();
      if (utr.length < 6) return toast("Enter the UTR from your UPI app.", "bad");
      Store.confirmPayment(db, b.id, { method: "UPI_QR_MANUAL", idempotencyKey: "man_" + b.id, utr, manual: true });
      save(); m._close(); showTicket(b.id, "Submitted — awaiting staff verification");
    };
  }

  function showTicket(bookingId, headline) {
    const b = db.bookings.find((x) => x.id === bookingId);
    const rows = db.bookingStations.filter((r) => r.bookingId === bookingId);
    const type = st(b.stationTypeId);
    state.pickedSlots = []; state.addonIds = []; state.coupon = ""; state.step = 1; state.redeem = 0;
    modal(headline, `
      <div class="center">
        <div style="font-size:44px">${b.status === "CONFIRMED" ? "✅" : "⏳"}</div>
        <div class="xs dim mt8">SHOW THIS AT THE COUNTER</div>
        <div class="mono" style="font-size:2rem;font-weight:800;letter-spacing:.1em;color:var(--accent)">${esc(b.code)}</div>
        ${b.invoiceNo ? `<div class="xs dim">Invoice ${esc(b.invoiceNo)}</div>` : ""}
      </div>
      <table class="tbl mt16">
        <tr><td class="sm dim">Station</td><td class="right sm"><b>${esc(type.name)} × ${rows.length}</b><br><span class="xs dim">${rows.map((r) => esc(r.stationId)).join(", ")}</span></td></tr>
        <tr><td class="sm dim">When</td><td class="right sm">${nice(b.startAt)} → ${E.hhmm(b.endAt)}</td></tr>
        <tr><td class="sm dim">Total</td><td class="right sm mono">${E.fmt(b.totalPaise)}</td></tr>
        <tr><td class="sm dim">Paid</td><td class="right sm mono">${E.fmt(b.paidPaise)}${b.paidPaise < b.totalPaise ? ` <span class="badge b-warn">${E.fmt(b.totalPaise - b.paidPaise)} due</span>` : ""}</td></tr>
      </table>
      ${b.pointsEarned > 0 ? `<div class="card accent mt16 center">
        <div class="xs acc" style="font-weight:800;letter-spacing:.08em">RESPAWN REWARDS</div>
        <div style="font-family:var(--display);font-size:1.5rem;font-weight:700;color:var(--accent)">+${b.pointsEarned} points</div>
        <div class="xs muted">Balance ${member() ? member().points : 0} · <a href="#rewards">see rewards</a></div></div>` : ""}
      <button class="btn pri block mt16" data-go="mine" data-closeme="1">See my bookings</button>
      <button class="btn block mt8 ghost" data-go="menu" data-closeme="1">Pre-order food to your seat 🍔</button>`);
  }

  // ---------- MENU ----------
  function viewMenu() {
    const cats = db.menuCategories.filter((c) => c.active);
    const items = db.menuItems.filter((i) => {
      if (state.menuCat !== "ALL" && i.categoryId !== state.menuCat) return false;
      if (state.dietFilter === "VEG" && i.diet !== "VEG") return false;
      if (state.dietFilter === "NON_VEG" && i.diet === "VEG") return false;
      return true;
    });
    const grouped = {};
    items.forEach((i) => { (grouped[i.categoryId] ||= []).push(i); });

    return `<section class="section"><div class="wrap" style="max-width:860px">
      <h2>Kitchen</h2>
      <p class="muted sm">Order to your table, your gaming station, or for takeaway.</p>
      <div class="row wrap gap8 mt16">
        <button class="chip ${state.dietFilter === "ALL" ? "foodon" : ""}" data-diet="ALL">Everything</button>
        <button class="chip ${state.dietFilter === "VEG" ? "foodon" : ""}" data-diet="VEG">🟢 Veg only</button>
        <button class="chip ${state.dietFilter === "NON_VEG" ? "foodon" : ""}" data-diet="NON_VEG">🔴 Non-veg</button>
      </div>
      <div class="row wrap gap8 mt8" style="overflow-x:auto">
        <button class="chip ${state.menuCat === "ALL" ? "on" : ""}" data-cat="ALL">All</button>
        ${cats.map((c) => `<button class="chip ${state.menuCat === c.id ? "on" : ""}" data-cat="${c.id}">${esc(c.name)}</button>`).join("")}
      </div>
      ${Object.keys(grouped).length === 0 ? `<div class="card center mt16 muted">Nothing matches that filter.</div>` : ""}
      ${cats.filter((c) => grouped[c.id]).map((c) => `
        <h3 class="mt24">${esc(c.name)}</h3>
        <div class="card pad0" style="padding:0 16px">
          ${grouped[c.id].map((i) => {
            const q = state.cart[i.id] || 0;
            return `<div class="mitem">
              <div class="info">
                <div class="nm"><span class="dietdot ${i.diet === "NON_VEG" ? "nonveg" : "veg"}" title="${i.diet}"></span>
                  ${esc(i.name)} ${i.bestseller ? '<span class="badge b-warn">Bestseller</span>' : ""}
                  ${!i.available ? '<span class="badge b-bad">Sold out</span>' : ""}</div>
                <div class="ds">${esc(i.description)}</div>
                <div class="xs dim mt8">~${i.prepMinutes} min</div>
              </div>
              <div class="col" style="align-items:flex-end;gap:8px">
                <div class="pr">${E.fmt(i.pricePaise)}</div>
                ${!i.available ? "" : q === 0
                  ? `<button class="btn xs food" data-add="${i.id}">Add</button>`
                  : `<div class="qty"><button data-dec="${i.id}" aria-label="One less">−</button><span>${q}</span><button data-add="${i.id}" aria-label="One more">+</button></div>`}
              </div></div>`;
          }).join("")}
        </div>`).join("")}
    </div></section>`;
  }

  function cartTotals() {
    let food = 0;
    const lines = Object.entries(state.cart).map(([id, qty]) => {
      const it = db.menuItems.find((m) => m.id === id);
      food += it.pricePaise * qty;
      return { it, qty, line: it.pricePaise * qty };
    });
    const m = member();
    const tot = E.totals({
      foodPaise: food, couponCode: state.cartCoupon, kind: "FOOD",
      memberPercent: m ? m.discountPercent : 0, redeemPoints: state.cartRedeem, settings: db.settings,
    });
    return { lines, tot, count: lines.reduce((a, l) => a + l.qty, 0), foodPaise: food, m };
  }

  function renderCartBar() {
    const { tot, count } = cartTotals();
    const bar = $("#cartbar");
    if (!count) { bar.className = "hide"; document.body.classList.remove("hascart"); return; }
    bar.className = "cartbar";
    bar.innerHTML = `<span>${count} item${count > 1 ? "s" : ""} · ${E.fmt(tot.totalPaise)}</span>
      <button class="btn sm" style="margin-left:auto;background:#241500;color:#fbbf24;border-color:#3d2600" id="cartgo">Checkout →</button>`;
    $("#cartgo").onclick = openCart;
  }

  function openCart() {
    const { lines, tot } = cartTotals();
    const live = db.bookings.filter((b) => b.customerId === me()?.id && ["CONFIRMED", "IN_PROGRESS"].includes(b.status) && b.endAt > E.localISO(new Date()));
    const m = modal("Your order", `
      <table class="tbl">
        ${lines.map((l) => `<tr><td>${esc(l.it.name)}<br><span class="xs dim">${l.qty} × ${E.fmt(l.it.pricePaise)}</span></td>
          <td class="right"><span class="mono sm">${E.fmt(l.line)}</span><br>
          <button class="btn xs ghost" data-cdec="${l.it.id}">remove one</button></td></tr>`).join("")}
      </table>
      <div class="field mt16"><label class="f">Where's it going?</label>
        <select id="otype">
          <option value="DINE_IN">Dine in — I'll pick a table</option>
          ${live.length ? `<option value="IN_SESSION">To my gaming station (${esc(live[0].code)})</option>` : ""}
          <option value="TAKEAWAY">Takeaway</option>
        </select></div>
      <div class="field" id="tblwrap"><label class="f">Table</label>
        <select id="otable">${db.tables.map((t) => `<option value="${t.id}">${esc(t.label)} · ${t.seats} seats</option>`).join("")}</select></div>
      <div class="field"><label class="f">Coupon</label>
        <div class="row gap8"><input id="ccpn" type="text" placeholder="FOOD30" value="${esc(state.cartCoupon)}" style="text-transform:uppercase">
          <button class="btn" id="ccapply">Apply</button></div>
        ${tot.couponError ? `<div class="err">${esc(tot.couponError)}</div>` : ""}</div>
      ${(() => {
        const m = member();
        if (!m) return `<div class="card mt16"><div class="row"><span style="font-size:19px">★</span>
          <div class="grow xs">Sign in to earn points on this order.</div>
          <button class="btn xs pri" data-go="login" data-closeme="1">Sign in</button></div></div>`;
        const cap = E.maxRedeemable(m.points, lines.reduce((a, l) => a + l.line, 0), db.settings);
        return `<div class="card accent mt16">
          <div class="row"><span class="tierpill t-${m.tier.id}">${esc(m.tier.name)}</span>
            <span class="xs" style="margin-left:auto">★ <b class="acc">${m.points}</b> pts</span></div>
          ${cap.points > 0 ? `<div class="row gap8 mt8">
            <input id="crdm" type="number" min="0" max="${cap.points}" step="10" value="${state.cartRedeem}" placeholder="0">
            <button class="btn sm" id="crdmgo">Use points</button></div>
            <div class="hint">Up to ${cap.points} points on this order</div>`
            : `<div class="hint">${esc(cap.reason || "Nothing to redeem yet")}</div>`}
        </div>`;
      })()}
      <table class="tbl mt16">
        <tr><td class="sm">Subtotal</td><td class="right sm mono">${E.fmt(tot.subtotalPaise)}</td></tr>
        ${tot.couponPaise ? `<tr><td class="sm" style="color:var(--ok)">Coupon</td><td class="right sm mono" style="color:var(--ok)">−${E.fmt(tot.couponPaise)}</td></tr>` : ""}
        ${tot.memberPaise ? `<tr><td class="sm" style="color:var(--ok)">Member discount ${tot.memberPercent}%</td><td class="right sm mono" style="color:var(--ok)">−${E.fmt(tot.memberPaise)}</td></tr>` : ""}
        ${tot.pointsPaise ? `<tr><td class="sm" style="color:var(--ok)">${tot.redeemPoints} points</td><td class="right sm mono" style="color:var(--ok)">−${E.fmt(tot.pointsPaise)}</td></tr>` : ""}
        ${tot.taxBreakup.map((t) => `<tr><td class="xs dim">${esc(t.label)} @ ${t.percent}%</td><td class="right xs mono dim">${E.fmt(t.taxPaise)}</td></tr>`).join("")}
        <tr><td><b>Total</b></td><td class="right"><b class="mono" style="color:var(--food)">${E.fmt(tot.totalPaise)}</b></td></tr>
      </table>
      <button class="btn food block mt16" id="oplace">Place order &amp; pay</button>
      <button class="btn block mt8 ghost" id="ocash">Pay at counter</button>`);

    const sync = () => { $("#tblwrap", m).style.display = $("#otype", m).value === "DINE_IN" ? "" : "none"; };
    $("#otype", m).onchange = sync; sync();
    $("#ccapply", m).onclick = () => { state.cartCoupon = $("#ccpn", m).value.trim().toUpperCase(); m._close(); openCart(); };
    if ($("#crdmgo", m)) $("#crdmgo", m).onclick = () => {
      state.cartRedeem = Math.max(0, parseInt($("#crdm", m).value || "0", 10));
      m._close(); openCart();
    };
    $$("[data-cdec]", m).forEach((btn) => btn.onclick = () => {
      const id = btn.dataset.cdec;
      state.cart[id]--; if (state.cart[id] <= 0) delete state.cart[id];
      m._close(); render(); if (Object.keys(state.cart).length) openCart();
    });
    const place = (method) => needIdentity(() => {
      const cu = me();
      const r = Store.createOrder(db, {
        type: $("#otype", m).value, tableId: $("#otype", m).value === "DINE_IN" ? $("#otable", m).value : null,
        bookingId: $("#otype", m).value === "IN_SESSION" ? live[0]?.id : null,
        items: Object.entries(state.cart).map(([itemId, qty]) => ({ itemId, qty })),
        customerId: cu.id, name: cu.name, phone: cu.phone, email: cu.email,
        couponCode: state.cartCoupon, redeemPoints: state.cartRedeem, method, source: "WEB",
      });
      save();
      if (!r.ok) return toast(r.error, "bad");
      state.cart = {}; state.cartCoupon = ""; state.cartRedeem = 0; m._close(); render();
      modal("Order placed", `<div class="center"><div style="font-size:44px">🍔</div>
        <div class="mono" style="font-size:1.7rem;font-weight:800;color:var(--food)">${esc(r.order.code)}</div>
        <p class="sm muted">Kitchen has it. About <b>${r.order.etaMinutes} minutes</b>.
        ${method === "COUNTER" ? "Pay at the counter." : "Paid."}</p>
        ${r.order.pointsEarned > 0 ? `<div class="xs acc" style="font-weight:800">+${r.order.pointsEarned} Respawn points</div>` : ""}</div>
        <button class="btn block mt16" data-closeme="1">Done</button>`);
    });
    $("#oplace", m).onclick = () => place("UPI");
    $("#ocash", m).onclick = () => place("COUNTER");
  }

  // ---------- MY BOOKINGS ----------
  function viewMine() {
    const cu = me();
    if (!cu)
      return `<section class="section"><div class="wrap center card" style="max-width:440px">
        <h3>Sign in to see your bookings</h3>
        <p class="muted sm">One code to your phone or email and you're in — plus ${db.settings.loyalty.signupBonus} points to start.</p>
        <button class="btn pri mt16" data-go="login">Sign in</button></div></section>`;

    const mine = db.bookings.filter((b) => b.customerId === cu.id).sort((a, b) => b.startAt.localeCompare(a.startAt));
    const orders = db.orders.filter((o) => o.customerId === cu.id).sort((a, b) => b.placedAt.localeCompare(a.placedAt)).slice(0, 12);
    const now = E.localISO(new Date());
    const up = mine.filter((b) => b.endAt >= now && !["CANCELLED", "EXPIRED", "NO_SHOW"].includes(b.status));
    const past = mine.filter((b) => !up.includes(b));

    const badge = (s) => ({
      CONFIRMED: '<span class="badge b-ok">Confirmed</span>', HELD: '<span class="badge b-held">Holding</span>',
      PENDING_PAYMENT: '<span class="badge b-warn">Payment pending</span>', IN_PROGRESS: '<span class="badge b-info">Playing now</span>',
      COMPLETED: '<span class="badge b-dim">Done</span>', CANCELLED: '<span class="badge b-bad">Cancelled</span>',
      NO_SHOW: '<span class="badge b-bad">No show</span>', EXPIRED: '<span class="badge b-dim">Expired</span>',
    }[s] || `<span class="badge b-dim">${s}</span>`);

    const card = (b) => {
      const rows = db.bookingStations.filter((r) => r.bookingId === b.id);
      const type = st(b.stationTypeId);
      const canCancel = ["CONFIRMED", "PENDING_PAYMENT", "HELD"].includes(b.status) && b.startAt > now;
      const rf = E.refundFor(b.startAt, now, b.paidPaise, db.settings);
      const isLive = b.status === "IN_PROGRESS";
      return `<div class="card">
        <div class="row wrap"><div class="mono" style="font-size:1.15rem;font-weight:800;color:var(--accent)">${esc(b.code)}</div>
          <span style="margin-left:auto">${badge(b.status)}</span></div>
        <div class="mt8"><b>${esc(type.name)} × ${rows.length}</b> <span class="xs dim">${rows.map((r) => esc(r.stationId)).join(", ")}</span></div>
        <div class="sm muted">${nice(b.startAt)} → ${E.hhmm(b.endAt)} · ${b.hours}h</div>
        <div class="row mt8"><span class="sm mono">${E.fmt(b.totalPaise)}</span>
          ${b.paidPaise < b.totalPaise ? `<span class="badge b-warn">${E.fmt(b.totalPaise - b.paidPaise)} due at counter</span>` : '<span class="badge b-ok">Paid</span>'}</div>
        <div class="row wrap gap8 mt16">
          ${isLive ? `<button class="btn sm pri" data-extend="${b.id}">+30 min</button>` : ""}
          ${canCancel ? `<button class="btn sm danger" data-cancel="${b.id}">Cancel${rf.refundPaise ? ` · ${E.fmt(rf.refundPaise)} back` : " · no refund"}</button>` : ""}
          ${["CONFIRMED", "IN_PROGRESS"].includes(b.status) ? `<button class="btn sm ghost" data-go="menu">Order food 🍔</button>` : ""}
          ${b.invoiceNo ? `<button class="btn sm ghost" data-inv="${b.id}">Invoice</button>` : ""}
        </div></div>`;
    };

    return `<section class="section"><div class="wrap" style="max-width:820px">
      <div class="row wrap"><h2 style="margin:0">Hi ${esc((cu.name || "there").split(" ")[0])}</h2>
        <span class="tierpill t-${member().tier.id}">${esc(member().tier.name)}</span>
        <button class="btn sm ghost" style="margin-left:auto" data-go="profile">Account</button></div>
      <a class="loyaltycard mt16" href="#rewards" style="display:block">
        <div class="row"><div><div class="lbl">${esc(db.settings.loyalty.programName)}</div>
          <div class="pts" style="font-size:1.9rem">${member().points.toLocaleString("en-IN")} <span class="sm muted" style="font-family:var(--sans)">points · worth ${E.fmt(member().valuePaise)}</span></div></div>
          <span class="acc" style="margin-left:auto;font-size:22px">→</span></div>
        ${member().next ? `<div class="bar mt16"><i style="width:${member().progress.toFixed(1)}%"></i></div>
          <div class="xs mt8" style="color:var(--muted)">${E.fmt(member().toNextPaise)} more to ${esc(member().next.name)}</div>` : ""}
      </a>
      <h3 class="mt24">Upcoming</h3>
      ${up.length ? `<div class="grid g2">${up.map(card).join("")}</div>`
        : `<div class="card center muted sm">No upcoming sessions. <button class="btn sm pri mt8" data-go="book">Book one</button></div>`}
      ${orders.length ? `<h3 class="mt24">Food orders</h3><div class="card pad0"><table class="tbl">
        <thead><tr><th>Order</th><th>When</th><th>Status</th><th class="right">Total</th></tr></thead>
        <tbody>${orders.map((o) => `<tr><td class="mono sm">${esc(o.code)}</td><td class="sm">${nice(o.placedAt)}</td>
          <td>${badge(o.status)}</td><td class="right mono sm">${E.fmt(o.totalPaise)}</td></tr>`).join("")}</tbody></table></div>` : ""}
      ${past.length ? `<h3 class="mt24">History</h3><div class="grid g2">${past.slice(0, 8).map(card).join("")}</div>` : ""}
    </div></section>`;
  }

  function showInvoice(bookingId) {
    const b = db.bookings.find((x) => x.id === bookingId);
    const B = db.settings.brand;
    const rows = db.bookingStations.filter((r) => r.bookingId === bookingId);
    modal("Invoice " + (b.invoiceNo || ""), `
      <div class="receipt" id="invbox">
        <div style="display:flex;justify-content:space-between;gap:12px">
          <div><b style="font-size:17px">${esc(B.name)}</b><br>
            <span class="xs muted">${esc(B.legalEntity)}<br>${esc(B.address)}<br>
            ${B.gstin ? "GSTIN: " + esc(B.gstin) + "<br>" : ""}${B.fssai ? "FSSAI: " + esc(B.fssai) : ""}</span></div>
          <div style="text-align:right" class="xs muted">Invoice<br><b style="font-size:14px;color:var(--txt)">${esc(b.invoiceNo || "-")}</b><br>${esc(b.startAt.replace("T", " "))}</div>
        </div>
        <hr>
        <div class="sm">Billed to: <b>${esc(b.guestName)}</b> · ${esc(b.guestPhone)}</div>
        <table class="mt8">
          <tr><th>Description</th><th>SAC</th><th style="text-align:right">Amount</th></tr>
          <tr><td>${esc(st(b.stationTypeId).name)} × ${rows.length} · ${b.hours}h</td><td>998439</td><td align="right">${E.fmt(b.subtotalPaise)}</td></tr>
          ${b.discountPaise ? `<tr><td colspan="2">Discount ${esc(b.couponCode || "")}</td><td align="right">−${E.fmt(b.discountPaise)}</td></tr>` : ""}
          ${(b.taxBreakup || []).map((t) => db.settings.tax.interState
            ? `<tr><td colspan="2">IGST @ ${t.percent}%</td><td align="right">${E.fmt(t.taxPaise)}</td></tr>`
            : `<tr><td colspan="2">CGST @ ${t.percent / 2}%</td><td align="right">${E.fmt(Math.round(t.taxPaise / 2))}</td></tr>
               <tr><td colspan="2">SGST @ ${t.percent / 2}%</td><td align="right">${E.fmt(t.taxPaise - Math.round(t.taxPaise / 2))}</td></tr>`).join("")}
          <tr class="tot"><td colspan="2">Total</td><td align="right">${E.fmt(b.totalPaise)}</td></tr>
          <tr><td colspan="2">Paid</td><td align="right">${E.fmt(b.paidPaise)}</td></tr>
        </table>
        <div class="xs dim mt16">
          ${db.settings.tax.registered ? "Gaming is a recreational service taxed at 18%. Food, where billed, is 5% without input tax credit." : "Not registered under GST — no tax collected."}
          <br>Place of supply: ${esc(B.city)}. This is a computer-generated invoice.</div>
      </div>
      <button class="btn block mt16" onclick="window.print()">Print / Save as PDF</button>`);
  }


  /* Signed-out guard: render a real prompt rather than a blank flash. */
  function signInWall(title, blurb) {
    const L = db.settings.loyalty;
    return `<section class="section"><div class="wrap" style="max-width:440px">
      <div class="card center">
        <div style="font-size:38px">★</div>
        <h2>${esc(title)}</h2>
        <p class="muted sm">${esc(blurb)}</p>
        <button class="btn pri block mt16" data-go="login">Sign in with phone or email</button>
        <div class="hint">New here? You'll get ${L.signupBonus} points just for joining ${esc(L.programName)}.</div>
      </div></div></section>`;
  }

  // ---------- LOGIN (phone or email + OTP) ----------
  function viewLogin() {
    const A = db.settings.auth;
    if (me()) {
      const m = member();
      return `<section class="section"><div class="wrap center card" style="max-width:420px">
        <h2>You're signed in</h2>
        <p class="muted sm">${esc(me().name || me().phone || me().email)} · <span class="tierpill t-${m.tier.id}">${esc(m.tier.name)}</span></p>
        <button class="btn pri block mt16" data-go="rewards">Go to my rewards</button>
        <button class="btn block mt8 ghost" data-logout="1">Sign out</button></div></section>`;
    }
    const L = db.settings.loyalty;

    if (state.loginStep === 2) {
      const len = A.otpLength;
      return `<section class="section"><div class="wrap" style="max-width:420px">
        <div class="card">
          <h2>Enter the code</h2>
          <p class="muted sm">We sent a ${len}-digit code to <b class="acc">${esc(state.loginId)}</b>.</p>
          <div class="otp mt16">
            ${Array.from({ length: len }).map((_, i) => `<input type="text" inputmode="numeric" maxlength="1"
              data-otp="${i}" aria-label="Digit ${i + 1}" autocomplete="${i === 0 ? "one-time-code" : "off"}">`).join("")}
          </div>
          ${state.loginDemoCode ? `<div class="card accent mt16 center">
            <div class="xs acc" style="font-weight:800;letter-spacing:.1em">DEMO BUILD — NO SMS IS SENT</div>
            <div class="mono" style="font-size:1.6rem;font-weight:800;color:var(--accent);letter-spacing:.2em">${esc(state.loginDemoCode)}</div>
            <button class="btn xs ghost mt8" data-autofill="1">Fill it in for me</button></div>` : ""}
          <div class="err hide" id="loerr"></div>
          <button class="btn pri block mt16" data-verify="1">Verify &amp; sign in</button>
          <div class="row mt16"><button class="btn sm ghost" data-loginback="1">← Change ${state.loginMode}</button>
            <button class="btn sm ghost" style="margin-left:auto" data-resend="1">Resend code</button></div>
        </div></div></section>`;
    }

    return `<section class="section"><div class="wrap" style="max-width:420px">
      <div class="card">
        <h2>Sign in</h2>
        <p class="muted sm">One account for bookings, orders and ${esc(L.programName)}.</p>

        <div class="segs mt16">
          ${A.allowPhone ? `<button class="${state.loginMode === "phone" ? "on" : ""}" data-lmode="phone">📱 Mobile</button>` : ""}
          ${A.allowEmail ? `<button class="${state.loginMode === "email" ? "on" : ""}" data-lmode="email">✉️ Email</button>` : ""}
        </div>

        <div class="field mt16">
          ${state.loginMode === "phone"
            ? `<label class="f" for="lid">Mobile number</label>
               <input id="lid" type="tel" inputmode="numeric" maxlength="10" placeholder="98300 00000"
                      autocomplete="tel" value="${esc(state.loginId)}">`
            : `<label class="f" for="lid">Email address</label>
               <input id="lid" type="email" placeholder="you@example.com" autocomplete="email" value="${esc(state.loginId)}">`}
        </div>
        <div class="err hide" id="lierr"></div>
        <button class="btn pri block" data-sendotp="1">Send me a code</button>
        <div class="hint center">No password. We text or email you a one-time code.</div>

        <div class="card accent mt24">
          <div class="row"><span style="font-size:22px">★</span>
            <div><b>${esc(L.programName)}</b><div class="xs muted">Free to join</div></div></div>
          <div class="perk mt8"><i>✓</i><span><b class="acc">${L.signupBonus} points</b> the moment you sign up</span></div>
          <div class="perk"><i>✓</i><span>${L.pointsPerHundred} points per ₹100 — <b>double on gaming time</b></span></div>
          <div class="perk"><i>✓</i><span>Up to <b>15% off</b> every booking as you climb tiers</span></div>
          <div class="perk"><i>✓</i><span>${L.referralBonus} points for you and your friend on every referral</span></div>
        </div>

        <div class="hint center mt16">Demo shortcut: sign in as <b class="acc">9999900001</b> to land in an account
          that already has spend history and a tier.</div>
      </div></div></section>`;
  }

  // ---------- REWARDS ----------
  function viewRewards() {
    const c = me();
    if (!c) return signInWall("Your rewards", "Track your points, tier and perks in one place.");
    const m = member();
    const L = db.settings.loyalty;
    const ledger = db.loyalty.filter((r) => r.customerId === c.id).sort((a, b) => b.at.localeCompare(a.at));
    const tiers = [...L.tiers].sort((a, b) => a.minSpend - b.minSpend);
    const tierCls = (id) => "t-" + id;

    return `<section class="section"><div class="wrap" style="max-width:860px">
      <div class="loyaltycard">
        <div class="row"><div>
          <div class="lbl">${esc(L.programName)}</div>
          <div class="tier">${esc(m.tier.name)} member</div>
        </div><span class="tierpill ${tierCls(m.tier.id)}" style="margin-left:auto">${esc(m.tier.name)}</span></div>

        <div class="row mt16" style="align-items:flex-end">
          <div><div class="lbl">Points balance</div><div class="pts">${m.points.toLocaleString("en-IN")}</div></div>
          <div style="margin-left:auto;text-align:right">
            <div class="lbl">Worth</div>
            <div style="font-family:var(--display);font-size:1.5rem;font-weight:700;color:var(--accent)">${E.fmt(m.valuePaise)}</div>
          </div>
        </div>

        <div class="mt16">
          ${m.next ? `<div class="row xs" style="color:var(--muted)">
              <span>${esc(m.tier.name)}</span><span style="margin-left:auto">${E.fmt(m.toNextPaise)} more to ${esc(m.next.name)}</span></div>
            <div class="bar mt8"><i style="width:${m.progress.toFixed(1)}%"></i></div>`
            : `<div class="xs" style="color:var(--accent-soft)">★ Top tier — you've maxed it out.</div>`}
        </div>
        <div class="xs mt16" style="color:var(--muted)">Lifetime spend ${E.fmt(c.spendPaise)} · ${c.visits} visits · ${(c.lifetimePoints || 0).toLocaleString("en-IN")} points earned all-time</div>
      </div>

      <div class="grid g2 mt16">
        <div class="card"><h3>Your ${esc(m.tier.name)} perks</h3>
          ${m.tier.perks.map((p) => `<div class="perk"><i>✓</i><span>${esc(p)}</span></div>`).join("")}
          ${m.next ? `<div class="mt16"><div class="xs dim" style="font-weight:800;letter-spacing:.08em;text-transform:uppercase">Unlocks at ${esc(m.next.name)}</div>
            ${m.next.perks.filter((p) => !m.tier.perks.includes(p)).map((p) => `<div class="perk off"><i>🔒</i><span>${esc(p)}</span></div>`).join("")}</div>` : ""}
        </div>

        <div class="card"><h3>How it works</h3>
          <div class="perk"><i>+</i><span>Earn <b>${L.pointsPerHundred} points per ₹100</b> on food, <b>${L.pointsPerHundred * L.gamingMultiplier} per ₹100</b> on gaming time</span></div>
          <div class="perk"><i>+</i><span>${m.tier.earnBonus ? `<b class="acc">+${m.tier.earnBonus}% bonus</b> on everything, as a ${esc(m.tier.name)} member` : "Climb a tier for bonus points on everything"}</span></div>
          <div class="perk"><i>₹</i><span>Redeem from <b>${L.minRedeemPoints} points</b> — 100 points = ${E.fmt(E.toPaise(L.rupeesPerPoint * 100))}</span></div>
          <div class="perk"><i>%</i><span>Points cover up to <b>${L.maxRedeemPercent}%</b> of any single bill</span></div>
          <div class="perk"><i>⏳</i><span>Points last ${L.expiryMonths} months from the day you earn them</span></div>
          <div class="hint">Points are spendable in the café only. They're not cash and can't be withdrawn.</div>
        </div>
      </div>

      <div class="card mt16"><h3>Refer a friend</h3>
        <p class="sm muted">You both get <b class="acc">${L.referralBonus} points</b> when they sign up and book.</p>
        <div class="row wrap gap8 mt8">
          <span class="refcode">${esc(c.referralCode)}</span>
          <button class="btn sm" data-copyref="${esc(c.referralCode)}">Copy code</button>
          <button class="btn sm ghost" data-shareref="${esc(c.referralCode)}">Share on WhatsApp</button>
        </div>
        ${!c.referredBy ? `<div class="field mt16" style="max-width:300px"><label class="f">Got a friend's code?</label>
          <div class="row gap8"><input id="refin" placeholder="ARNA7K2" style="text-transform:uppercase">
            <button class="btn" data-usref="1">Apply</button></div></div>`
          : `<div class="sm mt8" style="color:var(--ok)">✓ You joined with a friend's code — both of you got ${L.referralBonus} points.</div>`}
      </div>

      <div class="card mt16"><h3>All tiers</h3>
        <div class="tblwrap"><table class="tbl">
          <thead><tr><th>Tier</th><th>Lifetime spend</th><th>Discount</th><th>Bonus points</th></tr></thead>
          <tbody>${tiers.map((t) => `<tr style="${t.id === m.tier.id ? "background:var(--accent-wash)" : ""}">
            <td><span class="tierpill ${tierCls(t.id)}">${esc(t.name)}</span>${t.id === m.tier.id ? ' <span class="xs acc">you are here</span>' : ""}</td>
            <td class="sm mono">${E.fmt(E.toPaise(t.minSpend))}+</td>
            <td class="sm">${t.discountPercent ? `<b class="acc">${t.discountPercent}% off</b>` : "—"}</td>
            <td class="sm">${t.earnBonus ? `+${t.earnBonus}%` : "—"}</td></tr>`).join("")}
          </tbody></table></div></div>

      <div class="card mt16"><div class="row"><h3 style="margin:0">Points history</h3>
        <span class="xs dim" style="margin-left:auto">${ledger.length} entries</span></div>
        <div class="tblwrap mt8"><table class="tbl ledger">
          <tbody>${ledger.length ? ledger.slice(0, 40).map((r) => `<tr>
            <td class="sm">${esc(r.reason)}<br><span class="xs dim">${esc(r.at.replace("T", " "))}</span></td>
            <td class="right"><span class="amt ${r.delta > 0 ? "plus" : "minus"}">${r.delta > 0 ? "+" : ""}${r.delta}</span>
              <br><span class="xs dim">bal ${r.balanceAfter}</span></td></tr>`).join("")
            : `<tr><td class="muted sm">Nothing yet — your first booking will show up here.</td></tr>`}
        </tbody></table></div></div>
    </div></section>`;
  }

  // ---------- PROFILE ----------
  function viewProfile() {
    const c = me();
    if (!c) return signInWall("Your account", "Manage your details, contact preferences and data.");
    const m = member();
    return `<section class="section"><div class="wrap" style="max-width:520px">
      <h2>Your account</h2>
      <div class="card mt16">
        <div class="row"><div>
          <b style="font-size:1.1rem">${esc(c.name || "Add your name")}</b>
          <div class="sm muted">${esc(c.phone || "")}${c.phone && c.email ? " · " : ""}${esc(c.email || "")}</div>
        </div><span class="tierpill t-${m.tier.id}" style="margin-left:auto">${esc(m.tier.name)}</span></div>
      </div>

      <div class="card mt16">
        <div class="field"><label class="f" for="pn">Name</label><input id="pn" value="${esc(c.name || "")}" placeholder="Arnab Sen"></div>
        <div class="field"><label class="f" for="pp">Mobile</label><input id="pp" type="tel" maxlength="10" value="${esc(c.phone || "")}" placeholder="98300 00000"></div>
        <div class="field"><label class="f" for="pe">Email</label><input id="pe" type="email" value="${esc(c.email || "")}" placeholder="you@example.com"></div>
        <div class="field"><label class="f" for="pd">Date of birth</label><input id="pd" type="date" value="${esc(c.dob || "")}">
          <div class="hint">${c.dob ? "We'll send you a birthday reward." : `Add it and get ${db.settings.loyalty.birthdayBonus} points now.`}</div></div>
        <label class="check"><input type="checkbox" id="pm" ${c.marketingOptIn ? "checked" : ""}>
          <span class="sm">Send me offers and tournament news on WhatsApp and email</span></label>
        <button class="btn pri block mt16" data-saveprofile="1">Save changes</button>
      </div>

      <div class="card mt16">
        <div class="row"><span class="sm muted">Signed in as ${esc(c.phone || c.email)}</span>
          <button class="btn sm ghost" style="margin-left:auto" data-logout="1">Sign out</button></div>
      </div>

      <div class="card mt16"><h3>Your data</h3>
        <p class="sm muted">Download everything we hold about you, or ask us to delete it. Records attached to
          tax invoices are anonymised rather than erased, because we're required to keep those.</p>
        <div class="row wrap gap8">
          <button class="btn sm" data-exportme="1">⬇ Download my data</button>
          <button class="btn sm danger" data-deleteme="1">Delete my account</button>
        </div></div>
    </div></section>`;
  }

  // ---------- INFO ----------
  function viewInfo() {
    const B = db.settings.brand;
    return `<section class="section"><div class="wrap" style="max-width:760px">
      <h2>The fine print</h2>
      <div class="card mt16"><h3>Cancellation &amp; refunds</h3>
        <table class="tbl">${db.settings.refundPolicy.map((r) => `<tr><td class="sm">${r.minHoursBefore === 0 ? "Under 1 hour before" : `More than ${r.minHoursBefore} hours before`}</td>
          <td class="right"><b>${r.refundPercent}% back</b></td></tr>`).join("")}</table>
        <p class="sm muted">Refunds go back to the original payment method in 5–7 working days.</p></div>
      <div class="card mt16"><h3>Privacy</h3>
        <p class="sm muted">We keep your name, mobile number and booking history so we can hold your slot and send reminders.
        We don't sell it. Ask us and we'll export or delete your data — records attached to tax invoices are anonymised
        rather than deleted, because we're required to retain those.</p></div>
      <div class="card mt16"><h3>Gaming, honestly</h3>
        <p class="sm muted">We rent hardware time and sell food. There is no betting, wagering, staking or cash prize pool
        anywhere in this app, and loyalty credit can only be spent in the café — never withdrawn. Tournaments are
        fixed-format skill events with declared prizes.</p></div>
      <div class="card mt16"><h3>Contact</h3>
        <p class="sm">${esc(B.legalEntity)}<br>${esc(B.address)}<br>
        <a href="tel:${esc(B.phone)}">${esc(B.phone)}</a> · <a href="mailto:${esc(B.email)}">${esc(B.email)}</a></p></div>
      <div class="card mt16 xs dim">Demo build. Data lives only in this browser.
        <button class="btn xs danger mt8" data-reseed="1">Reset demo data</button></div>
    </div></section>`;
  }

  // ---------- bindings ----------
  function bind() {
    $$("[data-go]").forEach((b) => b.onclick = () => {
      if (b.dataset.closeme) $(".mask")?._close?.();
      go(b.dataset.go);
    });
    $$("[data-closeme]").forEach((b) => b.onclick = b.onclick || (() => $(".mask")?._close?.()));
    $$("[data-type]").forEach((b) => b.onclick = () => {
      state.stationTypeId = b.dataset.type; state.pickedSlots = [];
      if (state.view !== "book") { go("book"); state.step = 1; }
      render();
    });
    $$("[data-count]").forEach((b) => b.onclick = () => { state.stationCount = +b.dataset.count; state.pickedSlots = []; render(); });
    $$("[data-step]").forEach((b) => b.onclick = () => {
      const n = +b.dataset.step;
      if (n === 4) {
        const hrs = state.pickedSlots.length * (db.settings.booking.slotMinutes / 60);
        if (hrs < db.settings.booking.minHours) return toast(`Minimum ${db.settings.booking.minHours} hour.`, "bad");
        if (hrs > db.settings.booking.maxHours) return toast(`Maximum ${db.settings.booking.maxHours} hours.`, "bad");
      }
      state.step = n; render();
    });
    $$("[data-date]").forEach((b) => b.onclick = () => { state.dateStr = b.dataset.date; state.pickedSlots = []; state.step = 3; render(); });
    $$("[data-slot]").forEach((b) => b.onclick = () => {
      const s = b.dataset.slot;
      const i = state.pickedSlots.indexOf(s);
      if (i >= 0) state.pickedSlots.splice(i, 1); else state.pickedSlots.push(s);
      const hrs = state.pickedSlots.length * (db.settings.booking.slotMinutes / 60);
      if (hrs > db.settings.booking.maxHours) { state.pickedSlots.pop(); toast(`Maximum ${db.settings.booking.maxHours} hours per booking.`, "warn"); }
      render();
    });
    $$("[data-clear]").forEach((b) => b.onclick = () => { state.pickedSlots = []; render(); });
    $$("[data-addon]").forEach((c) => c.onchange = () => {
      const id = c.dataset.addon;
      if (c.checked) state.addonIds.push(id); else state.addonIds = state.addonIds.filter((x) => x !== id);
      render();
    });
    $$("[data-applycpn]").forEach((b) => b.onclick = () => { state.coupon = $("#cpn").value.trim().toUpperCase(); render(); });
    $$("[data-pay]").forEach((b) => b.onclick = () => doPay(b.dataset.pay));
    $$("[data-add]").forEach((b) => b.onclick = () => {
      const id = b.dataset.add;
      state.cart[id] = (state.cart[id] || 0) + 1;
      const it = db.menuItems.find((m) => m.id === id);
      toast(`${it.name} added`, "ok");
      if (state.view === "menu") render(); else renderCartBar();
    });
    $$("[data-dec]").forEach((b) => b.onclick = () => {
      const id = b.dataset.dec;
      state.cart[id]--; if (state.cart[id] <= 0) delete state.cart[id];
      render();
    });
    $$("[data-diet]").forEach((b) => b.onclick = () => { state.dietFilter = b.dataset.diet; render(); });
    $$("[data-cat]").forEach((b) => b.onclick = () => { state.menuCat = b.dataset.cat; render(); });
    // ---- auth ----
    $$("[data-lmode]").forEach((b) => b.onclick = () => { state.loginMode = b.dataset.lmode; state.loginId = ""; render(); });
    $$("[data-sendotp]").forEach((b) => b.onclick = () => {
      const val = $("#lid").value;
      const r = Store.startLogin(db, val);
      const e = $("#lierr");
      if (!r.ok) { e.className = "err"; e.textContent = r.error; return; }
      save();
      state.loginId = r.identifier; state.loginDemoCode = r.demo ? r.code : "";
      state.loginStep = 2; render();
      toast(r.isEmail ? "Code sent to your email" : "Code sent by SMS", "ok");
    });
    $$("[data-loginback]").forEach((b) => b.onclick = () => { state.loginStep = 1; state.loginDemoCode = ""; render(); });
    $$("[data-resend]").forEach((b) => b.onclick = () => {
      const r = Store.startLogin(db, state.loginId); save();
      state.loginDemoCode = r.demo ? r.code : ""; render(); toast("New code sent", "ok");
    });
    $$("[data-autofill]").forEach((b) => b.onclick = () => {
      const boxes = $$("[data-otp]");
      state.loginDemoCode.split("").forEach((d, i) => { if (boxes[i]) boxes[i].value = d; });
      doVerify();
    });
    // OTP boxes: auto-advance, paste support, submit on complete
    $$("[data-otp]").forEach((inp, i, all) => {
      inp.oninput = () => {
        const v = inp.value.replace(/\D/g, "");
        if (v.length > 1) { v.split("").forEach((d, k) => { if (all[i + k]) all[i + k].value = d; }); }
        else inp.value = v;
        if (v && all[i + 1]) all[i + 1].focus();
        if (all.every((x) => x.value)) doVerify();
      };
      inp.onkeydown = (e) => { if (e.key === "Backspace" && !inp.value && all[i - 1]) all[i - 1].focus(); };
    });
    if ($$("[data-otp]").length) setTimeout(() => $$("[data-otp]")[0].focus(), 80);
    $$("[data-verify]").forEach((b) => b.onclick = doVerify);
    $$("[data-logout]").forEach((b) => b.onclick = () => {
      Store.logout(db); save(); state.redeem = 0; state.cartRedeem = 0;
      toast("Signed out", "ok"); go("home");
    });
    $$("[data-saveprofile]").forEach((b) => b.onclick = () => {
      Store.updateProfile(db, {
        name: $("#pn").value.trim(), phone: $("#pp").value.replace(/\D/g, ""),
        email: $("#pe").value.trim(), dob: $("#pd").value, marketingOptIn: $("#pm").checked,
      });
      save(); toast("Saved", "ok"); render();
    });
    $$("[data-exportme]").forEach((b) => b.onclick = () => {
      const c = me();
      const data = {
        profile: c,
        bookings: db.bookings.filter((x) => x.customerId === c.id),
        orders: db.orders.filter((x) => x.customerId === c.id),
        loyalty: db.loyalty.filter((x) => x.customerId === c.id),
      };
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
      const a = document.createElement("a"); a.href = URL.createObjectURL(blob);
      a.download = "my-respawn-data.json"; a.click();
      toast("Your data has been downloaded", "ok");
    });
    $$("[data-deleteme]").forEach((b) => b.onclick = () => {
      if (!confirm("Delete your account?\n\nBookings tied to tax invoices are anonymised, not erased.")) return;
      const c = me();
      c.name = "Deleted user"; c.phone = ""; c.email = ""; c.dob = ""; c.points = 0; c.deletedAt = E.localISO(new Date());
      Store.logout(db); save(); toast("Account deleted", "ok"); go("home");
    });
    // ---- loyalty ----
    $$("[data-copyref]").forEach((b) => b.onclick = () => {
      const code = b.dataset.copyref;
      if (navigator.clipboard) navigator.clipboard.writeText(code).catch(() => {});
      toast("Code " + code + " copied", "ok");
    });
    $$("[data-shareref]").forEach((b) => b.onclick = () => {
      const code = b.dataset.shareref;
      const txt = `Come game at ${db.settings.brand.name}! Use my code ${code} when you sign up and we both get ${db.settings.loyalty.referralBonus} points.`;
      const url = "https://wa.me/?text=" + encodeURIComponent(txt);
      if (typeof window !== "undefined" && window.open) window.open(url, "_blank");
    });
    $$("[data-usref]").forEach((b) => b.onclick = () => {
      const r = Store.applyReferral(db, me().id, $("#refin").value);
      save();
      toast(r.ok ? `+${r.points} points for you both!` : r.error, r.ok ? "ok" : "bad");
      render();
    });
    $$("[data-applyrdm]").forEach((b) => b.onclick = () => {
      state.redeem = Math.max(0, parseInt($("#rdm").value || "0", 10)); render();
    });
    $$("[data-clearrdm]").forEach((b) => b.onclick = () => { state.redeem = 0; render(); });
    $$("[data-inv]").forEach((b) => b.onclick = () => showInvoice(b.dataset.inv));
    $$("[data-cancel]").forEach((b) => b.onclick = () => {
      const id = b.dataset.cancel;
      const bk = db.bookings.find((x) => x.id === id);
      const rf = E.refundFor(bk.startAt, E.localISO(new Date()), bk.paidPaise, db.settings);
      const m = modal("Cancel this booking?", `
        <p class="sm">${esc(bk.code)} · ${nice(bk.startAt)}</p>
        <div class="card"><table class="tbl">
          <tr><td class="sm">You paid</td><td class="right mono sm">${E.fmt(bk.paidPaise)}</td></tr>
          <tr><td class="sm">Time to session</td><td class="right sm">${rf.hoursLeft.toFixed(1)} hours</td></tr>
          <tr><td class="sm">Refund band</td><td class="right sm"><b>${rf.percent}%</b></td></tr>
          <tr><td><b>You get back</b></td><td class="right"><b class="mono" style="color:${rf.refundPaise ? "var(--ok)" : "var(--bad)"}">${E.fmt(rf.refundPaise)}</b></td></tr>
        </table></div>
        <button class="btn danger block mt16" id="cyes">Yes, cancel it</button>
        <button class="btn block mt8 ghost" data-closeme="1">Keep my booking</button>`);
      $("#cyes", m).onclick = () => {
        const r = Store.cancelBooking(db, id, "Cancelled by customer"); save(); m._close();
        toast(r.refund.refundPaise ? `Cancelled. ${E.fmt(r.refund.refundPaise)} refunded.` : "Cancelled.", "ok");
        render();
      };
      $$("[data-closeme]", m).forEach((x) => x.onclick = () => m._close());
    });
    $$("[data-extend]").forEach((b) => b.onclick = () => {
      const r = Store.extendBooking(db, b.dataset.extend, 30); save();
      toast(r.ok ? `Extended 30 min · ${E.fmt(r.addedPaise)} added to your bill` : r.error, r.ok ? "ok" : "bad");
      render();
    });
    $$("[data-waitlist]").forEach((b) => b.onclick = () => needIdentity(() => {
      Store.joinWaitlist(db, { name: me().name, phone: me().phone, startISO: state.dateStr + "T00:00", stationTypeId: state.stationTypeId, partySize: state.stationCount });
      save(); toast("On the waitlist — we'll message you if a slot frees up.", "ok");
    }));
    $$("[data-reseed]").forEach((b) => b.onclick = () => {
      if (!confirm("Wipe and regenerate all demo data?")) return;
      db = Store.reset(CONFIG); toast("Demo data reset.", "ok"); render();
    });
  }

  // ---------- live refresh ----------
  setInterval(() => {
    const n = Store.expireHolds(db);
    if (n) { save(); if (state.view === "book" && state.step === 3) render(); }
  }, 20000);
  document.addEventListener("visibilitychange", () => { if (!document.hidden) render(); });

  route();
})();
