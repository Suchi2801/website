/* ============================================================
   SECTION 0 — BUSINESS INPUTS
   This is the ONLY file you need to edit to rebrand the app.
   Everything else reads from here (or from Admin → Settings,
   which overrides these once you save changes there).
   ============================================================ */
globalThis.CONFIG = {
  brand: {
    name: "Respawn Café",
    tagline: "Play hard. Eat harder.",
    city: "Kolkata",
    address: "12B Sarat Bose Road, Kolkata 700020",
    phone: "+91 98300 00000",
    whatsapp: "+91 98300 00000",
    email: "hello@respawncafe.in",
    instagram: "@respawncafe",
    upiId: "respawncafe@okhdfcbank",
    gstin: "",                    // leave "" if not yet registered
    fssai: "",                    // leave "" if applied
    invoicePrefix: "RC/2026-27/",
    legalEntity: "Respawn Hospitality Pvt Ltd",
  },

  booking: {
    slotMinutes: 60,              // 30 or 60
    minHours: 1,
    maxHours: 6,
    bufferMinutes: 5,             // cleanup gap after each session
    advanceDays: 14,              // how far ahead customers can book
    holdMinutes: 10,              // how long a slot is reserved during checkout
    noShowGraceMinutes: 15,
    minorCurfewHour: 20,          // under-18 cannot book starting after 20:00
  },

  // 0 = Sunday … 6 = Saturday
  hours: [
    { day: 0, open: "11:00", close: "23:00", closed: false },
    { day: 1, open: "11:00", close: "23:00", closed: false },
    { day: 2, open: "11:00", close: "23:00", closed: false },
    { day: 3, open: "11:00", close: "23:00", closed: false },
    { day: 4, open: "11:00", close: "23:00", closed: false },
    { day: 5, open: "11:00", close: "23:59", closed: false },
    { day: 6, open: "10:00", close: "23:59", closed: false },
  ],

  // rateaise = ₹ per hour. Stored in paise everywhere internally.
  stationTypes: [
    { id: "pc",  name: "Gaming PC",  hourly: 80,  seats: 1, count: 8,
      specs: "RTX 4060 · i5-13400F · 16GB · 165Hz 1080p · Mechanical KB",
      icon: "🖥️" },
    { id: "ps5", name: "PlayStation 5", hourly: 150, seats: 4, count: 2,
      specs: "PS5 Slim · 55\" 4K 120Hz · 4 DualSense controllers",
      icon: "🎮" },
    { id: "sim", name: "Racing Sim", hourly: 250, seats: 1, count: 1,
      specs: "Logitech G Pro wheel · load-cell pedals · triple 27\" · bucket seat",
      icon: "🏎️" },
    { id: "vr",  name: "VR Arena", hourly: 300, seats: 2, count: 1,
      specs: "Meta Quest 3 · 4m × 4m tracked play space · staff supervised",
      icon: "🥽" },
  ],

  // Rules stack by priority (higher wins/applies last).
  pricingRules: [
    { id: "peak-eve", label: "Evening Peak", scope: "*", days: [0,1,2,3,4,5,6],
      from: "18:00", to: "23:59", type: "PERCENT", value: 25, priority: 10 },
    { id: "peak-wknd", label: "Weekend Surcharge", scope: "*", days: [0,6],
      from: "00:00", to: "23:59", type: "PERCENT", value: 15, priority: 5 },
    { id: "happy", label: "Happy Hour", scope: "*", days: [1,2,3,4,5],
      from: "12:00", to: "15:00", type: "PERCENT", value: -30, priority: 20 },
  ],

  addons: [
    { id: "ctrl",  name: "Extra controller", price: 30 },
    { id: "coach", name: "30-min coaching",  price: 200 },
    { id: "hs",    name: "Premium headset",  price: 40 },
  ],

  payments: {
    // "FULL" = must pay online, "DEPOSIT" = pay part now, "COUNTER" = allowed to pay at venue
    policy: "FULL",
    depositPercent: 30,
    allowPayAtCounter: true,
    allowManualUpi: true,
    gateway: "MOCK",              // MOCK | RAZORPAY  (Razorpay needs real keys + a server)
    razorpayKeyId: "",
  },

  // Refund = percent of amount paid, by hours remaining before session start
  refundPolicy: [
    { minHoursBefore: 4, refundPercent: 100 },
    { minHoursBefore: 1, refundPercent: 50 },
    { minHoursBefore: 0, refundPercent: 0 },
  ],

  tax: {
    registered: true,             // false → invoices show no tax lines
    foodPercent: 5,               // restaurant service, no input tax credit
    gamingPercent: 18,            // recreational service
    interState: false,            // false → split CGST/SGST
  },


  /* ---------- LOYALTY PROGRAM ---------- */
  loyalty: {
    enabled: true,
    programName: "Respawn Rewards",
    pointsPerHundred: 5,        // earn 5 points per ₹100 spent
    gamingMultiplier: 2,        // gaming time earns double
    rupeesPerPoint: 0.5,        // redeeming: 1 point = ₹0.50  (100 pts = ₹50)
    minRedeemPoints: 100,       // can't redeem below this
    maxRedeemPercent: 25,       // points can't wipe more than 25% of a bill
    signupBonus: 100,
    referralBonus: 200,         // both sides get this
    birthdayBonus: 250,
    expiryMonths: 12,
    // Tier is decided by lifetime spend. Member discount applies automatically.
    tiers: [
      { id: "bronze",   name: "Bronze",   minSpend: 0,     discountPercent: 0,  earnBonus: 0,
        perks: ["Earn points on everything", "Booking reminders on WhatsApp"] },
      { id: "silver",   name: "Silver",   minSpend: 3000,  discountPercent: 5,  earnBonus: 10,
        perks: ["5% off every booking", "10% bonus points", "Free controller add-on"] },
      { id: "gold",     name: "Gold",     minSpend: 10000, discountPercent: 10, earnBonus: 25,
        perks: ["10% off every booking", "25% bonus points", "1 free hour every month", "Skip the walk-in queue"] },
      { id: "platinum", name: "Platinum", minSpend: 25000, discountPercent: 15, earnBonus: 50,
        perks: ["15% off every booking", "50% bonus points", "2 free hours every month", "Priority booking window", "Free birthday session"] },
    ],
  },

  auth: {
    allowPhone: true,
    allowEmail: true,
    otpLength: 6,
    otpValidMinutes: 10,
    // Demo build: the code is shown on screen instead of being sent.
    // Production sends SMS via MSG91/Fast2SMS (DLT-registered) or email.
    showOtpOnScreen: true,
  },

  tables: 12,

  menu: [
    { cat: "Quick Bites", items: [
      { name: "Loaded Nachos",        price: 180, diet: "VEG", prep: 8,  desc: "Cheese sauce, jalapeño, salsa, sour cream" },
      { name: "Peri Peri Fries",      price: 120, diet: "VEG", prep: 6,  desc: "Hand-cut, tossed in peri peri" },
      { name: "Chicken Popcorn",      price: 190, diet: "NON_VEG", prep: 10, desc: "Buttermilk-brined, crisp fried" },
      { name: "Paneer Chilli Dry",    price: 210, diet: "VEG", prep: 12, desc: "Indo-Chinese, sticky and hot" },
      { name: "Chicken Momo (8pc)",   price: 160, diet: "NON_VEG", prep: 12, desc: "Steamed, with schezwan chutney" },
    ]},
    { cat: "Burgers & Wraps", items: [
      { name: "Respawn Chicken Burger", price: 240, diet: "NON_VEG", prep: 14, desc: "Double patty, cheddar, smoked mayo", bestseller: true },
      { name: "Aloo Tikki Burger",      price: 150, diet: "VEG", prep: 10, desc: "Spiced potato patty, mint mayo" },
      { name: "Paneer Tikka Wrap",      price: 200, diet: "VEG", prep: 12, desc: "Tandoori paneer, onion, pudina" },
      { name: "Egg Roll",               price: 130, diet: "EGG", prep: 8,  desc: "Kolkata style, double egg" },
    ]},
    { cat: "Pizza", items: [
      { name: "Margherita (8\")",     price: 220, diet: "VEG", prep: 16, desc: "San Marzano, mozzarella, basil" },
      { name: "Chicken Tikka (8\")",  price: 290, diet: "NON_VEG", prep: 18, desc: "Tikka chunks, onion, coriander" },
      { name: "Farmhouse (8\")",      price: 260, diet: "VEG", prep: 16, desc: "Capsicum, corn, olive, mushroom" },
    ]},
    { cat: "Rice & Noodles", items: [
      { name: "Chicken Fried Rice",   price: 210, diet: "NON_VEG", prep: 14, desc: "Wok-tossed, spring onion" },
      { name: "Hakka Noodles",        price: 180, diet: "VEG", prep: 12, desc: "Classic, garlic-forward" },
      { name: "Chilli Garlic Maggi",  price: 110, diet: "VEG", prep: 7,  desc: "The gamer default", bestseller: true },
    ]},
    { cat: "Coffee & Cold", items: [
      { name: "Cold Coffee",          price: 130, diet: "VEG", prep: 5,  desc: "Thick, double shot" },
      { name: "Cappuccino",           price: 110, diet: "VEG", prep: 4,  desc: "Single origin, Chikmagalur" },
      { name: "Iced Americano",       price: 120, diet: "VEG", prep: 4,  desc: "Long black over ice" },
      { name: "Masala Chai",          price: 40,  diet: "VEG", prep: 5,  desc: "Cutting or full" },
      { name: "Blue Lagoon Soda",     price: 90,  diet: "VEG", prep: 3,  desc: "House cooler" },
    ]},
    { cat: "Energy & Shakes", items: [
      { name: "Red Bull",             price: 130, diet: "VEG", prep: 1,  desc: "Chilled, 250ml" },
      { name: "Oreo Shake",           price: 180, diet: "VEG", prep: 6,  desc: "Thick, spoon required" },
      { name: "Mango Lassi",          price: 140, diet: "VEG", prep: 5,  desc: "Seasonal, thick set curd" },
    ]},
  ],

  coupons: [
    { code: "FIRST50",  type: "PERCENT", value: 50, maxDiscount: 100, appliesTo: "BOTH",   minSpend: 200, note: "50% off first booking, max ₹100" },
    { code: "WEEKDAY20",type: "PERCENT", value: 20, maxDiscount: 150, appliesTo: "GAMING", minSpend: 0,   note: "20% off Mon–Fri gaming" },
    { code: "FOOD30",   type: "FLAT",    value: 30, maxDiscount: 30,  appliesTo: "FOOD",   minSpend: 250, note: "₹30 off food over ₹250" },
  ],

  theme: {
    accent: "#22d3ee",      // gaming cyan
    accentFood: "#f59e0b",  // cafeteria amber
  },
};
