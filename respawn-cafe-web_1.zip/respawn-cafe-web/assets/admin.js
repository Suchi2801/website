/* ============================================================
   ADMIN · KDS · POS · REPORTS
   ============================================================ */
(function () {
  "use strict";
  const E = Engine, $ = (s, r = document) => r.querySelector(s), $$ = (s, r = document) => [...r.querySelectorAll(s)];
  let db = Store.load(CONFIG);
  const save = () => Store.save(db);

  const state = {
    view: "dash", bkFilter: { date: "", status: "ALL", q: "" }, pos: {}, posType: "DINE_IN",
    reportRange: 30,
  };

  const toast = (m, k = "") => {
    const t = document.createElement("div"); t.className = "toast " + k; t.textContent = m;
    $("#toasts").appendChild(t); setTimeout(() => t.remove(), 3200);
  };
  const esc = (s) => String(s ?? "").replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
  const today = () => E.dateKey(new Date());
  const now = () => E.localISO(new Date());
  const st = (id) => db.settings.stationTypes.find((t) => t.id === id);
  const nice = (iso) => iso ? iso.replace("T", " ") : "—";

  function modal(title, html) {
    const m = document.createElement("div"); m.className = "mask";
    m.innerHTML = `<div class="modal"><div class="mh"><h3>${esc(title)}</h3><button class="x">&times;</button></div><div class="mb">${html}</div></div>`;
    const close = () => { m.remove(); document.body.style.overflow = ""; };
    m.addEventListener("click", (e) => { if (e.target === m || e.target.classList.contains("x")) close(); });
    document.body.appendChild(m); document.body.style.overflow = "hidden"; m._close = close; return m;
  }

  const BADGE = {
    CONFIRMED: "b-ok", HELD: "b-held", PENDING_PAYMENT: "b-warn", IN_PROGRESS: "b-info",
    CHECKED_IN: "b-info", COMPLETED: "b-dim", CANCELLED: "b-bad", NO_SHOW: "b-bad", EXPIRED: "b-dim",
    PLACED: "b-warn", ACCEPTED: "b-info", PREPARING: "b-info", READY: "b-ok", SERVED: "b-dim",
  };
  const badge = (s) => `<span class="badge ${BADGE[s] || "b-dim"}">${esc(String(s).replace(/_/g, " ").toLowerCase())}</span>`;

  // ---------------- aggregates ----------------
  function dayStats(dateStr) {
    const bk = db.bookings.filter((b) => b.startAt.startsWith(dateStr) && !["CANCELLED", "EXPIRED"].includes(b.status));
    const od = db.orders.filter((o) => o.placedAt.startsWith(dateStr) && o.status !== "CANCELLED");
    const gaming = bk.reduce((a, b) => a + b.totalPaise, 0);
    const food = od.reduce((a, o) => a + o.totalPaise, 0);
    const cancels = db.bookings.filter((b) => b.startAt.startsWith(dateStr) && b.status === "CANCELLED").length;
    const noshow = db.bookings.filter((b) => b.startAt.startsWith(dateStr) && b.status === "NO_SHOW").length;
    const refunds = db.refunds.filter((r) => r.at.startsWith(dateStr)).reduce((a, r) => a + r.amountPaise, 0);
    const disc = bk.reduce((a, b) => a + b.discountPaise, 0) + od.reduce((a, o) => a + o.discountPaise, 0);
    const bookedHours = db.bookingStations.filter((r) => r.startAt.startsWith(dateStr)).reduce((a, r) => a + E.diffMin(r.startAt, r.endAt) / 60, 0);
    const slots = E.slotsForDate(dateStr, db.settings).length;
    const capacity = slots * db.stations.length * (db.settings.booking.slotMinutes / 60);
    const pay = (m) => [...db.payments.filter((p) => p.at.startsWith(dateStr) && p.method === m && p.status === "CAPTURED")].reduce((a, p) => a + p.amountPaise, 0);
    return {
      date: dateStr, bookings: bk.length, orders: od.length, gaming, food, total: gaming + food,
      cancels, noshow, refunds, disc, util: capacity ? (bookedHours / capacity) * 100 : 0,
      cash: pay("CASH"), upi: pay("UPI") + pay("UPI_QR_MANUAL"), card: pay("CARD"),
    };
  }

  function liveStations() {
    const n = now();
    return db.stations.map((s) => {
      const bs = db.bookingStations.find((r) => {
        if (r.stationId !== s.id) return false;
        const b = db.bookings.find((x) => x.id === r.bookingId);
        return b && E.BLOCKING.includes(b.status) && r.startAt <= n && r.endAt > n;
      });
      const bk = bs && db.bookings.find((x) => x.id === bs.bookingId);
      return { s, bs, bk, state: s.status === "MAINTENANCE" ? "maint" : bs ? "busy" : "free" };
    });
  }

  // ---------------- router ----------------
  const NAV = [
    ["OPERATIONS", null],
    ["dash", "◱ Dashboard"], ["floor", "▦ Floor &amp; sessions"], ["bookings", "🎟 Bookings"],
    ["orders", "🍔 Orders"], ["kds", "🔥 Kitchen display"], ["pos", "🧾 Counter POS"],
    ["SETUP", null],
    ["menu", "📋 Menu manager"], ["stations", "🖥 Stations &amp; rates"], ["customers", "👥 Customers"],
    ["loyalty", "★ Loyalty program"],
    ["INSIGHT", null],
    ["reports", "📊 Reports &amp; Excel"], ["payments", "💳 Payments"], ["audit", "🗒 Audit log"],
    ["settings", "⚙ Settings"],
  ];

  function go(v) { location.hash = "#" + v; }
  window.addEventListener("hashchange", () => { state.view = (location.hash || "#dash").slice(1); render(); });

  function render() {
    Store.expireHolds(db); save();
    $("#side").innerHTML = `<div class="lg">🎮 ${esc(db.settings.brand.name)}<div class="xs dim" style="font-weight:400">Staff console</div></div>` +
      NAV.map(([k, l]) => l === null ? `<div class="sec">${k}</div>` : `<a href="#${k}" class="${state.view === k ? "on" : ""}">${l}</a>`).join("") +
      `<div class="sec">&nbsp;</div><a href="index.html">↩ Customer site</a>`;
    const v = state.view;
    const map = {
      dash: viewDash, floor: viewFloor, bookings: viewBookings, orders: viewOrders, kds: viewKds,
      pos: viewPos, menu: viewMenu, stations: viewStations, customers: viewCustomers, loyalty: viewLoyalty,
      reports: viewReports, payments: viewPayments, audit: viewAudit, settings: viewSettings,
    };
    $("#main").innerHTML = (map[v] || viewDash)();
    bind();
  }

  // ---------------- DASHBOARD ----------------
  function viewDash() {
    const t = dayStats(today());
    const y = dayStats(E.dateKey(new Date(Date.now() - 86400000)));
    const ls = liveStations();
    const busy = ls.filter((x) => x.state === "busy").length;
    const pend = db.payments.filter((p) => p.status === "AWAITING_VERIFICATION");
    const upcoming = db.bookings.filter((b) => b.startAt > now() && ["CONFIRMED", "PENDING_PAYMENT"].includes(b.status))
      .sort((a, b) => a.startAt.localeCompare(b.startAt)).slice(0, 6);
    const kitchen = db.orders.filter((o) => ["PLACED", "ACCEPTED", "PREPARING"].includes(o.status));
    const delta = (a, b) => { if (!b) return ""; const d = ((a - b) / b) * 100; return `<span class="xs" style="color:${d >= 0 ? "var(--ok)" : "var(--bad)"}">${d >= 0 ? "▲" : "▼"} ${Math.abs(d).toFixed(0)}% vs yesterday</span>`; };

    return `<div class="ahead"><h2>Today · ${new Date().toDateString()}</h2>
      <button class="btn sm" style="margin-left:auto" data-x="reports">Reports →</button></div>
    <div class="grid g4">
      <div class="stat"><div class="k">Total revenue</div><div class="v">${E.fmt(t.total)}</div><div class="d">${delta(t.total, y.total)}</div></div>
      <div class="stat"><div class="k">Gaming</div><div class="v" style="color:var(--accent)">${E.fmt(t.gaming)}</div><div class="d">${t.bookings} bookings</div></div>
      <div class="stat"><div class="k">Kitchen</div><div class="v" style="color:var(--food)">${E.fmt(t.food)}</div><div class="d">${t.orders} orders</div></div>
      <div class="stat"><div class="k">Occupied now</div><div class="v">${busy}<span class="dim" style="font-size:.6em">/${db.stations.length}</span></div><div class="d">${t.util.toFixed(0)}% booked today</div></div>
    </div>

    ${pend.length ? `<div class="card mt16" style="border-color:var(--warn)">
      <b>⚠ ${pend.length} manual UPI payment${pend.length > 1 ? "s" : ""} awaiting your check</b>
      <table class="tbl mt8">${pend.map((p) => {
        const b = db.bookings.find((x) => x.id === p.bookingId);
        return `<tr><td class="mono sm">${esc(b?.code || "-")}</td><td class="sm">${esc(b?.guestName || "")}</td>
          <td class="sm mono">UTR ${esc(p.utr || "?")}</td><td class="right mono sm">${E.fmt(p.amountPaise)}</td>
          <td class="right"><button class="btn xs pri" data-verify="${p.id}">Verify</button></td></tr>`;
      }).join("")}</table></div>` : ""}

    <div class="grid g2 mt16">
      <div class="card"><div class="row"><h3 style="margin:0">Next up</h3>
        <button class="btn xs ghost" style="margin-left:auto" data-x="bookings">All</button></div>
        <table class="tbl mt8">${upcoming.length ? upcoming.map((b) => `<tr>
          <td class="mono sm">${esc(b.code)}</td>
          <td class="sm">${esc(b.guestName)}<br><span class="xs dim">${esc(st(b.stationTypeId).name)}</span></td>
          <td class="sm mono">${E.hhmm(b.startAt)}</td>
          <td>${badge(b.status)}</td>
          <td class="right"><button class="btn xs pri" data-checkin="${b.id}">Check in</button></td></tr>`).join("")
          : `<tr><td class="muted sm">Nothing booked ahead.</td></tr>`}</table></div>

      <div class="card"><div class="row"><h3 style="margin:0">Kitchen queue</h3>
        <button class="btn xs ghost" style="margin-left:auto" data-x="kds">KDS →</button></div>
        <table class="tbl mt8">${kitchen.length ? kitchen.slice(0, 7).map((o) => `<tr>
          <td class="mono sm">${esc(o.code)}</td><td class="sm">${o.type === "IN_SESSION" ? "To station" : esc(o.tableId || o.type)}</td>
          <td>${badge(o.status)}</td><td class="right mono sm">${E.fmt(o.totalPaise)}</td></tr>`).join("")
          : `<tr><td class="muted sm">Kitchen is clear.</td></tr>`}</table></div>
    </div>

    <div class="card mt16"><div class="row"><h3 style="margin:0">Floor</h3>
      <span class="xs dim" style="margin-left:auto">tap a station to change its status</span></div>
      <div class="floor mt16">${ls.map((x) => `<div class="fst ${x.state}" data-station="${x.s.id}">
        <div class="id">${esc(x.s.label)}</div>
        <div class="st">${x.state === "maint" ? "Repair" : x.state === "busy" ? "In use" : "Free"}</div>
        ${x.bk ? `<div class="xs dim">${esc(x.bk.guestName.split(" ")[0])} · till ${E.hhmm(x.bs.endAt)}</div>` : ""}
        ${x.s.status === "MAINTENANCE" ? `<div class="xs dim">${esc(x.s.maintenanceNote || "")}</div>` : ""}
      </div>`).join("")}</div></div>

    <div class="grid g4 mt16">
      <div class="stat"><div class="k">Cash</div><div class="v" style="font-size:1.2rem">${E.fmt(t.cash)}</div></div>
      <div class="stat"><div class="k">UPI</div><div class="v" style="font-size:1.2rem">${E.fmt(t.upi)}</div></div>
      <div class="stat"><div class="k">Card</div><div class="v" style="font-size:1.2rem">${E.fmt(t.card)}</div></div>
      <div class="stat"><div class="k">Cancels / no-shows</div><div class="v" style="font-size:1.2rem">${t.cancels} / ${t.noshow}</div></div>
    </div>`;
  }

  // ---------------- FLOOR ----------------
  function viewFloor() {
    const ls = liveStations();
    const live = ls.filter((x) => x.bk);
    return `<div class="ahead"><h2>Floor &amp; live sessions</h2></div>
    <div class="floor">${ls.map((x) => `<div class="fst ${x.state}" data-station="${x.s.id}">
      <div class="id">${esc(x.s.label)}</div><div class="st">${x.state === "maint" ? "Repair" : x.state === "busy" ? "In use" : "Free"}</div>
      ${x.bk ? `<div class="xs dim">${esc(x.bk.guestName)}<br>till ${E.hhmm(x.bs.endAt)}</div>` : ""}</div>`).join("")}</div>

    <h3 class="mt24">Running now (${live.length})</h3>
    <div class="card pad0"><table class="tbl">
      <thead><tr><th>Code</th><th>Guest</th><th>Station</th><th>Ends</th><th>Left</th><th>Due</th><th></th></tr></thead>
      <tbody>${live.length ? live.map((x) => {
        const left = E.diffMin(now(), x.bs.endAt);
        const due = x.bk.totalPaise - x.bk.paidPaise;
        return `<tr><td class="mono sm">${esc(x.bk.code)}</td><td class="sm">${esc(x.bk.guestName)}<br><span class="xs dim">${esc(x.bk.guestPhone)}</span></td>
          <td class="sm">${esc(x.s.label)}</td><td class="mono sm">${E.hhmm(x.bs.endAt)}</td>
          <td class="sm"><b style="color:${left < 15 ? "var(--warn)" : "var(--txt)"}">${left} min</b></td>
          <td class="mono sm">${due > 0 ? `<span style="color:var(--warn)">${E.fmt(due)}</span>` : "paid"}</td>
          <td class="right nowrap"><button class="btn xs" data-ext="${x.bk.id}">+30m</button>
            <button class="btn xs ghost" data-checkout="${x.bk.id}">End</button></td></tr>`;
      }).join("") : `<tr><td colspan="7" class="muted sm">Nobody playing right now.</td></tr>`}</tbody></table></div>`;
  }

  // ---------------- BOOKINGS ----------------
  function viewBookings() {
    const f = state.bkFilter;
    let rows = [...db.bookings];
    if (f.date) rows = rows.filter((b) => b.startAt.startsWith(f.date));
    if (f.status !== "ALL") rows = rows.filter((b) => b.status === f.status);
    if (f.q) {
      const q = f.q.toLowerCase();
      rows = rows.filter((b) => b.code.toLowerCase().includes(q) || (b.guestName || "").toLowerCase().includes(q) || (b.guestPhone || "").includes(q));
    }
    rows.sort((a, b) => b.startAt.localeCompare(a.startAt));
    const shown = rows.slice(0, 200);
    const sum = rows.reduce((a, b) => a + (["CANCELLED", "EXPIRED"].includes(b.status) ? 0 : b.totalPaise), 0);

    return `<div class="ahead"><h2>Bookings</h2>
      <button class="btn sm" style="margin-left:auto" data-newbooking="1">+ Walk-in booking</button>
      <button class="btn sm pri" data-xls="bookings">⬇ Excel (${rows.length})</button></div>

    <div class="card">
      <div class="row wrap gap8">
        <input type="date" id="fdate" value="${f.date}" style="max-width:170px">
        <select id="fstatus" style="max-width:190px">
          ${["ALL", "CONFIRMED", "PENDING_PAYMENT", "HELD", "IN_PROGRESS", "COMPLETED", "CANCELLED", "NO_SHOW", "EXPIRED"]
            .map((s) => `<option ${f.status === s ? "selected" : ""}>${s}</option>`).join("")}
        </select>
        <input type="text" id="fq" placeholder="Code, name or phone" value="${esc(f.q)}" style="max-width:230px">
        <button class="btn sm" data-clearf="1">Clear</button>
        <span class="sm muted" style="margin-left:auto">${rows.length} rows · ${E.fmt(sum)}</span>
      </div>
    </div>

    <div class="card pad0 mt16"><div class="tblwrap"><table class="tbl">
      <thead><tr><th>Code</th><th>When</th><th>Guest</th><th>Station</th><th>Src</th><th>Status</th>
        <th class="right">Total</th><th class="right">Paid</th><th></th></tr></thead>
      <tbody>${shown.map((b) => {
        const rws = db.bookingStations.filter((r) => r.bookingId === b.id);
        return `<tr><td class="mono sm">${esc(b.code)}</td>
          <td class="sm nowrap">${esc(b.startAt.split("T")[0])}<br><span class="xs dim">${E.hhmm(b.startAt)}–${E.hhmm(b.endAt)}</span></td>
          <td class="sm">${esc(b.guestName || "—")}<br><span class="xs dim">${esc(b.guestPhone || "")}</span></td>
          <td class="sm">${esc(st(b.stationTypeId)?.name || "")} ×${rws.length}<br><span class="xs dim">${rws.map((r) => esc(r.stationId)).join(", ")}</span></td>
          <td class="xs dim">${esc(b.source)}</td>
          <td>${badge(b.status)}</td>
          <td class="right mono sm">${E.fmt(b.totalPaise)}</td>
          <td class="right mono sm">${b.paidPaise < b.totalPaise ? `<span style="color:var(--warn)">${E.fmt(b.paidPaise)}</span>` : E.fmt(b.paidPaise)}</td>
          <td class="right nowrap">
            ${["CONFIRMED", "PENDING_PAYMENT"].includes(b.status) ? `<button class="btn xs pri" data-checkin="${b.id}">In</button>` : ""}
            ${b.status === "IN_PROGRESS" ? `<button class="btn xs" data-checkout="${b.id}">Out</button>` : ""}
            ${["CONFIRMED", "PENDING_PAYMENT", "HELD"].includes(b.status) ? `<button class="btn xs ghost" data-noshow="${b.id}">No-show</button>
              <button class="btn xs danger" data-cancel="${b.id}">✕</button>` : ""}
          </td></tr>`;
      }).join("")}</tbody></table></div>
      ${rows.length > 200 ? `<div class="center sm muted" style="padding:12px">Showing 200 of ${rows.length}. Narrow the filter or export to Excel.</div>` : ""}
    </div>`;
  }

  function newBookingModal() {
    const m = modal("Walk-in booking", `
      <div class="field"><label class="f">Guest name</label><input id="wn" placeholder="Walk-in"></div>
      <div class="field"><label class="f">Phone</label><input id="wp" type="tel" maxlength="10" placeholder="98300 00000"></div>
      <div class="row gap8">
        <div class="field grow"><label class="f">Station type</label>
          <select id="wt">${db.settings.stationTypes.map((t) => `<option value="${t.id}">${esc(t.name)} · ₹${t.hourly}/hr</option>`).join("")}</select></div>
        <div class="field" style="max-width:90px"><label class="f">How many</label><input id="wc" type="number" value="1" min="1" max="8"></div>
      </div>
      <div class="row gap8">
        <div class="field grow"><label class="f">Date</label><input id="wd" type="date" value="${today()}"></div>
        <div class="field" style="max-width:110px"><label class="f">Start</label><input id="wtime" type="time" value="${E.hhmm(now())}"></div>
        <div class="field" style="max-width:90px"><label class="f">Hours</label><input id="wh" type="number" value="1" min="1" max="8" step="0.5"></div>
      </div>
      <div class="field"><label class="f">Payment</label>
        <select id="wpay"><option value="CASH">Cash now</option><option value="UPI">UPI now</option><option value="CARD">Card now</option><option value="COUNTER">Unpaid — collect later</option></select></div>
      <div class="err hide" id="werr"></div>
      <button class="btn pri block" id="wgo">Create booking</button>`);
    $("#wgo", m).onclick = () => {
      const startISO = `${$("#wd", m).value}T${$("#wtime", m).value}`;
      const r = Store.holdBooking(db, {
        stationTypeId: $("#wt", m).value, stationCount: +$("#wc", m).value, startISO,
        hours: +$("#wh", m).value, name: $("#wn", m).value.trim() || "Walk-in",
        phone: $("#wp", m).value.replace(/\D/g, "") || "0000000000", source: "COUNTER", createdBy: "staff",
      });
      if (!r.ok) { const e = $("#werr", m); e.className = "err"; e.textContent = r.errors.join(" "); return; }
      const method = $("#wpay", m).value;
      if (method === "COUNTER") Store.markPayAtCounter(db, r.bookingId);
      else Store.confirmPayment(db, r.bookingId, { method, idempotencyKey: "pos_" + r.bookingId });
      save(); m._close(); toast("Booked " + r.code + " on " + r.stationIds.join(", "), "ok"); render();
    };
  }

  // ---------------- ORDERS + KDS ----------------
  function viewOrders() {
    const rows = [...db.orders].sort((a, b) => b.placedAt.localeCompare(a.placedAt)).slice(0, 150);
    return `<div class="ahead"><h2>Food orders</h2>
      <button class="btn sm pri" style="margin-left:auto" data-xls="orders">⬇ Excel</button></div>
    <div class="card pad0"><div class="tblwrap"><table class="tbl">
      <thead><tr><th>Order</th><th>Placed</th><th>Type</th><th>Where</th><th>Items</th><th>Status</th><th class="right">Total</th><th></th></tr></thead>
      <tbody>${rows.map((o) => {
        const items = db.orderItems.filter((i) => i.orderId === o.id);
        const next = { PLACED: "ACCEPTED", ACCEPTED: "PREPARING", PREPARING: "READY", READY: "SERVED", SERVED: "COMPLETED" }[o.status];
        return `<tr><td class="mono sm">${esc(o.code)}</td><td class="sm nowrap">${esc(nice(o.placedAt))}</td>
          <td class="xs dim">${esc(o.type)}</td><td class="sm">${esc(o.tableId || (o.bookingId ? "station" : "—"))}</td>
          <td class="sm">${items.slice(0, 3).map((i) => esc(i.qty + "× " + i.name)).join(", ")}${items.length > 3 ? ` +${items.length - 3}` : ""}</td>
          <td>${badge(o.status)}</td><td class="right mono sm">${E.fmt(o.totalPaise)}</td>
          <td class="right">${next ? `<button class="btn xs" data-adv="${o.id}|${next}">→ ${next.toLowerCase()}</button>` : ""}</td></tr>`;
      }).join("")}</tbody></table></div></div>`;
  }

  function viewKds() {
    const q = db.orders.filter((o) => ["PLACED", "ACCEPTED", "PREPARING", "READY"].includes(o.status))
      .sort((a, b) => a.placedAt.localeCompare(b.placedAt));
    return `<div class="ahead"><h2>Kitchen display</h2>
      <span class="sm muted">${q.length} active · auto-refreshes</span>
      <button class="btn sm ghost" style="margin-left:auto" onclick="location.reload()">↻</button></div>
    ${q.length ? `<div class="kds">${q.map((o) => {
      const age = Math.max(0, E.diffMin(o.placedAt, now()));
      const cls = age > 10 ? "red" : age > 5 ? "amber" : "green";
      const items = db.orderItems.filter((i) => i.orderId === o.id);
      const next = { PLACED: "ACCEPTED", ACCEPTED: "PREPARING", PREPARING: "READY", READY: "SERVED" }[o.status];
      return `<div class="kcard ${cls}">
        <div class="kh"><span class="c">${esc(o.code)}</span><span class="t">${age}m</span></div>
        <div class="xs dim">${esc(o.type === "IN_SESSION" ? "→ gaming station" : o.tableId || o.type)} · ${badge(o.status)}</div>
        <ul>${items.map((i) => `<li><b>${i.qty}</b><span>${esc(i.name)}${i.note ? `<br><span class="xs" style="color:var(--warn)">${esc(i.note)}</span>` : ""}</span></li>`).join("")}</ul>
        ${next ? `<button class="btn pri block mt8" data-adv="${o.id}|${next}">Mark ${next.toLowerCase()}</button>` : ""}
      </div>`;
    }).join("")}</div>` : `<div class="card center muted">Nothing cooking. 🧊</div>`}`;
  }

  // ---------------- POS ----------------
  function viewPos() {
    const lines = Object.entries(state.pos).map(([id, qty]) => {
      const it = db.menuItems.find((m) => m.id === id);
      return { it, qty, line: it.pricePaise * qty };
    });
    const food = lines.reduce((a, l) => a + l.line, 0);
    const tot = E.totals({ foodPaise: food, kind: "FOOD", settings: db.settings });
    const cats = db.menuCategories;
    return `<div class="ahead"><h2>Counter POS</h2>
      <button class="btn sm" style="margin-left:auto" data-newbooking="1">+ Walk-in booking</button>
      <button class="btn sm ghost" data-scan="1">Scan check-in code</button></div>
    <div class="grid" style="grid-template-columns:1fr 320px;align-items:start;gap:16px">
      <div>${cats.map((c) => `<h3 class="mt16">${esc(c.name)}</h3>
        <div class="posgrid">${db.menuItems.filter((i) => i.categoryId === c.id && i.available).map((i) =>
          `<button class="pitem" data-pos="${i.id}"><div class="n">${esc(i.name)}</div><div class="p">${E.fmt(i.pricePaise)}</div></button>`).join("")}</div>`).join("")}</div>
      <div class="card" style="position:sticky;top:16px">
        <h3>Bill</h3>
        ${lines.length ? `<table class="tbl">${lines.map((l) => `<tr>
          <td class="sm">${esc(l.it.name)}<br><span class="xs dim">${l.qty} × ${E.fmt(l.it.pricePaise)}</span></td>
          <td class="right mono sm">${E.fmt(l.line)}<br><button class="btn xs ghost" data-posdec="${l.it.id}">−</button></td></tr>`).join("")}
          <tr><td class="sm">Subtotal</td><td class="right mono sm">${E.fmt(tot.subtotalPaise)}</td></tr>
          ${tot.taxBreakup.map((t) => `<tr><td class="xs dim">${esc(t.label)} ${t.percent}%</td><td class="right xs mono dim">${E.fmt(t.taxPaise)}</td></tr>`).join("")}
          <tr><td><b>Total</b></td><td class="right"><b class="mono" style="color:var(--food);font-size:16px">${E.fmt(tot.totalPaise)}</b></td></tr></table>
          <div class="field mt16"><label class="f">Type</label><select id="postype">
            <option value="DINE_IN">Dine in</option><option value="TAKEAWAY">Takeaway</option></select></div>
          <button class="btn food block" data-possettle="CASH">💵 Cash</button>
          <button class="btn block mt8" data-possettle="UPI">📱 UPI</button>
          <button class="btn block mt8" data-possettle="CARD">💳 Card</button>
          <button class="btn block mt8 ghost" data-posclear="1">Clear</button>`
        : `<p class="muted sm">Tap items to build a bill.</p>`}
      </div>
    </div>`;
  }

  // ---------------- MENU MANAGER ----------------
  function viewMenu() {
    return `<div class="ahead"><h2>Menu manager</h2>
      <button class="btn sm" style="margin-left:auto" data-additem="1">+ Add item</button>
      <button class="btn sm pri" data-xls="menu">⬇ Excel</button></div>
    ${db.menuCategories.map((c) => `<h3 class="mt16">${esc(c.name)}</h3>
      <div class="card pad0"><div class="tblwrap"><table class="tbl">
        <thead><tr><th>Item</th><th>Diet</th><th class="right">Price</th><th>Prep</th><th>Available</th><th></th></tr></thead>
        <tbody>${db.menuItems.filter((i) => i.categoryId === c.id).map((i) => `<tr>
          <td><b class="sm">${esc(i.name)}</b>${i.bestseller ? ' <span class="badge b-warn">★</span>' : ""}<br><span class="xs dim">${esc(i.description)}</span></td>
          <td><span class="dietdot ${i.diet === "NON_VEG" ? "nonveg" : "veg"}"></span></td>
          <td class="right"><input type="number" value="${i.pricePaise / 100}" data-price="${i.id}" style="width:88px;text-align:right;min-height:34px;padding:5px 8px"></td>
          <td class="sm">${i.prepMinutes}m</td>
          <td><button class="btn xs ${i.available ? "" : "danger"}" data-avail="${i.id}">${i.available ? "On menu" : "86'd"}</button></td>
          <td class="right"><button class="btn xs danger" data-delitem="${i.id}">✕</button></td></tr>`).join("")}
        </tbody></table></div></div>`).join("")}
    <div class="card mt16 sm muted">Change a price and it applies instantly on the website, the app and the POS —
      no redeploy, no code edit.</div>`;
  }

  // ---------------- STATIONS & RATES ----------------
  function viewStations() {
    const days = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
    const hrs = [];
    for (let h = 10; h <= 23; h++) hrs.push(h);
    const pc = db.settings.stationTypes[0];
    return `<div class="ahead"><h2>Stations &amp; rates</h2></div>
    <div class="card"><h3>Hourly rates</h3>
      <table class="tbl">${db.settings.stationTypes.map((t) => `<tr>
        <td><b>${t.icon} ${esc(t.name)}</b><br><span class="xs dim">${esc(t.specs)}</span></td>
        <td class="right"><input type="number" value="${t.hourly}" data-rate="${t.id}" style="width:96px;text-align:right;min-height:34px;padding:5px 8px"> <span class="xs dim">/hr</span></td>
        <td class="sm">${db.stations.filter((s) => s.stationTypeId === t.id).length} units</td></tr>`).join("")}</table>
      <button class="btn sm pri mt16" data-saverates="1">Save rates</button></div>

    <div class="card mt16"><h3>Effective price — ${esc(pc.name)}</h3>
      <p class="sm muted">What a customer actually pays per hour, after peak, weekend and happy-hour rules stack.</p>
      <div class="heat mt16">
        <div></div>${hrs.map((h) => `<div class="hl" style="text-align:center">${h}</div>`).join("")}
        ${days.map((d, di) => {
          // find a real date with this weekday
          let probe = new Date();
          while (probe.getDay() !== di) probe.setDate(probe.getDate() + 1);
          const key = E.dateKey(probe);
          return `<div class="hl">${d}</div>` + hrs.map((h) => {
            const p = E.slotPricePaise(pc, `${key}T${String(h).padStart(2, "0")}:00`, db.settings).paise;
            const base = E.toPaise(pc.hourly);
            const ratio = p / base;
            const bg = ratio > 1.3 ? "rgba(251,138,138,.20)" : ratio > 1.1 ? "rgba(251,191,36,.18)"
                     : ratio < 0.9 ? "rgba(74,222,128,.18)" : "var(--card2)";
            const tx = ratio > 1.3 ? "#f4a3a3" : ratio > 1.1 ? "var(--food-soft)" : ratio < 0.9 ? "#6ee7a8" : "var(--muted)";
            return `<div style="background:${bg};color:${tx}" title="${d} ${h}:00">${Math.round(p / 100)}</div>`;
          }).join("");
        }).join("")}
      </div>
      <div class="legend"><span><i style="background:rgba(74,222,128,.18)"></i>Happy hour</span><span><i style="background:var(--card2)"></i>Base</span>
        <span><i style="background:rgba(251,191,36,.18)"></i>Peak</span><span><i style="background:rgba(251,138,138,.20)"></i>Peak + weekend</span></div></div>

    <div class="card mt16"><h3>Units</h3>
      <div class="tblwrap"><table class="tbl">
        <thead><tr><th>Station</th><th>Type</th><th>Status</th><th>Note</th><th></th></tr></thead>
        <tbody>${db.stations.map((s) => `<tr><td class="mono sm">${esc(s.label)}</td>
          <td class="sm">${esc(st(s.stationTypeId)?.name || "")}</td><td>${badge(s.status)}</td>
          <td class="xs dim">${esc(s.maintenanceNote || "")}</td>
          <td class="right"><button class="btn xs ${s.status === "MAINTENANCE" ? "pri" : "danger"}" data-toggle="${s.id}">
            ${s.status === "MAINTENANCE" ? "Back in service" : "Mark for repair"}</button></td></tr>`).join("")}
      </tbody></table></div></div>`;
  }

  // ---------------- CUSTOMERS ----------------
  function viewCustomers() {
    const rows = [...db.customers].sort((a, b) => b.spendPaise - a.spendPaise).slice(0, 200);
    return `<div class="ahead"><h2>Customers</h2><span class="sm muted">${db.customers.length} total</span>
      <button class="btn sm pri" style="margin-left:auto" data-xls="customers">⬇ Excel</button></div>
    <div class="card pad0"><div class="tblwrap"><table class="tbl">
      <thead><tr><th>Name</th><th>Phone</th><th class="right">Visits</th><th class="right">Spend</th><th class="right">Avg</th><th class="right">No-shows</th></tr></thead>
      <tbody>${rows.map((c) => `<tr><td class="sm"><b>${esc(c.name || "—")}</b></td><td class="mono sm">${esc(c.phone)}</td>
        <td class="right sm">${c.visits}</td><td class="right mono sm">${E.fmt(c.spendPaise)}</td>
        <td class="right mono sm">${E.fmt(c.visits ? c.spendPaise / c.visits : 0)}</td>
        <td class="right sm">${c.noShows ? `<span style="color:var(--bad)">${c.noShows}</span>` : "0"}</td></tr>`).join("")}
      </tbody></table></div></div>`;
  }

  // ---------------- LOYALTY ADMIN ----------------
  function viewLoyalty() {
    const L = db.settings.loyalty;
    const withPts = db.customers.filter((c) => (c.points || 0) > 0 || (c.lifetimePoints || 0) > 0);
    const outstanding = withPts.reduce((a, c) => a + (c.points || 0), 0);
    const liability = E.redeemValuePaise(outstanding, db.settings);
    const issued = db.loyalty.filter((r) => r.delta > 0).reduce((a, r) => a + r.delta, 0);
    const redeemed = Math.abs(db.loyalty.filter((r) => r.delta < 0).reduce((a, r) => a + r.delta, 0));
    const byTier = {};
    db.customers.forEach((c) => {
      const t = E.tierFor(c.spendPaise || 0, db.settings).tier;
      (byTier[t.id] ||= { tier: t, n: 0, spend: 0 });
      byTier[t.id].n++; byTier[t.id].spend += c.spendPaise || 0;
    });
    const top = [...db.customers].sort((a, b) => (b.lifetimePoints || 0) - (a.lifetimePoints || 0)).slice(0, 15);
    const recent = [...db.loyalty].sort((a, b) => b.at.localeCompare(a.at)).slice(0, 30);

    return `<div class="ahead"><h2>★ ${esc(L.programName)}</h2>
      <span class="badge ${L.enabled ? "b-ok" : "b-dim"}">${L.enabled ? "Live" : "Off"}</span>
      <button class="btn sm pri" style="margin-left:auto" data-xls="loyalty">⬇ Excel</button></div>

    <div class="grid g4">
      <div class="stat"><div class="k">Points outstanding</div><div class="v">${outstanding.toLocaleString("en-IN")}</div>
        <div class="d">liability ${E.fmt(liability)}</div></div>
      <div class="stat"><div class="k">Issued all-time</div><div class="v" style="font-size:1.3rem">${issued.toLocaleString("en-IN")}</div></div>
      <div class="stat"><div class="k">Redeemed</div><div class="v" style="font-size:1.3rem">${redeemed.toLocaleString("en-IN")}</div>
        <div class="d">${issued ? ((redeemed / issued) * 100).toFixed(0) : 0}% redemption rate</div></div>
      <div class="stat"><div class="k">Members</div><div class="v" style="font-size:1.3rem">${withPts.length}</div>
        <div class="d">of ${db.customers.length} customers</div></div>
    </div>

    <div class="card mt16" style="border-color:var(--warn)">
      <b>Watch the liability number.</b>
      <div class="sm muted mt8">Every point you issue is a future discount you've promised. At ${E.fmt(liability)} of
        outstanding value, that's what you'd give away if everyone redeemed tomorrow. Keep it in view when you
        set the earn rate — generous programs are easy to launch and painful to walk back.</div>
    </div>

    <div class="grid g2 mt16">
      <div class="card"><h3>Members by tier</h3>
        <table class="tbl">${[...L.tiers].sort((a, b) => a.minSpend - b.minSpend).map((t) => {
          const g = byTier[t.id] || { n: 0, spend: 0 };
          const pct = db.customers.length ? (g.n / db.customers.length) * 100 : 0;
          return `<tr><td><span class="tierpill t-${t.id}">${esc(t.name)}</span></td>
            <td class="sm">${g.n} members</td>
            <td style="width:38%"><div class="bar"><i style="width:${pct.toFixed(1)}%"></i></div></td>
            <td class="right mono sm">${E.fmt(g.spend)}</td></tr>`;
        }).join("")}</table></div>

      <div class="card"><h3>Programme rules</h3>
        <label class="check"><input type="checkbox" data-set="loyalty.enabled" ${L.enabled ? "checked" : ""}>
          <span>Programme is live</span></label>
        <div class="row gap8">
          <div class="field grow"><label class="f">Points per ₹100</label><input type="number" data-set="loyalty.pointsPerHundred" value="${L.pointsPerHundred}"></div>
          <div class="field grow"><label class="f">Gaming multiplier</label><input type="number" step="0.5" data-set="loyalty.gamingMultiplier" value="${L.gamingMultiplier}"></div>
        </div>
        <div class="row gap8">
          <div class="field grow"><label class="f">₹ per point</label><input type="number" step="0.1" data-set="loyalty.rupeesPerPoint" value="${L.rupeesPerPoint}"></div>
          <div class="field grow"><label class="f">Min redeem</label><input type="number" data-set="loyalty.minRedeemPoints" value="${L.minRedeemPoints}"></div>
        </div>
        <div class="row gap8">
          <div class="field grow"><label class="f">Max % of a bill</label><input type="number" data-set="loyalty.maxRedeemPercent" value="${L.maxRedeemPercent}"></div>
          <div class="field grow"><label class="f">Expiry (months)</label><input type="number" data-set="loyalty.expiryMonths" value="${L.expiryMonths}"></div>
        </div>
        <div class="row gap8">
          <div class="field grow"><label class="f">Signup bonus</label><input type="number" data-set="loyalty.signupBonus" value="${L.signupBonus}"></div>
          <div class="field grow"><label class="f">Referral bonus</label><input type="number" data-set="loyalty.referralBonus" value="${L.referralBonus}"></div>
          <div class="field grow"><label class="f">Birthday bonus</label><input type="number" data-set="loyalty.birthdayBonus" value="${L.birthdayBonus}"></div>
        </div>
        <div class="hint">A member earning ${L.pointsPerHundred} points per ₹100 on food and
          ${L.pointsPerHundred * L.gamingMultiplier} on gaming, redeeming at ₹${L.rupeesPerPoint}/point,
          is getting roughly <b>${((L.pointsPerHundred * L.rupeesPerPoint) / 100 * 100).toFixed(1)}% back on food</b>
          and <b>${((L.pointsPerHundred * L.gamingMultiplier * L.rupeesPerPoint) / 100 * 100).toFixed(1)}% back on gaming</b>,
          before tier discounts.</div>
      </div>
    </div>

    <div class="card mt16"><h3>Tier thresholds &amp; benefits</h3>
      <div class="tblwrap"><table class="tbl">
        <thead><tr><th>Tier</th><th>Lifetime spend from</th><th>Auto discount</th><th>Bonus earn</th><th>Perks</th></tr></thead>
        <tbody>${[...L.tiers].sort((a, b) => a.minSpend - b.minSpend).map((t, i) => `<tr>
          <td><span class="tierpill t-${t.id}">${esc(t.name)}</span></td>
          <td><input type="number" data-tier="${i}.minSpend" value="${t.minSpend}" style="width:104px;min-height:34px;padding:5px 8px"></td>
          <td><input type="number" data-tier="${i}.discountPercent" value="${t.discountPercent}" style="width:76px;min-height:34px;padding:5px 8px"> %</td>
          <td><input type="number" data-tier="${i}.earnBonus" value="${t.earnBonus}" style="width:76px;min-height:34px;padding:5px 8px"> %</td>
          <td class="xs muted">${t.perks.map(esc).join(" · ")}</td></tr>`).join("")}
      </tbody></table></div>
      <button class="btn sm pri mt16" data-savetiers="1">Save tiers</button>
      <div class="hint">Changing a threshold re-tiers members immediately, since tier is derived from spend rather than stored.</div></div>

    <div class="grid g2 mt16">
      <div class="card"><h3>Top members</h3>
        <div class="tblwrap"><table class="tbl">
          <thead><tr><th>Member</th><th>Tier</th><th class="right">Balance</th><th class="right">Lifetime</th><th></th></tr></thead>
          <tbody>${top.map((c) => {
            const t = E.tierFor(c.spendPaise || 0, db.settings).tier;
            return `<tr><td class="sm"><b>${esc(c.name || "—")}</b><br><span class="xs dim">${esc(c.phone || c.email || "")}</span></td>
              <td><span class="tierpill t-${t.id}">${esc(t.name)}</span></td>
              <td class="right mono sm">${(c.points || 0).toLocaleString("en-IN")}</td>
              <td class="right mono sm dim">${(c.lifetimePoints || 0).toLocaleString("en-IN")}</td>
              <td class="right"><button class="btn xs" data-adjpts="${c.id}">Adjust</button></td></tr>`;
          }).join("")}</tbody></table></div></div>

      <div class="card"><h3>Recent points activity</h3>
        <div class="tblwrap"><table class="tbl ledger">
          <tbody>${recent.map((r) => {
            const c = db.customers.find((x) => x.id === r.customerId);
            return `<tr><td class="sm">${esc(c?.name || "—")}<br><span class="xs dim">${esc(r.reason)}</span></td>
              <td class="right"><span class="amt ${r.delta > 0 ? "plus" : "minus"}">${r.delta > 0 ? "+" : ""}${r.delta}</span>
                <br><span class="xs dim">${esc(r.at.slice(5, 16).replace("T", " "))}</span></td></tr>`;
          }).join("")}</tbody></table></div></div>
    </div>`;
  }

  // ---------------- PAYMENTS ----------------
  function viewPayments() {
    const rows = [...db.payments].sort((a, b) => b.at.localeCompare(a.at)).slice(0, 200);
    const byMethod = {};
    db.payments.filter((p) => p.status === "CAPTURED").forEach((p) => { byMethod[p.method] = (byMethod[p.method] || 0) + p.amountPaise; });
    return `<div class="ahead"><h2>Payments</h2>
      <button class="btn sm pri" style="margin-left:auto" data-xls="payments">⬇ Excel</button></div>
    <div class="grid g4">${Object.entries(byMethod).map(([m, v]) => `<div class="stat"><div class="k">${esc(m)}</div><div class="v" style="font-size:1.2rem">${E.fmt(v)}</div></div>`).join("")}</div>
    <div class="card pad0 mt16"><div class="tblwrap"><table class="tbl">
      <thead><tr><th>When</th><th>Ref</th><th>Method</th><th>Status</th><th class="right">Amount</th><th></th></tr></thead>
      <tbody>${rows.map((p) => {
        const b = db.bookings.find((x) => x.id === p.bookingId);
        const o = db.orders.find((x) => x.id === p.orderId);
        return `<tr><td class="sm nowrap">${esc(nice(p.at))}</td>
          <td class="mono sm">${esc(b?.code || o?.code || "—")}</td><td class="sm">${esc(p.method)}</td>
          <td>${badge(p.status)}</td><td class="right mono sm">${E.fmt(p.amountPaise)}</td>
          <td class="right">${p.status === "AWAITING_VERIFICATION" ? `<button class="btn xs pri" data-verify="${p.id}">Verify</button>` : ""}</td></tr>`;
      }).join("")}</tbody></table></div></div>
    ${db.refunds.length ? `<h3 class="mt24">Refunds</h3><div class="card pad0"><table class="tbl">
      <thead><tr><th>When</th><th>Booking</th><th>Reason</th><th class="right">Amount</th></tr></thead>
      <tbody>${db.refunds.slice(-40).reverse().map((r) => {
        const b = db.bookings.find((x) => x.id === r.bookingId);
        return `<tr><td class="sm">${esc(nice(r.at))}</td><td class="mono sm">${esc(b?.code || "")}</td>
          <td class="sm">${esc(r.reason)} <span class="xs dim">(${r.percent}%)</span></td>
          <td class="right mono sm">${E.fmt(r.amountPaise)}</td></tr>`;
      }).join("")}</tbody></table></div>` : ""}`;
  }

  function viewAudit() {
    return `<div class="ahead"><h2>Audit log</h2><span class="sm muted">every state change, newest first</span></div>
    <div class="card pad0"><div class="tblwrap"><table class="tbl">
      <thead><tr><th>When</th><th>Actor</th><th>Action</th><th>Entity</th><th>Detail</th></tr></thead>
      <tbody>${db.audit.slice(0, 200).map((a) => `<tr><td class="sm nowrap">${esc(nice(a.at))}</td>
        <td class="xs dim">${esc(a.actor)}</td><td class="sm"><b>${esc(a.action)}</b></td>
        <td class="xs dim">${esc(a.entity)}</td><td class="xs">${esc(a.detail || "")}</td></tr>`).join("")}
      </tbody></table></div></div>`;
  }

  // ---------------- REPORTS ----------------
  function rangeDays(n) {
    const out = [];
    for (let i = n - 1; i >= 0; i--) {
      const d = new Date(); d.setDate(d.getDate() - i);
      out.push(dayStats(E.dateKey(d)));
    }
    return out;
  }

  function viewReports() {
    const days = rangeDays(state.reportRange);
    const tot = days.reduce((a, d) => ({
      gaming: a.gaming + d.gaming, food: a.food + d.food, total: a.total + d.total,
      bookings: a.bookings + d.bookings, orders: a.orders + d.orders, refunds: a.refunds + d.refunds, disc: a.disc + d.disc,
    }), { gaming: 0, food: 0, total: 0, bookings: 0, orders: 0, refunds: 0, disc: 0 });
    const max = Math.max(1, ...days.map((d) => d.total));

    // peak-hour heatmap from real bookings
    const heat = {};
    for (let dw = 0; dw < 7; dw++) heat[dw] = {};
    db.bookingStations.forEach((r) => {
      const b = db.bookings.find((x) => x.id === r.bookingId);
      if (!b || ["CANCELLED", "EXPIRED", "NO_SHOW"].includes(b.status)) return;
      const d = E.parseLocal(r.startAt);
      const h = d.getHours();
      heat[d.getDay()][h] = (heat[d.getDay()][h] || 0) + 1;
    });
    const heatMax = Math.max(1, ...Object.values(heat).flatMap((o) => Object.values(o)));
    const hrs = []; for (let h = 10; h <= 23; h++) hrs.push(h);

    // menu performance
    const perf = {};
    db.orderItems.forEach((i) => {
      const o = db.orders.find((x) => x.id === i.orderId);
      if (!o || o.status === "CANCELLED") return;
      (perf[i.name] ||= { qty: 0, rev: 0 });
      perf[i.name].qty += i.qty; perf[i.name].rev += i.lineTotalPaise;
    });
    const top = Object.entries(perf).sort((a, b) => b[1].rev - a[1].rev);

    // station utilisation
    const util = db.stations.map((s) => {
      const hoursBooked = db.bookingStations.filter((r) => r.stationId === s.id).reduce((a, r) => a + E.diffMin(r.startAt, r.endAt) / 60, 0);
      return { s, hoursBooked };
    }).sort((a, b) => b.hoursBooked - a.hoursBooked);
    const utilMax = Math.max(1, ...util.map((u) => u.hoursBooked));

    return `<div class="ahead"><h2>Reports</h2>
      <div class="row gap8" style="margin-left:auto">
        ${[7, 30, 60].map((n) => `<button class="chip ${state.reportRange === n ? "on" : ""}" data-range="${n}">${n}d</button>`).join("")}
        <button class="btn sm pri" data-xls="workbook">⬇ Full Excel workbook</button>
      </div></div>

    <div class="grid g4">
      <div class="stat"><div class="k">Revenue · ${state.reportRange}d</div><div class="v">${E.fmt(tot.total)}</div></div>
      <div class="stat"><div class="k">Gaming</div><div class="v" style="font-size:1.3rem;color:var(--accent)">${E.fmt(tot.gaming)}</div>
        <div class="d">${((tot.gaming / (tot.total || 1)) * 100).toFixed(0)}% of revenue</div></div>
      <div class="stat"><div class="k">Kitchen</div><div class="v" style="font-size:1.3rem;color:var(--food)">${E.fmt(tot.food)}</div>
        <div class="d">${((tot.food / (tot.total || 1)) * 100).toFixed(0)}% of revenue</div></div>
      <div class="stat"><div class="k">Avg ticket</div><div class="v" style="font-size:1.3rem">${E.fmt(tot.total / Math.max(1, tot.bookings + tot.orders))}</div>
        <div class="d">${tot.bookings} bookings, ${tot.orders} orders</div></div>
    </div>

    <div class="card mt16"><h3>Daily revenue</h3>
      <div style="display:flex;align-items:flex-end;gap:2px;height:150px;margin-top:12px">
        ${days.map((d) => `<div title="${d.date}: ${E.fmt(d.total)}" style="flex:1;display:flex;flex-direction:column;justify-content:flex-end;height:100%">
          <div style="background:var(--food);height:${(d.food / max) * 100}%"></div>
          <div style="background:var(--accent);height:${(d.gaming / max) * 100}%"></div></div>`).join("")}
      </div>
      <div class="row sm muted mt8"><span>${days[0]?.date}</span><span style="margin-left:auto">${days[days.length - 1]?.date}</span></div>
      <div class="legend"><span><i style="background:var(--accent)"></i>Gaming</span><span><i style="background:var(--food)"></i>Food</span></div></div>

    <div class="card mt16"><h3>Peak-hour heatmap</h3>
      <p class="sm muted">Sessions started, by weekday and hour. This is the report that tells you when to staff up and where to raise prices.</p>
      <div class="heat mt16"><div></div>${hrs.map((h) => `<div class="hl" style="text-align:center">${h}</div>`).join("")}
        ${["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((d, di) => `<div class="hl">${d}</div>` +
          hrs.map((h) => {
            const v = heat[di][h] || 0, r = v / heatMax;
            // Scale stays dark enough that light text always reads — no dark text anywhere.
            const bg = v === 0 ? "var(--s-off-bg)" : `rgba(11,114,133,${(0.25 + r * 0.75).toFixed(2)})`;
            const tx = r > 0.5 ? "var(--on-accent)" : r > 0 ? "var(--accent-soft)" : "var(--dim)";
            return `<div style="background:${bg};color:${tx}" title="${d} ${h}:00 — ${v} sessions">${v || ""}</div>`;
          }).join("")).join("")}
      </div></div>

    <div class="grid g2 mt16">
      <div class="card"><h3>Top sellers</h3><table class="tbl">
        ${top.slice(0, 10).map(([n, v], i) => `<tr><td class="sm"><span class="dim">${i + 1}.</span> ${esc(n)}</td>
          <td class="right sm">${v.qty}</td><td class="right mono sm">${E.fmt(v.rev)}</td></tr>`).join("")}</table></div>
      <div class="card"><h3>Slowest movers</h3><table class="tbl">
        ${top.slice(-6).reverse().map(([n, v]) => `<tr><td class="sm">${esc(n)}</td>
          <td class="right sm">${v.qty}</td><td class="right mono sm">${E.fmt(v.rev)}</td></tr>`).join("")}</table>
        <div class="hint">Consider cutting or repricing these.</div></div>
    </div>

    <div class="card mt16"><h3>Station utilisation (hours booked, all time)</h3>
      ${util.map((u) => `<div class="row gap8 sm" style="margin:5px 0">
        <span class="mono" style="min-width:74px">${esc(u.s.label)}</span>
        <div style="flex:1;background:var(--bg2);border-radius:4px;height:16px;overflow:hidden">
          <div style="background:var(--accent);height:100%;width:${(u.hoursBooked / utilMax) * 100}%"></div></div>
        <span class="mono dim" style="min-width:58px;text-align:right">${u.hoursBooked.toFixed(0)}h</span></div>`).join("")}</div>

    <div class="card mt16"><h3>GST summary</h3>
      <p class="sm muted">Gaming at ${db.settings.tax.gamingPercent}% (recreational service), food at ${db.settings.tax.foodPercent}% (restaurant, no ITC).
        ${db.settings.tax.registered ? "" : "<b>Currently unregistered — no tax is being collected.</b>"}</p>
      <table class="tbl"><thead><tr><th>Head</th><th class="right">Taxable</th><th class="right">Rate</th><th class="right">Tax</th></tr></thead><tbody>
        ${(() => {
          const g = db.bookings.filter((b) => !["CANCELLED", "EXPIRED"].includes(b.status)).reduce((a, b) => a + (b.subtotalPaise - b.discountPaise), 0);
          const f = db.orders.filter((o) => o.status !== "CANCELLED").reduce((a, o) => a + (o.subtotalPaise - o.discountPaise), 0);
          const gt = Math.round((g * db.settings.tax.gamingPercent) / 100), ft = Math.round((f * db.settings.tax.foodPercent) / 100);
          return `<tr><td class="sm">Gaming · SAC 9996</td><td class="right mono sm">${E.fmt(g)}</td><td class="right sm">${db.settings.tax.gamingPercent}%</td><td class="right mono sm">${E.fmt(gt)}</td></tr>
                  <tr><td class="sm">Food · restaurant service</td><td class="right mono sm">${E.fmt(f)}</td><td class="right sm">${db.settings.tax.foodPercent}%</td><td class="right mono sm">${E.fmt(ft)}</td></tr>
                  <tr><td><b>Total</b></td><td class="right mono"><b>${E.fmt(g + f)}</b></td><td></td><td class="right mono"><b>${E.fmt(gt + ft)}</b></td></tr>`;
        })()}
      </tbody></table>
      <div class="hint">Give this to your CA. Not a substitute for a filed return.</div></div>`;
  }

  // ---------------- EXCEL ----------------
  function xlsSheets(kind) {
    const rs = (b) => db.bookingStations.filter((r) => r.bookingId === b.id);
    const bookingRows = () => [
      ["Booking Code", "Date", "Day", "Start", "End", "Hours", "Stations", "Type", "Customer", "Phone",
       "Players", "Source", "Status", "Subtotal", "Discount", "Coupon", "Tax", "Total", "Paid", "Method", "Booked At", "Invoice"],
      ...[...db.bookings].sort((a, b) => a.startAt.localeCompare(b.startAt)).map((b) => {
        const p = db.payments.find((x) => x.bookingId === b.id);
        const d = E.parseLocal(b.startAt);
        return [b.code, b.startAt.split("T")[0], ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"][d.getDay()],
          E.hhmm(b.startAt), E.hhmm(b.endAt), b.hours, rs(b).map((r) => r.stationId).join(" "),
          st(b.stationTypeId)?.name || "", b.guestName, b.guestPhone, b.playerCount, b.source, b.status,
          b.subtotalPaise / 100, b.discountPaise / 100, b.couponCode || "", b.taxPaise / 100,
          b.totalPaise / 100, b.paidPaise / 100, p?.method || "", b.createdAt, b.invoiceNo || ""];
      })];
    const orderRows = () => [
      ["Order Code", "Placed", "Type", "Table/Station", "Customer", "Phone", "Items", "Count", "Subtotal", "Discount", "Tax", "Tip", "Total", "Method", "Status"],
      ...[...db.orders].sort((a, b) => a.placedAt.localeCompare(b.placedAt)).map((o) => {
        const items = db.orderItems.filter((i) => i.orderId === o.id);
        return [o.code, o.placedAt, o.type, o.tableId || (o.bookingId ? "station" : ""), o.guestName, o.guestPhone,
          items.map((i) => `${i.qty}× ${i.name}`).join("; "), items.reduce((a, i) => a + i.qty, 0),
          o.subtotalPaise / 100, o.discountPaise / 100, o.taxPaise / 100, o.tipPaise / 100, o.totalPaise / 100,
          o.paymentMethod, o.status];
      })];
    const summaryRows = () => {
      const days = rangeDays(90);
      return [["Date", "Bookings", "Gaming Revenue", "Orders", "Food Revenue", "Total Revenue", "Discounts", "Refunds", "Cash", "UPI", "Card", "Cancels", "No-shows", "Utilisation %"],
        ...days.map((d) => [d.date, d.bookings, d.gaming / 100, d.orders, d.food / 100, d.total / 100,
          d.disc / 100, d.refunds / 100, d.cash / 100, d.upi / 100, d.card / 100, d.cancels, d.noshow, +d.util.toFixed(1)])];
    };
    const paymentRows = () => [
      ["When", "Reference", "Type", "Method", "Status", "Amount", "UTR", "Provider Payment ID", "Idempotency Key"],
      ...[...db.payments].sort((a, b) => a.at.localeCompare(b.at)).map((p) => {
        const b = db.bookings.find((x) => x.id === p.bookingId), o = db.orders.find((x) => x.id === p.orderId);
        return [p.at, b?.code || o?.code || "", b ? "Booking" : "Order", p.method, p.status,
          p.amountPaise / 100, p.utr || "", p.providerPaymentId || "", p.idempotencyKey];
      })];
    const utilRows = () => {
      const stations = db.stations;
      const dates = [...new Set(db.bookingStations.map((r) => r.startAt.split("T")[0]))].sort().slice(-45);
      return [["Station", "Type", ...dates, "Total Hours"],
        ...stations.map((s) => {
          const cells = dates.map((d) => db.bookingStations.filter((r) => r.stationId === s.id && r.startAt.startsWith(d))
            .reduce((a, r) => a + E.diffMin(r.startAt, r.endAt) / 60, 0));
          return [s.label, st(s.stationTypeId)?.name || "", ...cells, cells.reduce((a, b) => a + b, 0)];
        })];
    };
    const menuRows = () => {
      const perf = {};
      db.orderItems.forEach((i) => { (perf[i.name] ||= { qty: 0, rev: 0 }); perf[i.name].qty += i.qty; perf[i.name].rev += i.lineTotalPaise; });
      const totalRev = Object.values(perf).reduce((a, v) => a + v.rev, 0) || 1;
      return [["Item", "Category", "Price", "Diet", "Prep (min)", "On Menu", "Qty Sold", "Revenue", "% of Food Revenue"],
        ...db.menuItems.map((i) => {
          const p = perf[i.name] || { qty: 0, rev: 0 };
          return [i.name, db.menuCategories.find((c) => c.id === i.categoryId)?.name || "", i.pricePaise / 100,
            i.diet, i.prepMinutes, i.available ? "Yes" : "No", p.qty, p.rev / 100, +((p.rev / totalRev) * 100).toFixed(1)];
        })];
    };
    const custRows = () => [
      ["Name", "Phone", "First Seen", "Visits", "Total Spend", "Avg Ticket", "No-shows"],
      ...[...db.customers].sort((a, b) => b.spendPaise - a.spendPaise).map((c) => [c.name, c.phone, c.createdAt,
        c.visits, c.spendPaise / 100, c.visits ? +(c.spendPaise / c.visits / 100).toFixed(2) : 0, c.noShows])];
    const gstRows = () => {
      const months = {};
      db.bookings.filter((b) => !["CANCELLED", "EXPIRED"].includes(b.status)).forEach((b) => {
        const m = b.startAt.slice(0, 7); (months[m] ||= { g: 0, f: 0 }); months[m].g += b.subtotalPaise - b.discountPaise;
      });
      db.orders.filter((o) => o.status !== "CANCELLED").forEach((o) => {
        const m = o.placedAt.slice(0, 7); (months[m] ||= { g: 0, f: 0 }); months[m].f += o.subtotalPaise - o.discountPaise;
      });
      const T = db.settings.tax;
      return [["Month", "Gaming Taxable", `Gaming Tax @${T.gamingPercent}%`, "Food Taxable", `Food Tax @${T.foodPercent}%`, "Total Tax"],
        ...Object.keys(months).sort().map((m) => {
          const v = months[m], gt = Math.round(v.g * T.gamingPercent / 100), ft = Math.round(v.f * T.foodPercent / 100);
          return [m, v.g / 100, gt / 100, v.f / 100, ft / 100, (gt + ft) / 100];
        })];
    };

    if (kind === "bookings") return [{ name: "Bookings", rows: bookingRows(), money: [13, 14, 16, 17, 18], widths: [13, 11, 6, 7, 7, 6, 16, 12, 16, 12, 7, 8, 14, 10, 9, 10, 8, 10, 9, 9, 17, 15] }];
    if (kind === "orders") return [{ name: "Food Orders", rows: orderRows(), money: [8, 9, 10, 11, 12], widths: [12, 17, 10, 12, 16, 12, 44, 7, 10, 9, 8, 7, 10, 9, 12] }];
    if (kind === "payments") return [{ name: "Payments", rows: paymentRows(), money: [5], widths: [17, 12, 9, 14, 20, 10, 14, 22, 22] }];
    if (kind === "menu") return [{ name: "Menu Performance", rows: menuRows(), money: [2, 7], widths: [26, 18, 9, 10, 10, 9, 10, 11, 16] }];
    const loyaltyRows = () => [
      ["When", "Member", "Phone/Email", "Reason", "Points", "Balance After", "Reference", "Expires"],
      ...[...db.loyalty].sort((a, b) => a.at.localeCompare(b.at)).map((r) => {
        const c = db.customers.find((x) => x.id === r.customerId);
        return [r.at, c?.name || "", c?.phone || c?.email || "", r.reason, r.delta, r.balanceAfter, r.refId || "", r.expiresAt || ""];
      })];
    const memberRows = () => [
      ["Member", "Phone", "Email", "Tier", "Points Balance", "Points Value", "Lifetime Points", "Lifetime Spend", "Visits", "Referral Code", "Referred By"],
      ...[...db.customers].sort((a, b) => (b.lifetimePoints || 0) - (a.lifetimePoints || 0)).map((c) => {
        const t = E.tierFor(c.spendPaise || 0, db.settings).tier;
        const ref = c.referredBy ? db.customers.find((x) => x.id === c.referredBy) : null;
        return [c.name || "", c.phone || "", c.email || "", t.name, c.points || 0,
          E.redeemValuePaise(c.points || 0, db.settings) / 100, c.lifetimePoints || 0,
          (c.spendPaise || 0) / 100, c.visits || 0, c.referralCode || "", ref ? (ref.name || ref.phone) : ""];
      })];

    if (kind === "customers") return [{ name: "Customers", rows: custRows(), money: [4, 5], widths: [20, 13, 17, 8, 12, 11, 10] }];
    if (kind === "loyalty") return [
      { name: "Members", rows: memberRows(), money: [5, 7], widths: [20, 13, 24, 11, 14, 12, 15, 14, 8, 14, 18] },
      { name: "Points Ledger", rows: loyaltyRows(), widths: [17, 20, 22, 40, 9, 13, 22, 17] },
    ];
    // full workbook
    return [
      { name: "Bookings", rows: bookingRows(), money: [13, 14, 16, 17, 18], widths: [13, 11, 6, 7, 7, 6, 16, 12, 16, 12, 7, 8, 14, 10, 9, 10, 8, 10, 9, 9, 17, 15] },
      { name: "Food Orders", rows: orderRows(), money: [8, 9, 10, 11, 12], widths: [12, 17, 10, 12, 16, 12, 44, 7, 10, 9, 8, 7, 10, 9, 12] },
      { name: "Daily Summary", rows: summaryRows(), money: [2, 4, 5, 6, 7, 8, 9, 10], widths: [11, 10, 15, 8, 13, 14, 11, 10, 9, 9, 9, 9, 10, 13] },
      { name: "Payments", rows: paymentRows(), money: [5], widths: [17, 12, 9, 14, 20, 10, 14, 22, 22] },
      { name: "Station Utilisation", rows: utilRows(), widths: [11, 12] },
      { name: "Menu Performance", rows: menuRows(), money: [2, 7], widths: [26, 18, 9, 10, 10, 9, 10, 11, 16] },
      { name: "Customers", rows: custRows(), money: [4, 5], widths: [20, 13, 17, 8, 12, 11, 10] },
      { name: "GST Summary", rows: gstRows(), money: [1, 2, 3, 4, 5], widths: [11, 15, 16, 14, 15, 12] },
      { name: "Loyalty Members", rows: memberRows(), money: [5, 7], widths: [20, 13, 24, 11, 14, 12, 15, 14, 8, 14, 18] },
      { name: "Points Ledger", rows: loyaltyRows(), widths: [17, 20, 22, 40, 9, 13, 22, 17] },
    ];
  }

  function doExport(kind) {
    const sheets = xlsSheets(kind);
    const name = kind === "workbook"
      ? `${db.settings.brand.name.replace(/\s+/g, "-")}-full-${today()}.xlsx`
      : `${kind}-${today()}.xlsx`;
    XlsxWriter.download(name, sheets);
    toast(`${name} downloaded — ${sheets.length} sheet${sheets.length > 1 ? "s" : ""}`, "ok");
  }

  // ---------------- SETTINGS ----------------
  function viewSettings() {
    const B = db.settings.brand, K = db.settings.booking, T = db.settings.tax, P = db.settings.payments;
    return `<div class="ahead"><h2>Settings</h2><span class="sm muted">saved to this browser instantly</span></div>
    <div class="grid g2">
      <div class="card"><h3>Brand</h3>
        ${[["name", "Café name"], ["tagline", "Tagline"], ["address", "Address"], ["phone", "Phone"],
           ["whatsapp", "WhatsApp"], ["email", "Email"], ["upiId", "UPI ID for direct payments"],
           ["gstin", "GSTIN (blank if unregistered)"], ["fssai", "FSSAI licence"], ["invoicePrefix", "Invoice prefix"]]
          .map(([k, l]) => `<div class="field"><label class="f">${l}</label><input data-set="brand.${k}" value="${esc(B[k] || "")}"></div>`).join("")}
      </div>

      <div class="col">
        <div class="card"><h3>Booking rules</h3>
          <div class="row gap8">
            <div class="field grow"><label class="f">Slot length (min)</label>
              <select data-set="booking.slotMinutes"><option value="30" ${K.slotMinutes === 30 ? "selected" : ""}>30</option><option value="60" ${K.slotMinutes === 60 ? "selected" : ""}>60</option></select></div>
            <div class="field grow"><label class="f">Hold timer (min)</label><input type="number" data-set="booking.holdMinutes" value="${K.holdMinutes}"></div>
          </div>
          <div class="row gap8">
            <div class="field grow"><label class="f">Min hours</label><input type="number" data-set="booking.minHours" value="${K.minHours}"></div>
            <div class="field grow"><label class="f">Max hours</label><input type="number" data-set="booking.maxHours" value="${K.maxHours}"></div>
          </div>
          <div class="row gap8">
            <div class="field grow"><label class="f">Cleanup buffer (min)</label><input type="number" data-set="booking.bufferMinutes" value="${K.bufferMinutes}"></div>
            <div class="field grow"><label class="f">Book ahead (days)</label><input type="number" data-set="booking.advanceDays" value="${K.advanceDays}"></div>
          </div>
          <div class="field"><label class="f">No-show grace (min)</label><input type="number" data-set="booking.noShowGraceMinutes" value="${K.noShowGraceMinutes}"></div>
        </div>

        <div class="card"><h3>Tax</h3>
          <label class="check"><input type="checkbox" data-set="tax.registered" ${T.registered ? "checked" : ""}>
            <span>GST registered — charge tax on invoices</span></label>
          <div class="row gap8">
            <div class="field grow"><label class="f">Food %</label><input type="number" data-set="tax.foodPercent" value="${T.foodPercent}"></div>
            <div class="field grow"><label class="f">Gaming %</label><input type="number" data-set="tax.gamingPercent" value="${T.gamingPercent}"></div>
          </div>
          <div class="hint">India: restaurant service is 5% without input tax credit; a gaming lounge is a recreational service at 18%.
            Confirm your own position with a CA.</div>
        </div>

        <div class="card"><h3>Payments</h3>
          <div class="field"><label class="f">Gateway</label>
            <select data-set="payments.gateway">
              <option value="MOCK" ${P.gateway === "MOCK" ? "selected" : ""}>Mock (demo, no real money)</option>
              <option value="RAZORPAY" ${P.gateway === "RAZORPAY" ? "selected" : ""}>Razorpay (needs a server)</option>
            </select></div>
          <label class="check"><input type="checkbox" data-set="payments.allowPayAtCounter" ${P.allowPayAtCounter ? "checked" : ""}><span>Allow "pay at counter"</span></label>
          <label class="check"><input type="checkbox" data-set="payments.allowManualUpi" ${P.allowManualUpi ? "checked" : ""}><span>Allow manual UPI QR + UTR</span></label>
        </div>
      </div>
    </div>

    <div class="card mt16"><h3>Opening hours</h3>
      <div class="tblwrap"><table class="tbl">
        <thead><tr><th>Day</th><th>Open</th><th>Close</th><th>Closed?</th></tr></thead>
        <tbody>${db.settings.hours.map((h, i) => `<tr>
          <td class="sm">${["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"][h.day]}</td>
          <td><input type="time" value="${h.open}" data-hr="${i}.open" style="min-height:34px;padding:4px 8px"></td>
          <td><input type="time" value="${h.close}" data-hr="${i}.close" style="min-height:34px;padding:4px 8px"></td>
          <td><input type="checkbox" data-hr="${i}.closed" ${h.closed ? "checked" : ""} style="width:20px;height:20px"></td></tr>`).join("")}
      </tbody></table></div></div>

    <div class="card mt16"><h3>Data</h3>
      <div class="row wrap gap8">
        <button class="btn sm" data-xls="workbook">⬇ Download full Excel workbook</button>
        <button class="btn sm" data-backup="1">⬇ Backup (JSON)</button>
        <button class="btn sm" data-restore="1">⬆ Restore from backup</button>
        <button class="btn sm danger" data-reseed="1">Regenerate demo data</button>
        <button class="btn sm danger" data-wipe="1">Wipe everything (go live empty)</button>
      </div>
      <div class="hint">This build keeps data in this browser only. The production monorepo uses PostgreSQL with nightly backups.</div>
    </div>`;
  }

  // ---------------- bind ----------------
  function bind() {
    $$("[data-x]").forEach((b) => b.onclick = () => go(b.dataset.x));
    $$("[data-xls]").forEach((b) => b.onclick = () => doExport(b.dataset.xls));
    $$("[data-range]").forEach((b) => b.onclick = () => { state.reportRange = +b.dataset.range; render(); });
    $$("[data-checkin]").forEach((b) => b.onclick = () => { Store.checkIn(db, b.dataset.checkin); save(); toast("Checked in", "ok"); render(); });
    $$("[data-checkout]").forEach((b) => b.onclick = () => { Store.checkOut(db, b.dataset.checkout); save(); toast("Session ended", "ok"); render(); });
    $$("[data-noshow]").forEach((b) => b.onclick = () => { Store.markNoShow(db, b.dataset.noshow); save(); toast("Marked no-show", "warn"); render(); });
    $$("[data-ext]").forEach((b) => b.onclick = () => {
      const r = Store.extendBooking(db, b.dataset.ext, 30); save();
      toast(r.ok ? `Extended · ${E.fmt(r.addedPaise)} added` : r.error, r.ok ? "ok" : "bad"); render();
    });
    $$("[data-cancel]").forEach((b) => b.onclick = () => {
      const bk = db.bookings.find((x) => x.id === b.dataset.cancel);
      const rf = E.refundFor(bk.startAt, now(), bk.paidPaise, db.settings);
      if (!confirm(`Cancel ${bk.code}?\n\nRefund due: ${E.fmt(rf.refundPaise)} (${rf.percent}% of ${E.fmt(bk.paidPaise)} paid)`)) return;
      Store.cancelBooking(db, bk.id, "Cancelled by staff"); save(); toast("Cancelled", "ok"); render();
    });
    $$("[data-verify]").forEach((b) => b.onclick = () => { Store.verifyManualPayment(db, b.dataset.verify); save(); toast("Payment verified", "ok"); render(); });
    $$("[data-adv]").forEach((b) => b.onclick = () => {
      const [id, s] = b.dataset.adv.split("|"); Store.advanceOrder(db, id, s); save(); render();
    });
    $$("[data-station]").forEach((el) => el.onclick = () => {
      const s = db.stations.find((x) => x.id === el.dataset.station);
      const m = modal(s.label, `
        <p class="sm muted">${esc(st(s.stationTypeId)?.name || "")} · currently ${badge(s.status)}</p>
        <div class="field"><label class="f">Maintenance note</label><input id="mn" value="${esc(s.maintenanceNote || "")}" placeholder="GPU swap, back Friday"></div>
        <button class="btn danger block" id="mmaint">Mark for repair (blocks all bookings)</button>
        <button class="btn pri block mt8" id="mfree">Back in service</button>`);
      $("#mmaint", m).onclick = () => { Store.setStationStatus(db, s.id, "MAINTENANCE", $("#mn", m).value); save(); m._close(); toast(s.label + " blocked", "warn"); render(); };
      $("#mfree", m).onclick = () => { Store.setStationStatus(db, s.id, "AVAILABLE", ""); save(); m._close(); toast(s.label + " available", "ok"); render(); };
    });
    $$("[data-toggle]").forEach((b) => b.onclick = () => {
      const s = db.stations.find((x) => x.id === b.dataset.toggle);
      Store.setStationStatus(db, s.id, s.status === "MAINTENANCE" ? "AVAILABLE" : "MAINTENANCE", s.status === "MAINTENANCE" ? "" : "Marked from admin");
      save(); render();
    });
    $$("[data-newbooking]").forEach((b) => b.onclick = newBookingModal);
    $$("[data-avail]").forEach((b) => b.onclick = () => {
      const i = db.menuItems.find((x) => x.id === b.dataset.avail);
      i.available = !i.available; Store.audit(db, "MENU_AVAIL", "menuItem", i.id, i.available ? "on" : "86");
      save(); toast(`${i.name} ${i.available ? "back on the menu" : "marked sold out"}`, "ok"); render();
    });
    $$("[data-price]").forEach((inp) => inp.onchange = () => {
      const i = db.menuItems.find((x) => x.id === inp.dataset.price);
      i.pricePaise = E.toPaise(+inp.value); Store.audit(db, "MENU_PRICE", "menuItem", i.id, inp.value);
      save(); toast(`${i.name} → ₹${inp.value}`, "ok");
    });
    $$("[data-delitem]").forEach((b) => b.onclick = () => {
      const i = db.menuItems.find((x) => x.id === b.dataset.delitem);
      if (!confirm(`Remove ${i.name} from the menu?`)) return;
      db.menuItems = db.menuItems.filter((x) => x.id !== i.id); save(); render();
    });
    $$("[data-additem]").forEach((b) => b.onclick = () => {
      const m = modal("Add menu item", `
        <div class="field"><label class="f">Name</label><input id="an"></div>
        <div class="field"><label class="f">Category</label><select id="ac">${db.menuCategories.map((c) => `<option value="${c.id}">${esc(c.name)}</option>`).join("")}</select></div>
        <div class="row gap8"><div class="field grow"><label class="f">Price ₹</label><input id="ap" type="number" value="150"></div>
          <div class="field grow"><label class="f">Prep (min)</label><input id="am" type="number" value="10"></div></div>
        <div class="field"><label class="f">Diet</label><select id="ad"><option value="VEG">Veg</option><option value="NON_VEG">Non-veg</option><option value="EGG">Egg</option></select></div>
        <div class="field"><label class="f">Description</label><input id="ades"></div>
        <button class="btn pri block" id="ago">Add to menu</button>`);
      $("#ago", m).onclick = () => {
        const n = $("#an", m).value.trim(); if (!n) return toast("Name it first", "bad");
        db.menuItems.push({
          id: Store.uid("item"), categoryId: $("#ac", m).value, name: n, pricePaise: E.toPaise(+$("#ap", m).value),
          diet: $("#ad", m).value, prepMinutes: +$("#am", m).value, description: $("#ades", m).value,
          available: true, bestseller: false, sortOrder: 99,
        });
        Store.audit(db, "MENU_ADD", "menuItem", n, ""); save(); m._close(); toast(n + " added", "ok"); render();
      };
    });
    $$("[data-rate]").forEach((inp) => inp.dataset.bound = "1");
    $$("[data-saverates]").forEach((b) => b.onclick = () => {
      $$("[data-rate]").forEach((inp) => {
        const t = st(inp.dataset.rate); t.hourly = +inp.value;
      });
      Store.audit(db, "RATES_UPDATED", "settings", "-", ""); save(); toast("Rates saved — live everywhere now", "ok"); render();
    });
    // POS
    $$("[data-pos]").forEach((b) => b.onclick = () => { state.pos[b.dataset.pos] = (state.pos[b.dataset.pos] || 0) + 1; render(); });
    $$("[data-posdec]").forEach((b) => b.onclick = () => {
      const id = b.dataset.posdec; state.pos[id]--; if (state.pos[id] <= 0) delete state.pos[id]; render();
    });
    $$("[data-posclear]").forEach((b) => b.onclick = () => { state.pos = {}; render(); });
    $$("[data-possettle]").forEach((b) => b.onclick = () => {
      const r = Store.createOrder(db, {
        type: $("#postype")?.value || "DINE_IN", items: Object.entries(state.pos).map(([itemId, qty]) => ({ itemId, qty })),
        name: "Counter", phone: "", method: b.dataset.possettle, source: "COUNTER",
      });
      if (!r.ok) return toast(r.error, "bad");
      Store.advanceOrder(db, r.orderId, "ACCEPTED");
      state.pos = {}; save(); toast(`${r.code} rung up · ${b.dataset.possettle}`, "ok"); render();
    });
    $$("[data-scan]").forEach((b) => b.onclick = () => {
      const m = modal("Check in a booking", `
        <div class="field"><label class="f">Booking code</label><input id="sc" placeholder="RC-4F7K2" style="text-transform:uppercase;font-family:var(--mono);font-size:18px"></div>
        <div class="hint">In the real app the camera scans the customer's QR. Type it here instead.</div>
        <button class="btn pri block" id="sgo">Find &amp; check in</button>`);
      $("#sgo", m).onclick = () => {
        const code = $("#sc", m).value.trim().toUpperCase();
        const bk = db.bookings.find((x) => x.code.toUpperCase() === code);
        if (!bk) return toast("No booking with that code", "bad");
        Store.checkIn(db, bk.id); save(); m._close(); toast(`${bk.guestName} checked in`, "ok"); render();
      };
    });
    $$("[data-savetiers]").forEach((b) => b.onclick = () => {
      $$("[data-tier]").forEach((inp) => {
        const [i, k] = inp.dataset.tier.split(".");
        db.settings.loyalty.tiers[+i][k] = +inp.value;
      });
      Store.audit(db, "LOYALTY_TIERS", "settings", "-", ""); save();
      toast("Tiers saved — members re-tiered instantly", "ok"); render();
    });
    $$("[data-adjpts]").forEach((b) => b.onclick = () => {
      const c = db.customers.find((x) => x.id === b.dataset.adjpts);
      const m = modal("Adjust points · " + (c.name || c.phone), `
        <p class="sm muted">Balance <b class="acc">${c.points || 0}</b> points (${E.fmt(E.redeemValuePaise(c.points || 0, db.settings))})</p>
        <div class="field"><label class="f">Points to add (negative to remove)</label><input id="apn" type="number" value="100"></div>
        <div class="field"><label class="f">Reason — goes on the customer's history</label><input id="apr" placeholder="Goodwill: long wait on Saturday"></div>
        <button class="btn pri block" id="apgo">Apply adjustment</button>`);
      $("#apgo", m).onclick = () => {
        const d = parseInt($("#apn", m).value || "0", 10);
        const why = $("#apr", m).value.trim() || "Manual adjustment by staff";
        if (!d) return toast("Enter a non-zero amount", "bad");
        Store.addPoints(db, c.id, d, why, null);
        Store.audit(db, "POINTS_ADJUST", "customer", c.id, `${d} · ${why}`);
        save(); m._close(); toast(`${d > 0 ? "+" : ""}${d} points for ${c.name || c.phone}`, "ok"); render();
      };
    });
    // settings inputs
    $$("[data-set]").forEach((el) => el.onchange = () => {
      const [grp, key] = el.dataset.set.split(".");
      let v = el.type === "checkbox" ? el.checked : el.value;
      if (el.type === "number" || ["slotMinutes", "foodPercent", "gamingPercent"].includes(key)) v = +v;
      if (grp === "loyalty" && el.type === "number") v = +v;
      db.settings[grp][key] = v;
      Store.audit(db, "SETTING", grp, key, String(v)); save();
      toast("Saved", "ok");
      if (["slotMinutes", "registered"].includes(key)) render();
    });
    $$("[data-hr]").forEach((el) => el.onchange = () => {
      const [i, k] = el.dataset.hr.split(".");
      db.settings.hours[+i][k] = el.type === "checkbox" ? el.checked : el.value;
      save(); toast("Hours updated", "ok");
    });
    $$("[data-backup]").forEach((b) => b.onclick = () => {
      const blob = new Blob([JSON.stringify(db, null, 2)], { type: "application/json" });
      const a = document.createElement("a"); a.href = URL.createObjectURL(blob);
      a.download = `respawn-backup-${today()}.json`; a.click();
      toast("Backup downloaded", "ok");
    });
    $$("[data-restore]").forEach((b) => b.onclick = () => {
      const inp = document.createElement("input"); inp.type = "file"; inp.accept = ".json";
      inp.onchange = () => {
        const f = inp.files[0]; if (!f) return;
        const r = new FileReader();
        r.onload = () => {
          try { db = JSON.parse(r.result); save(); toast("Restored", "ok"); render(); }
          catch { toast("That file isn't a valid backup", "bad"); }
        };
        r.readAsText(f);
      };
      inp.click();
    });
    $$("[data-reseed]").forEach((b) => b.onclick = () => {
      if (!confirm("Wipe and regenerate 74 days of demo data?")) return;
      db = Store.reset(CONFIG); toast("Demo data regenerated", "ok"); render();
    });
    $$("[data-wipe]").forEach((b) => b.onclick = () => {
      if (!confirm("Delete ALL bookings, orders, customers and payments?\n\nThis is what you do on your real opening day.")) return;
      db = Store.wipeDemo(CONFIG); toast("Empty and ready for real business", "ok"); render();
    });
    // filters
    const f = state.bkFilter;
    if ($("#fdate")) $("#fdate").onchange = (e) => { f.date = e.target.value; render(); };
    if ($("#fstatus")) $("#fstatus").onchange = (e) => { f.status = e.target.value; render(); };
    if ($("#fq")) {
      const q = $("#fq");
      q.oninput = () => { clearTimeout(q._t); q._t = setTimeout(() => { f.q = q.value; render(); const n = $("#fq"); if (n) { n.focus(); n.setSelectionRange(n.value.length, n.value.length); } }, 350); };
    }
    $$("[data-clearf]").forEach((b) => b.onclick = () => { state.bkFilter = { date: "", status: "ALL", q: "" }; render(); });
  }

  // KDS auto refresh
  setInterval(() => { if (state.view === "kds" || state.view === "dash" || state.view === "floor") render(); }, 30000);

  state.view = (location.hash || "#dash").slice(1);
  render();
})();
