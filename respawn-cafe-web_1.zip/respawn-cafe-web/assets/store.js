/* ============================================================
   STORE — the "database".
   In this local build the DB is a single JSON object persisted to
   localStorage. In the production build (see the monorepo zip) the
   exact same functions live in Postgres transactions with a UNIQUE
   partial index as the final backstop. The state machine is identical.
   ============================================================ */
(function (g) {
  "use strict";
  const E = g.Engine;
  const KEY = "respawn.db.v1";

  // deterministic PRNG so the demo data is the same every time
  let _s = 20260811;
  const rnd = () => ((_s = (_s * 1664525 + 1013904223) % 4294967296) / 4294967296);
  const pick = (a) => a[Math.floor(rnd() * a.length)];
  const rint = (a, b) => a + Math.floor(rnd() * (b - a + 1));

  const uid = (p) => p + "_" + Math.random().toString(36).slice(2, 10);
  const CODE_CHARS = "ACDEFGHJKLMNPQRTUVWXY3456789";
  const bookingCode = () => {
    let s = "";
    for (let i = 0; i < 5; i++) s += CODE_CHARS[Math.floor(Math.random() * CODE_CHARS.length)];
    return "RC-" + s;
  };

  const NAMES = ["Arnab", "Priya", "Rohit", "Sneha", "Aditya", "Ishita", "Sourav", "Tanya", "Rahul", "Megha",
    "Debjit", "Ananya", "Karan", "Riya", "Sayan", "Nikita", "Abhishek", "Payal", "Vikram", "Diya",
    "Soumya", "Trisha", "Manish", "Anushka", "Rajat"];

  function audit(db, action, entity, entityId, detail) {
    db.audit.unshift({ id: uid("a"), at: E.localISO(new Date()), actor: db.session?.role || "SYSTEM", action, entity, entityId, detail });
    if (db.audit.length > 800) db.audit.length = 800;
  }

  // ---------------- schema + seed ----------------
  function baseDb(cfg) {
    const settings = JSON.parse(JSON.stringify({
      brand: cfg.brand, booking: cfg.booking, hours: cfg.hours, stationTypes: cfg.stationTypes,
      pricingRules: cfg.pricingRules, addons: cfg.addons, payments: cfg.payments,
      refundPolicy: cfg.refundPolicy, tax: cfg.tax, coupons: cfg.coupons, theme: cfg.theme,
      loyalty: cfg.loyalty, auth: cfg.auth,
    }));

    const stations = [];
    for (const t of cfg.stationTypes) {
      for (let i = 1; i <= t.count; i++) {
        stations.push({
          id: `${t.id.toUpperCase()}-${String(i).padStart(2, "0")}`,
          stationTypeId: t.id, label: `${t.id.toUpperCase()}-${String(i).padStart(2, "0")}`,
          status: "AVAILABLE", maintenanceNote: "", active: true,
        });
      }
    }

    const menuCategories = [], menuItems = [];
    cfg.menu.forEach((c, ci) => {
      const catId = "cat_" + ci;
      menuCategories.push({ id: catId, name: c.cat, sortOrder: ci, active: true });
      c.items.forEach((it, ii) => {
        menuItems.push({
          id: `item_${ci}_${ii}`, categoryId: catId, name: it.name,
          pricePaise: E.toPaise(it.price), diet: it.diet, prepMinutes: it.prep,
          description: it.desc || "", available: true, bestseller: !!it.bestseller, sortOrder: ii,
        });
      });
    });

    const tables = [];
    for (let i = 1; i <= cfg.tables; i++)
      tables.push({ id: "T-" + String(i).padStart(2, "0"), label: "T-" + String(i).padStart(2, "0"), seats: i % 4 === 0 ? 6 : 4, status: "FREE" });

    return {
      version: SCHEMA, settings, stations, tables, menuCategories, menuItems,
      bookings: [], bookingStations: [], orders: [], orderItems: [],
      payments: [], refunds: [], customers: [], audit: [], waitlist: [], loyalty: [], otp: null,
      counters: { invoice: 1 },
      session: { role: "CUSTOMER", userId: null, name: null, phone: null },
    };
  }

  const REF_CHARS = "ACDEFGHJKLMNPQRTUVWXY3456789";
  const refCode = (name) => {
    const base = (name || "RC").replace(/[^A-Za-z]/g, "").slice(0, 4).toUpperCase() || "PLAY";
    let s = "";
    for (let i = 0; i < 3; i++) s += REF_CHARS[Math.floor(Math.random() * REF_CHARS.length)];
    return base + s;
  };

  function upsertCustomer(db, name, phone, email) {
    let c = db.customers.find((x) => (phone && x.phone === phone) || (email && x.email && x.email.toLowerCase() === String(email).toLowerCase()));
    if (!c) {
      c = {
        id: uid("c"), name: name || "", phone: phone || "", email: email || "",
        createdAt: E.localISO(new Date()), visits: 0, spendPaise: 0, noShows: 0, tags: [],
        points: 0, lifetimePoints: 0, referralCode: refCode(name), referredBy: null,
        dob: "", marketingOptIn: false, verified: false,
      };
      db.customers.push(c);
      // Signup bonus — the first reason to create an account.
      if (db.settings.loyalty?.enabled && db.settings.loyalty.signupBonus > 0)
        addPoints(db, c.id, db.settings.loyalty.signupBonus, "Welcome bonus", null);
    } else {
      if (name && !c.name) c.name = name;
      if (email && !c.email) c.email = email;
      if (phone && !c.phone) c.phone = phone;
      if (c.points === undefined) { c.points = 0; c.lifetimePoints = 0; }
      if (!c.referralCode) c.referralCode = refCode(c.name);
    }
    return c;
  }

  // ---------------- loyalty ----------------
  /* Append-only ledger. Balance is always derived from, and reconciled with, the ledger. */
  function addPoints(db, customerId, delta, reason, refId) {
    const c = db.customers.find((x) => x.id === customerId);
    if (!c || !delta) return null;
    c.points = Math.max(0, (c.points || 0) + delta);
    if (delta > 0) c.lifetimePoints = (c.lifetimePoints || 0) + delta;
    const row = {
      id: uid("lp"), customerId, delta, reason, refId: refId || null,
      at: E.localISO(new Date()), balanceAfter: c.points,
      expiresAt: delta > 0 && db.settings.loyalty?.expiryMonths
        ? E.addMin(E.localISO(new Date()), db.settings.loyalty.expiryMonths * 30 * 24 * 60) : null,
    };
    db.loyalty.push(row);
    return row;
  }

/* One place that decides how many points a transaction earns. */
  function awardPointsFor(db, customerId, { gamingPaise = 0, foodPaise = 0, refId, label }) {
    const L = db.settings.loyalty;
    if (!L?.enabled) return 0;
    const mi = memberInfo(db, customerId);
    const p = E.pointsEarned({ gamingPaise, foodPaise, tier: mi?.tier, settings: db.settings });
    if (p.points > 0) {
      const why = p.bonus > 0
        ? `Earned on ${label} (+${p.bonusPct}% ${mi.tier.name})`
        : `Earned on ${label}`;
      addPoints(db, customerId, p.points, why, refId);
    }
    return p.points;
  }

  function memberInfo(db, customerId) {
    const c = db.customers.find((x) => x.id === customerId);
    if (!c || !db.settings.loyalty?.enabled) return null;
    const t = E.tierFor(c.spendPaise || 0, db.settings);
    return { customer: c, points: c.points || 0, ...t, valuePaise: E.redeemValuePaise(c.points || 0, db.settings) };
  }

  function applyReferral(db, customerId, code) {
    const L = db.settings.loyalty;
    if (!L?.enabled || !code) return { ok: false, error: "No code given" };
    const me = db.customers.find((x) => x.id === customerId);
    if (!me) return { ok: false, error: "Not signed in" };
    if (me.referredBy) return { ok: false, error: "You've already used a referral code" };
    const friend = db.customers.find((x) => (x.referralCode || "").toUpperCase() === code.trim().toUpperCase());
    if (!friend) return { ok: false, error: "That code doesn't exist" };
    if (friend.id === customerId) return { ok: false, error: "You can't refer yourself" };
    me.referredBy = friend.id;
    addPoints(db, me.id, L.referralBonus, `Referred by ${friend.name || friend.phone}`, friend.id);
    addPoints(db, friend.id, L.referralBonus, `${me.name || me.phone} joined with your code`, me.id);
    audit(db, "REFERRAL", "customer", me.id, code);
    return { ok: true, points: L.referralBonus, friend };
  }

  // ---------------- auth (phone or email + OTP) ----------------
  function startLogin(db, identifier) {
    const raw = String(identifier || "").trim();
    const isEmail = raw.includes("@");
    const phone = isEmail ? "" : raw.replace(/\D/g, "");
    if (isEmail) {
      if (!/^[^@\s]+@[^@\s]+\.[a-z]{2,}$/i.test(raw)) return { ok: false, error: "That email doesn't look right." };
    } else if (phone.length !== 10) {
      return { ok: false, error: "Enter a 10-digit mobile number." };
    }
    const len = db.settings.auth?.otpLength || 6;
    let code = "";
    for (let i = 0; i < len; i++) code += Math.floor(Math.random() * 10);
    db.otp = {
      identifier: isEmail ? raw.toLowerCase() : phone, isEmail, code,
      expiresAt: E.addMin(E.localISO(new Date()), db.settings.auth?.otpValidMinutes || 10),
      attempts: 0, sentAt: E.localISO(new Date()),
    };
    audit(db, "OTP_SENT", "auth", db.otp.identifier, isEmail ? "email" : "sms");
    // Production: hand this to the SMS/email provider. Demo: return it to the UI.
    return { ok: true, code, isEmail, identifier: db.otp.identifier, demo: !!db.settings.auth?.showOtpOnScreen };
  }

  function verifyLogin(db, code, name) {
    const o = db.otp;
    if (!o) return { ok: false, error: "Ask for a new code." };
    if (o.expiresAt < E.localISO(new Date())) { db.otp = null; return { ok: false, error: "That code expired. Send a new one." }; }
    o.attempts++;
    if (o.attempts > 5) { db.otp = null; return { ok: false, error: "Too many tries. Start again." }; }
    if (String(code).trim() !== o.code) return { ok: false, error: `Wrong code. ${6 - o.attempts} tries left.` };

    const c = upsertCustomer(db, name || "", o.isEmail ? "" : o.identifier, o.isEmail ? o.identifier : "");
    c.verified = true;
    db.session = { role: "CUSTOMER", userId: c.id, name: c.name, phone: c.phone, email: c.email };
    db.otp = null;
    audit(db, "LOGIN", "customer", c.id, o.isEmail ? "email" : "phone");
    return { ok: true, customer: c, isNew: !c.name };
  }

  function logout(db) {
    audit(db, "LOGOUT", "customer", db.session?.userId || "-", "");
    db.session = { role: "CUSTOMER", userId: null, name: null, phone: null };
  }

  function updateProfile(db, patch) {
    const c = db.customers.find((x) => x.id === db.session?.userId);
    if (!c) return { ok: false };
    const L = db.settings.loyalty;
    const hadDob = !!c.dob;
    Object.assign(c, patch);
    if (!hadDob && c.dob && L?.enabled && L.birthdayBonus)
      addPoints(db, c.id, L.birthdayBonus, "Birthday added — here's a gift", null);
    db.session.name = c.name;
    audit(db, "PROFILE_UPDATE", "customer", c.id, Object.keys(patch).join(","));
    return { ok: true, customer: c };
  }

  // ---------------- the hold (this is the critical section) ----------------
  /* Mirrors the production transaction:
       1. validate business rules
       2. find free stations for the WHOLE block
       3. re-check overlap immediately before insert  (no await in between)
       4. insert Booking + BookingStation rows
       5. verify no duplicate slipped in; if it did, roll back → SLOT_TAKEN
     Returns { ok, bookingId, code, price } or { ok:false, code, errors }        */
  function holdBooking(db, { stationTypeId, stationCount = 1, startISO, hours, addonIds = [], couponCode = null,
    name, phone, email, source = "WEB", forceStationId = null, createdBy = "customer",
    customerId = null, redeemPoints = 0 }) {
    const S = db.settings;
    const errors = E.validateBooking({ startISO, hours, settings: S });
    if (errors.length) return { ok: false, code: "INVALID", errors };

    const type = S.stationTypes.find((t) => t.id === stationTypeId);
    if (!type) return { ok: false, code: "INVALID", errors: ["Unknown station type"] };

    let chosen;
    if (forceStationId) {
      const st = db.stations.find((s) => s.id === forceStationId);
      const fits = st && E.canFit({ stationId: forceStationId, startISO, hours, bookingStations: db.bookingStations, bookings: db.bookings, settings: S, stations: db.stations });
      if (!fits) return { ok: false, code: "SLOT_TAKEN", errors: ["That station is already booked."] };
      chosen = [st];
    } else {
      const free = E.freeStationsFor({ stationTypeId, startISO, hours, stations: db.stations, bookingStations: db.bookingStations, bookings: db.bookings, settings: S });
      if (free.length < stationCount)
        return { ok: false, code: "SLOT_TAKEN", errors: [`Only ${free.length} ${type.name}(s) free for that whole block.`], available: free.length };
      chosen = free.slice(0, stationCount);
    }

    const endISO = E.addMin(startISO, hours * 60);
    const slots = [];
    for (let m = 0; m < hours * 60; m += S.booking.slotMinutes) {
      const s = E.addMin(startISO, m);
      slots.push({ start: s, end: E.addMin(s, S.booking.slotMinutes) });
    }
    const priced = E.priceBooking({ stationType: type, slots, stationCount: chosen.length, addonIds, settings: S });

    const customer = customerId
      ? db.customers.find((x) => x.id === customerId)
      : (phone || email) ? upsertCustomer(db, name, phone, email) : null;
    const mi = customer ? memberInfo(db, customer.id) : null;
    const memberPercent = mi ? mi.discountPercent : 0;
    // Never let a client redeem more than the cap allows — recheck server-side.
    const cap = customer && redeemPoints > 0
      ? E.maxRedeemable(customer.points || 0, priced.gamingPaise + priced.addonPaise, S) : { points: 0 };
    const usePoints = Math.min(redeemPoints || 0, cap.points || 0);

    const tot = E.totals({
      gamingPaise: priced.gamingPaise, addonPaise: priced.addonPaise, couponCode, kind: "GAMING",
      memberPercent, redeemPoints: usePoints, settings: S,
    });
    const booking = {
      id: uid("b"), code: bookingCode(), status: "HELD",
      customerId: customer?.id || null, guestName: name || "", guestPhone: phone || "",
      stationTypeId, startAt: startISO, endAt: endISO, hours, playerCount: stationCount * (type.seats || 1),
      addonIds: [...addonIds], couponCode: tot.coupon ? tot.coupon.code : null,
      subtotalPaise: tot.subtotalPaise, discountPaise: tot.discountPaise, taxPaise: tot.taxPaise,
      totalPaise: tot.totalPaise, paidPaise: 0, taxBreakup: tot.taxBreakup,
      memberPercent, memberPaise: tot.memberPaise, redeemPoints: usePoints, pointsPaise: tot.pointsPaise,
      pointsEarned: 0, tierAtBooking: mi ? mi.tier.id : null,
      source, createdBy, createdAt: E.localISO(new Date()),
      holdExpiresAt: E.addMin(E.localISO(new Date()), S.booking.holdMinutes),
      checkedInAt: null, actualEndAt: null, notes: "", invoiceNo: null,
    };

    // --- insert, then verify uniqueness (the partial-index backstop) ---
    const newRows = chosen.map((st) => ({ id: uid("bs"), bookingId: booking.id, stationId: st.id, startAt: startISO, endAt: endISO, ratePaiseSnapshot: E.toPaise(type.hourly) }));
    db.bookings.push(booking);
    db.bookingStations.push(...newRows);

    const clash = newRows.some((row) =>
      db.bookingStations.some((other) => {
        if (other.id === row.id || other.stationId !== row.stationId) return false;
        const ob = db.bookings.find((b) => b.id === other.bookingId);
        if (!ob || !E.BLOCKING.includes(ob.status)) return false;
        return E.overlaps(row.startAt, row.endAt, other.startAt, other.endAt);
      })
    );
    if (clash) {                                     // roll back completely
      db.bookings = db.bookings.filter((b) => b.id !== booking.id);
      db.bookingStations = db.bookingStations.filter((r) => r.bookingId !== booking.id);
      return { ok: false, code: "SLOT_TAKEN", errors: ["Someone just took that slot."], bookingId: booking.id };
    }

    if (usePoints > 0 && customer)
      addPoints(db, customer.id, -usePoints, `Redeemed on ${booking.code}`, booking.id);
    audit(db, "HOLD", "booking", booking.id, `${chosen.map((c) => c.id).join(",")} ${startISO} +${hours}h`);
    return { ok: true, bookingId: booking.id, code: booking.code, stationIds: chosen.map((c) => c.id), price: tot, breakdown: priced };
  }

  function expireHolds(db, nowISO) {
    const now = nowISO || E.localISO(new Date());
    let n = 0;
    for (const b of db.bookings) {
      if ((b.status === "HELD" || b.status === "PENDING_PAYMENT") && b.holdExpiresAt && b.holdExpiresAt < now) {
        b.status = "EXPIRED"; n++;
        audit(db, "EXPIRE", "booking", b.id, "hold timed out");
      }
    }
    return n;
  }

  // ---------------- payment ----------------
  /* Idempotent: the same idempotencyKey never creates a second payment. */
  function confirmPayment(db, bookingId, { method = "UPI", idempotencyKey = null, amountPaise = null, utr = null, manual = false } = {}) {
    const b = db.bookings.find((x) => x.id === bookingId);
    if (!b) return { ok: false, error: "Booking not found" };
    const key = idempotencyKey || uid("idem");
    const existing = db.payments.find((p) => p.idempotencyKey === key);
    if (existing) return { ok: true, paymentId: existing.id, replayed: true, booking: b };

    const amt = amountPaise == null ? b.totalPaise : amountPaise;
    const p = {
      id: uid("pay"), bookingId, orderId: null, method, amountPaise: amt,
      status: manual ? "AWAITING_VERIFICATION" : "CAPTURED",
      idempotencyKey: key, utr: utr || null, at: E.localISO(new Date()),
      providerPaymentId: "mock_" + Math.random().toString(36).slice(2, 12),
    };
    db.payments.push(p);

    if (!manual) {
      b.paidPaise += amt;
      b.status = "CONFIRMED";
      b.invoiceNo = db.settings.brand.invoicePrefix + String(db.counters.invoice++).padStart(4, "0");
      const c = db.customers.find((x) => x.id === b.customerId);
      if (c) {
        c.visits++; c.spendPaise += amt;
        b.pointsEarned = awardPointsFor(db, c.id, { gamingPaise: b.subtotalPaise, refId: b.id, label: b.code });
      }
    } else {
      b.status = "PENDING_PAYMENT";
    }
    audit(db, manual ? "PAYMENT_PENDING" : "PAYMENT_CAPTURED", "booking", bookingId, `${method} ${E.fmt(amt)}`);
    return { ok: true, paymentId: p.id, booking: b, replayed: false };
  }

  function markPayAtCounter(db, bookingId) {
    const b = db.bookings.find((x) => x.id === bookingId);
    if (!b) return { ok: false };
    b.status = "CONFIRMED";
    b.paidPaise = 0;
    b.holdExpiresAt = null;
    b.invoiceNo = db.settings.brand.invoicePrefix + String(db.counters.invoice++).padStart(4, "0");
    audit(db, "PAY_AT_COUNTER", "booking", bookingId, "unpaid, collect at venue");
    return { ok: true, booking: b };
  }

  function verifyManualPayment(db, paymentId) {
    const p = db.payments.find((x) => x.id === paymentId);
    if (!p) return { ok: false };
    p.status = "CAPTURED";
    const b = db.bookings.find((x) => x.id === p.bookingId);
    if (b) {
      b.paidPaise += p.amountPaise;
      b.status = "CONFIRMED";
      if (!b.invoiceNo) b.invoiceNo = db.settings.brand.invoicePrefix + String(db.counters.invoice++).padStart(4, "0");
    }
    audit(db, "MANUAL_UPI_VERIFIED", "payment", paymentId, p.utr || "");
    return { ok: true };
  }

  // ---------------- lifecycle ----------------
  function cancelBooking(db, bookingId, reason = "Customer cancelled") {
    const b = db.bookings.find((x) => x.id === bookingId);
    if (!b) return { ok: false };
    const r = E.refundFor(b.startAt, E.localISO(new Date()), b.paidPaise, db.settings);
    b.status = "CANCELLED";
    b.cancelReason = reason;
    // Give redeemed points back, and claw back points earned on this booking.
    if (b.customerId) {
      if (b.redeemPoints > 0) addPoints(db, b.customerId, b.redeemPoints, `Points returned from ${b.code}`, b.id);
      if (b.pointsEarned > 0) addPoints(db, b.customerId, -b.pointsEarned, `Points reversed — ${b.code} cancelled`, b.id);
    }
    if (r.refundPaise > 0) {
      db.refunds.push({ id: uid("rf"), bookingId, amountPaise: r.refundPaise, percent: r.percent, reason, at: E.localISO(new Date()), status: "PROCESSED" });
    }
    audit(db, "CANCEL", "booking", bookingId, `${reason} · refund ${E.fmt(r.refundPaise)} (${r.percent}%)`);
    return { ok: true, refund: r };
  }

  function checkIn(db, bookingId) {
    const b = db.bookings.find((x) => x.id === bookingId);
    if (!b) return { ok: false };
    b.status = "IN_PROGRESS"; b.checkedInAt = E.localISO(new Date());
    for (const bs of db.bookingStations.filter((r) => r.bookingId === bookingId)) {
      const st = db.stations.find((s) => s.id === bs.stationId);
      if (st) st.status = "OCCUPIED";
    }
    audit(db, "CHECK_IN", "booking", bookingId, "");
    return { ok: true };
  }

  function checkOut(db, bookingId) {
    const b = db.bookings.find((x) => x.id === bookingId);
    if (!b) return { ok: false };
    b.status = "COMPLETED"; b.actualEndAt = E.localISO(new Date());
    for (const bs of db.bookingStations.filter((r) => r.bookingId === bookingId)) {
      const st = db.stations.find((s) => s.id === bs.stationId);
      if (st && st.status === "OCCUPIED") st.status = "AVAILABLE";
    }
    audit(db, "CHECK_OUT", "booking", bookingId, "");
    return { ok: true };
  }

  function markNoShow(db, bookingId) {
    const b = db.bookings.find((x) => x.id === bookingId);
    if (!b) return { ok: false };
    b.status = "NO_SHOW";
    const c = db.customers.find((x) => x.id === b.customerId);
    if (c) c.noShows++;
    audit(db, "NO_SHOW", "booking", bookingId, "");
    return { ok: true };
  }

  /* Extend a live session — only if the NEXT block is still free. */
  function extendBooking(db, bookingId, extraMinutes) {
    const b = db.bookings.find((x) => x.id === bookingId);
    if (!b) return { ok: false, error: "Not found" };
    const rows = db.bookingStations.filter((r) => r.bookingId === bookingId);
    const newEnd = E.addMin(b.endAt, extraMinutes);
    for (const row of rows) {
      const clash = db.bookingStations.some((other) => {
        if (other.bookingId === bookingId || other.stationId !== row.stationId) return false;
        const ob = db.bookings.find((x) => x.id === other.bookingId);
        if (!ob || !E.BLOCKING.includes(ob.status)) return false;
        return E.overlaps(b.endAt, newEnd, other.startAt, other.endAt);
      });
      if (clash) return { ok: false, error: "The next slot is already booked on " + row.stationId };
    }
    const type = db.settings.stationTypes.find((t) => t.id === b.stationTypeId);
    const slots = [];
    for (let m = 0; m < extraMinutes; m += db.settings.booking.slotMinutes) {
      const s = E.addMin(b.endAt, m);
      slots.push({ start: s, end: E.addMin(s, db.settings.booking.slotMinutes) });
    }
    const priced = E.priceBooking({ stationType: type, slots, stationCount: rows.length, addonIds: [], settings: db.settings });
    const tot = E.totals({ gamingPaise: priced.gamingPaise, settings: db.settings });
    b.endAt = newEnd; b.hours += extraMinutes / 60;
    b.subtotalPaise += tot.subtotalPaise; b.taxPaise += tot.taxPaise; b.totalPaise += tot.totalPaise;
    rows.forEach((r) => (r.endAt = newEnd));
    audit(db, "EXTEND", "booking", bookingId, `+${extraMinutes}m ${E.fmt(tot.totalPaise)}`);
    return { ok: true, addedPaise: tot.totalPaise };
  }

  function setStationStatus(db, stationId, status, note = "") {
    const st = db.stations.find((s) => s.id === stationId);
    if (!st) return { ok: false };
    st.status = status; st.maintenanceNote = note;
    audit(db, "STATION_STATUS", "station", stationId, status + " " + note);
    return { ok: true };
  }

  function joinWaitlist(db, { name, phone, startISO, stationTypeId, partySize }) {
    db.waitlist.push({ id: uid("w"), name, phone, startISO, stationTypeId, partySize, at: E.localISO(new Date()), notified: false });
    audit(db, "WAITLIST", "waitlist", phone, startISO);
    return { ok: true };
  }

  // ---------------- food orders ----------------
  function createOrder(db, { type = "DINE_IN", tableId = null, bookingId = null, items, name, phone, email,
    couponCode = null, tipPaise = 0, method = "UPI", source = "WEB", customerId = null, redeemPoints = 0 }) {
    if (!items || !items.length) return { ok: false, error: "Cart is empty" };
    let food = 0;
    const lines = items.map((it) => {
      const mi = db.menuItems.find((m) => m.id === it.itemId);
      const line = mi.pricePaise * it.qty;
      food += line;
      return { id: uid("oi"), menuItemId: mi.id, name: mi.name, qty: it.qty, unitPricePaise: mi.pricePaise, lineTotalPaise: line, note: it.note || "", status: "PENDING", prepMinutes: mi.prepMinutes };
    });
    const customer = customerId
      ? db.customers.find((x) => x.id === customerId)
      : (phone || email) ? upsertCustomer(db, name, phone, email) : null;
    const mi = customer ? memberInfo(db, customer.id) : null;
    const memberPercent = mi ? mi.discountPercent : 0;
    const cap = customer && redeemPoints > 0 ? E.maxRedeemable(customer.points || 0, food, db.settings) : { points: 0 };
    const usePoints = Math.min(redeemPoints || 0, cap.points || 0);
    const tot = E.totals({ foodPaise: food, couponCode, kind: "FOOD", tipPaise, memberPercent,
      redeemPoints: usePoints, settings: db.settings });
    const order = {
      id: uid("o"), code: "ORD-" + String(db.orders.length + 1001), type, tableId, bookingId,
      customerId: customer?.id || null, guestName: name || "", guestPhone: phone || "",
      status: "PLACED", placedAt: E.localISO(new Date()), acceptedAt: null, readyAt: null, servedAt: null,
      subtotalPaise: tot.subtotalPaise, discountPaise: tot.discountPaise, taxPaise: tot.taxPaise,
      tipPaise, totalPaise: tot.totalPaise, taxBreakup: tot.taxBreakup, couponCode: tot.coupon?.code || null,
      paymentMethod: method, source,
      invoiceNo: db.settings.brand.invoicePrefix + String(db.counters.invoice++).padStart(4, "0"),
      etaMinutes: Math.max(...lines.map((l) => l.prepMinutes)),
    };
    db.orders.push(order);
    db.orderItems.push(...lines.map((l) => ({ ...l, orderId: order.id })));
    db.payments.push({ id: uid("pay"), bookingId: null, orderId: order.id, method, amountPaise: tot.totalPaise, status: method === "CASH" || method === "COUNTER" ? "PENDING" : "CAPTURED", idempotencyKey: uid("idem"), at: E.localISO(new Date()) });
    order.memberPercent = memberPercent;
    order.redeemPoints = usePoints;
    if (customer) {
      customer.visits++; customer.spendPaise += tot.totalPaise;
      if (usePoints > 0) addPoints(db, customer.id, -usePoints, `Redeemed on ${order.code}`, order.id);
      order.pointsEarned = awardPointsFor(db, customer.id, { foodPaise: tot.subtotalPaise, refId: order.id, label: order.code });
    }
    audit(db, "ORDER_PLACED", "order", order.id, `${type} ${E.fmt(tot.totalPaise)}`);
    return { ok: true, orderId: order.id, code: order.code, order };
  }

  function advanceOrder(db, orderId, status) {
    const o = db.orders.find((x) => x.id === orderId);
    if (!o) return { ok: false };
    o.status = status;
    const stamp = E.localISO(new Date());
    if (status === "ACCEPTED") o.acceptedAt = stamp;
    if (status === "READY") o.readyAt = stamp;
    if (status === "SERVED" || status === "COMPLETED") o.servedAt = stamp;
    audit(db, "ORDER_" + status, "order", orderId, "");
    return { ok: true };
  }

  // ---------------- demo data ----------------
  function nextOpenSlot(db, daysAhead = 1) {
    for (let d = daysAhead; d < daysAhead + 20; d++) {
      const day = new Date(); day.setDate(day.getDate() + d);
      const slots = E.slotsForDate(E.dateKey(day), db.settings);
      if (slots.length) return slots[Math.floor(slots.length / 2)].start;
    }
    return null;
  }

  function seedDemo(db) {
    _s = 20260811;
    const today = new Date();

    /* A fixed pool of regulars, so the CRM shows real repeat behaviour instead
       of one-visit-per-person. Weighted: a few heavy regulars, a long tail. */
    const SURNAMES = ["Sen", "Das", "Roy", "Ghosh", "Banerjee", "Dutta", "Bose", "Chatterjee", "Mitra", "Saha",
      "Sharma", "Verma", "Singh", "Nair", "Iyer", "Khan", "Ali", "Gupta", "Jain", "Mukherjee"];
    const pool = [];
    for (let i = 0; i < 120; i++) {
      pool.push({
        name: `${NAMES[i % NAMES.length]} ${SURNAMES[Math.floor(rnd() * SURNAMES.length)]}`,
        phone: "9" + String(300000000 + i * 7919 + Math.floor(rnd() * 900)),
        weight: i < 12 ? 8 : i < 40 ? 3 : 1,          // regulars vs occasionals
      });
    }
    const bag = [];
    pool.forEach((c, i) => { for (let k = 0; k < c.weight; k++) bag.push(i); });
    const someone = () => pool[bag[Math.floor(rnd() * bag.length)]];
    // 60 days back, 14 days forward
    for (let d = -60; d <= 14; d++) {
      const day = new Date(today); day.setDate(today.getDate() + d);
      const dateStr = E.dateKey(day);
      const slots = E.slotsForDate(dateStr, db.settings);
      if (!slots.length) continue;
      const dow = day.getDay();
      const busy = dow === 0 || dow === 5 || dow === 6 ? 0.55 : 0.3;
      const past = d < 0;

      for (const slot of slots) {
        const hr = Number(slot.start.split("T")[1].split(":")[0]);
        const weight = hr >= 17 ? busy * 1.7 : hr >= 14 ? busy : busy * 0.5;
        for (const type of db.settings.stationTypes) {
          const pool = db.stations.filter((s) => s.stationTypeId === type.id);
          const want = Math.min(pool.length, Math.round(pool.length * weight * (0.6 + rnd() * 0.8)));
          if (want <= 0) continue;
          const who = someone();
          const name = who.name, phone = who.phone;
          const r = holdBooking(db, {
            stationTypeId: type.id, stationCount: want, startISO: slot.start,
            hours: db.settings.booking.slotMinutes === 60 ? 1 : 1, addonIds: rnd() > 0.8 ? ["ctrl"] : [],
            name, phone, source: pick(["WEB", "ANDROID", "COUNTER", "PHONE"]),
          });
          if (!r.ok) continue;
          const b = db.bookings.find((x) => x.id === r.bookingId);
          b.createdAt = E.addMin(slot.start, -rint(30, 4000));
          if (past) {
            const roll = rnd();
            if (roll < 0.06) { b.status = "CANCELLED"; }
            else if (roll < 0.10) { b.status = "NO_SHOW"; }
            else {
              confirmPayment(db, b.id, { method: pick(["UPI", "UPI", "UPI", "CARD", "CASH"]) });
              b.status = "COMPLETED"; b.checkedInAt = slot.start; b.actualEndAt = b.endAt;
            }
          } else {
            if (rnd() < 0.8) confirmPayment(db, b.id, { method: pick(["UPI", "UPI", "CARD"]) });
            else markPayAtCounter(db, b.id);
          }
        }
      }

      // food orders
      const nOrders = rint(past ? 4 : 1, past ? 14 : 4);
      for (let i = 0; i < nOrders; i++) {
        const picks = [];
        for (let k = 0; k < rint(1, 4); k++) {
          const mi = pick(db.menuItems);
          picks.push({ itemId: mi.id, qty: rint(1, 2) });
        }
        const who2 = someone();
        const r = createOrder(db, {
          type: pick(["DINE_IN", "DINE_IN", "IN_SESSION", "TAKEAWAY"]),
          tableId: pick(db.tables).id, items: picks, name: who2.name,
          phone: who2.phone,
          method: pick(["UPI", "UPI", "CASH", "CARD"]), source: pick(["WEB", "ANDROID", "COUNTER"]),
        });
        const o = db.orders.find((x) => x.id === r.orderId);
        const hh = String(rint(11, 22)).padStart(2, "0");
        o.placedAt = `${dateStr}T${hh}:${String(rint(0, 59)).padStart(2, "0")}`;
        o.status = past ? "COMPLETED" : pick(["PLACED", "ACCEPTED", "PREPARING", "READY", "COMPLETED"]);
      }
    }

    /* Loyalty is derived from real spend, so tiers spread naturally across the
       pool. Top up a few regulars with visible bonus history. */
    db.customers.forEach((c) => {
      if (!c.referralCode) c.referralCode = refCode(c.name);
      if (rnd() < 0.18) addPoints(db, c.id, 250, "Birthday gift", null);
      if (rnd() < 0.12) addPoints(db, c.id, 200, "Referred a friend", null);
    });

    // A ready-made signed-in account so loyalty is visible the moment you open it.
    const demo = db.customers.sort((a, b) => b.spendPaise - a.spendPaise)[2];
    if (demo) { demo.name = "Demo Player"; demo.phone = "9999900001"; demo.email = "demo@respawn.in"; demo.verified = true; demo.dob = "1999-04-12"; }

    // a couple of live states so the demo looks alive on first open
    const st = db.stations.find((s) => s.stationTypeId === "pc");
    if (st) setStationStatus(db, db.stations[db.stations.length - 1].id, "MAINTENANCE", "GPU replacement, back Friday");
    audit(db, "SEED", "db", "-", `${db.bookings.length} bookings, ${db.orders.length} orders`);
    return db;
  }

  // ---------------- persistence ----------------
  const SCHEMA = 2;

  /* Forward-only migrations. Anyone who opened an earlier build has data saved
     without the loyalty tables, so upgrade it in place rather than crashing or
     wiping their bookings. */
  function migrate(db, cfg) {
    const from = db.version || 1;
    if (from < 2) {
      db.settings.loyalty = db.settings.loyalty || JSON.parse(JSON.stringify(cfg.loyalty));
      db.settings.auth = db.settings.auth || JSON.parse(JSON.stringify(cfg.auth));
      db.loyalty = db.loyalty || [];
      db.otp = null;
      db.session = db.session || { role: "CUSTOMER", userId: null, name: null, phone: null };
      db.customers.forEach((c) => {
        if (c.points === undefined) c.points = 0;
        if (c.lifetimePoints === undefined) c.lifetimePoints = 0;
        if (!c.referralCode) c.referralCode = refCode(c.name);
        if (c.email === undefined) c.email = "";
        if (c.dob === undefined) c.dob = "";
        if (c.referredBy === undefined) c.referredBy = null;
        if (c.marketingOptIn === undefined) c.marketingOptIn = false;
        if (c.verified === undefined) c.verified = false;
      });
      db.bookings.forEach((b) => {
        if (b.pointsEarned === undefined) b.pointsEarned = 0;
        if (b.redeemPoints === undefined) b.redeemPoints = 0;
        if (b.memberPercent === undefined) b.memberPercent = 0;
      });
      db.orders.forEach((o) => { if (o.pointsEarned === undefined) o.pointsEarned = 0; });
      db.version = 2;
      audit(db, "MIGRATE", "db", "-", `v${from} → v2 (loyalty + accounts)`);
    }
    // Any settings group added to config after the DB was created.
    for (const k of ["loyalty", "auth", "payments", "tax", "booking"])
      if (!db.settings[k] && cfg[k]) db.settings[k] = JSON.parse(JSON.stringify(cfg[k]));
    return db;
  }

  function load(cfg) {
    if (typeof localStorage === "undefined") return seedDemo(baseDb(cfg));
    try {
      const raw = localStorage.getItem(KEY);
      if (raw) {
        const db = JSON.parse(raw);
        if (db.version >= 1 && db.version <= SCHEMA) {
          migrate(db, cfg);
          expireHolds(db);
          save(db);
          return db;
        }
      }
    } catch (e) { console.warn("DB read failed, reseeding", e); }
    const db = seedDemo(baseDb(cfg));
    save(db);
    return db;
  }
  function save(db) {
    if (typeof localStorage === "undefined") return;
    try { localStorage.setItem(KEY, JSON.stringify(db)); }
    catch (e) { console.warn("DB write failed (quota?)", e); }
  }
  function reset(cfg) {
    if (typeof localStorage !== "undefined") localStorage.removeItem(KEY);
    return load(cfg);
  }
  function wipeDemo(cfg) {
    const db = baseDb(cfg);
    save(db);
    return db;
  }

  function freshTestDb() { return baseDb(g.CONFIG); }

  g.Store = {
    SCHEMA, migrate, baseDb, seedDemo, load, save, reset, wipeDemo, freshTestDb, nextOpenSlot,
    holdBooking, expireHolds, confirmPayment, markPayAtCounter, verifyManualPayment,
    cancelBooking, checkIn, checkOut, markNoShow, extendBooking, setStationStatus,
    joinWaitlist, createOrder, advanceOrder, upsertCustomer, audit, uid,
    addPoints, memberInfo, awardPointsFor, applyReferral, refCode,
    startLogin, verifyLogin, logout, updateProfile,
  };
})(typeof globalThis !== "undefined" ? globalThis : this);
