/* ============================================================
   ENGINE — pure logic. No DOM, no storage.
   Slot generation · availability · pricing · tax · refunds.
   Money is ALWAYS integer paise. Never floats.
   Times are "YYYY-MM-DDTHH:MM" in venue-local time.
   (Production note: the real build stores timestamptz in UTC;
    this demo uses local strings because there is one venue.)
   ============================================================ */
(function (g) {
  "use strict";

  // ---------- money ----------
  const rupees = (paise) => Math.round(paise) / 100;
  const toPaise = (rs) => Math.round(rs * 100);
  const fmt = (paise) =>
    "₹" + rupees(paise).toLocaleString("en-IN", { minimumFractionDigits: 0, maximumFractionDigits: 2 });

  // ---------- time ----------
  const pad = (n) => String(n).padStart(2, "0");
  const dateKey = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  const localISO = (d) => `${dateKey(d)}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
  const parseLocal = (s) => {
    const [dp, tp] = s.split("T");
    const [y, m, d] = dp.split("-").map(Number);
    const [hh, mm] = tp.split(":").map(Number);
    return new Date(y, m - 1, d, hh, mm, 0, 0);
  };
  const minutesOf = (hhmm) => {
    const [h, m] = hhmm.split(":").map(Number);
    return h * 60 + m;
  };
  const addMin = (iso, mins) => localISO(new Date(parseLocal(iso).getTime() + mins * 60000));
  const diffMin = (a, b) => Math.round((parseLocal(b) - parseLocal(a)) / 60000);
  const overlaps = (aStart, aEnd, bStart, bEnd) => aStart < bEnd && bStart < aEnd;

  // ---------- slot generation ----------
  // Returns [{start, end}] for a given YYYY-MM-DD, honouring opening hours.
  function slotsForDate(dateStr, settings) {
    const dow = parseLocal(dateStr + "T00:00").getDay();
    const h = (settings.hours || []).find((x) => x.day === dow);
    if (!h || h.closed) return [];
    const step = settings.booking.slotMinutes;
    const out = [];
    let m = Math.ceil(minutesOf(h.open) / step) * step;
    const closeM = minutesOf(h.close);
    while (m + step <= closeM + 1) {
      const start = `${dateStr}T${pad(Math.floor(m / 60) % 24)}:${pad(m % 60)}`;
      out.push({ start, end: addMin(start, step) });
      m += step;
    }
    return out;
  }

  // ---------- pricing ----------
  // Applies stacked PricingRules to a base hourly rate for ONE slot.
  // Returns paise for that slot.
  function slotPricePaise(stationType, slotStart, settings) {
    const base = toPaise(stationType.hourly) * (settings.booking.slotMinutes / 60);
    const d = parseLocal(slotStart);
    const dow = d.getDay();
    const mins = d.getHours() * 60 + d.getMinutes();
    const rules = (settings.pricingRules || [])
      .filter((r) => r.scope === "*" || r.scope === stationType.id)
      .filter((r) => (r.days || []).includes(dow))
      .filter((r) => mins >= minutesOf(r.from) && mins < minutesOf(r.to))
      .sort((a, b) => (a.priority || 0) - (b.priority || 0));

    let price = base;
    const applied = [];
    for (const r of rules) {
      if (r.type === "PERCENT") price = price * (1 + r.value / 100);
      else if (r.type === "FLAT") price = price + toPaise(r.value);
      else if (r.type === "OVERRIDE") price = toPaise(r.value) * (settings.booking.slotMinutes / 60);
      applied.push(r.label);
    }
    return { paise: Math.round(price), rules: applied, basePaise: base };
  }

  // Price a whole booking across N slots × M stations.
  function priceBooking({ stationType, slots, stationCount, addonIds, settings }) {
    let gaming = 0;
    const lines = [];
    for (const s of slots) {
      const p = slotPricePaise(stationType, s.start, settings);
      gaming += p.paise * stationCount;
      lines.push({ label: `${hhmm(s.start)}–${hhmm(s.end)}`, paise: p.paise * stationCount, rules: p.rules });
    }
    let addons = 0;
    const addonLines = [];
    for (const id of addonIds || []) {
      const a = (settings.addons || []).find((x) => x.id === id);
      if (a) {
        addons += toPaise(a.price);
        addonLines.push({ label: a.name, paise: toPaise(a.price) });
      }
    }
    return { gamingPaise: gaming, addonPaise: addons, lines, addonLines };
  }

  const hhmm = (iso) => iso.split("T")[1];

  // ---------- coupons ----------
  // kind: "GAMING" | "FOOD"
  function applyCoupon(code, subtotalPaise, kind, settings) {
    if (!code) return { discountPaise: 0, coupon: null, error: null };
    const c = (settings.coupons || []).find((x) => x.code.toUpperCase() === code.trim().toUpperCase());
    if (!c) return { discountPaise: 0, coupon: null, error: "Coupon not found" };
    if (c.appliesTo !== "BOTH" && c.appliesTo !== kind)
      return { discountPaise: 0, coupon: null, error: `Not valid on ${kind.toLowerCase()}` };
    if (subtotalPaise < toPaise(c.minSpend || 0))
      return { discountPaise: 0, coupon: null, error: `Minimum spend ${fmt(toPaise(c.minSpend))}` };
    let d = c.type === "PERCENT" ? Math.round((subtotalPaise * c.value) / 100) : toPaise(c.value);
    if (c.maxDiscount) d = Math.min(d, toPaise(c.maxDiscount));
    d = Math.min(d, subtotalPaise);
    return { discountPaise: d, coupon: c, error: null };
  }

  // ---------- tax ----------
  // Tax is computed PER LINE because one cart can mix 5% food and 18% gaming.
  function computeTax(gamingTaxablePaise, foodTaxablePaise, settings) {
    if (!settings.tax.registered)
      return { taxPaise: 0, breakup: [], registered: false };
    const b = [];
    let total = 0;
    const add = (label, taxable, pct) => {
      if (taxable <= 0) return;
      const t = Math.round((taxable * pct) / 100);
      total += t;
      b.push({ label, taxablePaise: taxable, percent: pct, taxPaise: t });
    };
    add("Gaming (SAC 9996)", gamingTaxablePaise, settings.tax.gamingPercent);
    add("Food (restaurant, no ITC)", foodTaxablePaise, settings.tax.foodPercent);
    return { taxPaise: total, breakup: b, registered: true, interState: settings.tax.interState };
  }

  // ---------- loyalty ----------
  /* Tier from lifetime spend. Returns current tier, the next one, and progress. */
  function tierFor(spendPaise, settings) {
    const L = settings.loyalty;
    const tiers = [...L.tiers].sort((a, b) => a.minSpend - b.minSpend);
    let cur = tiers[0];
    for (const t of tiers) if (spendPaise >= toPaise(t.minSpend)) cur = t;
    const next = tiers.find((t) => toPaise(t.minSpend) > spendPaise) || null;
    const floor = toPaise(cur.minSpend);
    const ceil = next ? toPaise(next.minSpend) : floor;
    const progress = next ? Math.min(100, ((spendPaise - floor) / Math.max(1, ceil - floor)) * 100) : 100;
    return {
      tier: cur, next, progress,
      toNextPaise: next ? Math.max(0, ceil - spendPaise) : 0,
      discountPercent: cur.discountPercent || 0,
    };
  }

  /* Points earned on a transaction. Gaming earns a multiplier; tier adds a bonus. */
  function pointsEarned({ gamingPaise = 0, foodPaise = 0, tier = null, settings }) {
    const L = settings.loyalty;
    if (!L.enabled) return { points: 0, base: 0, bonus: 0 };
    const per = L.pointsPerHundred / 10000;                       // points per paise
    const base = Math.floor(gamingPaise * per * L.gamingMultiplier + foodPaise * per);
    const bonusPct = tier?.earnBonus || 0;
    const bonus = Math.floor((base * bonusPct) / 100);
    return { points: base + bonus, base, bonus, bonusPct };
  }

  /* What a points balance is worth, and the most that may be used on this bill. */
  function redeemValuePaise(points, settings) {
    return Math.round(points * toPaise(settings.loyalty.rupeesPerPoint));
  }
  function maxRedeemable(balance, billPaise, settings) {
    const L = settings.loyalty;
    if (!L.enabled || balance < L.minRedeemPoints) return { points: 0, valuePaise: 0, reason: balance < L.minRedeemPoints ? `Need at least ${L.minRedeemPoints} points` : null };
    const capPaise = Math.floor((billPaise * L.maxRedeemPercent) / 100);
    const perPoint = toPaise(L.rupeesPerPoint);
    const capPoints = Math.floor(capPaise / perPoint);
    const points = Math.max(0, Math.min(balance, capPoints));
    return { points, valuePaise: redeemValuePaise(points, settings), reason: null, capPercent: L.maxRedeemPercent };
  }

  // ---------- totals ----------
  function totals({ gamingPaise = 0, addonPaise = 0, foodPaise = 0, couponCode = null, kind = "GAMING",
                    tipPaise = 0, memberPercent = 0, redeemPoints = 0, settings }) {
    const subtotal = gamingPaise + addonPaise + foodPaise;
    const { discountPaise: couponPaise, coupon, error } = applyCoupon(couponCode, subtotal, kind, settings);
    // Member (tier) discount stacks on top of any coupon.
    const memberPaise = memberPercent > 0 ? Math.round(((subtotal - couponPaise) * memberPercent) / 100) : 0;
    // Points redemption is a discount too, capped by maxRedeemable upstream.
    const pointsPaise = redeemPoints > 0 ? redeemValuePaise(redeemPoints, settings) : 0;
    const discountPaise = Math.min(subtotal, couponPaise + memberPaise + pointsPaise);
    // Spread the discount proportionally so per-line tax stays correct.
    const share = subtotal > 0 ? discountPaise / subtotal : 0;
    const gamingTaxable = Math.round((gamingPaise + addonPaise) * (1 - share));
    const foodTaxable = Math.round(foodPaise * (1 - share));
    const tax = computeTax(gamingTaxable, foodTaxable, settings);
    const beforeRound = gamingTaxable + foodTaxable + tax.taxPaise + tipPaise;
    const total = Math.round(beforeRound / 100) * 100; // round to nearest rupee
    return {
      subtotalPaise: subtotal,
      discountPaise,
      couponPaise, memberPaise, pointsPaise, memberPercent, redeemPoints,
      coupon,
      couponError: error,
      gamingTaxablePaise: gamingTaxable,
      foodTaxablePaise: foodTaxable,
      taxPaise: tax.taxPaise,
      taxBreakup: tax.breakup,
      taxRegistered: tax.registered,
      interState: tax.interState,
      tipPaise,
      roundOffPaise: total - beforeRound,
      totalPaise: total,
    };
  }

  // ---------- refunds ----------
  // Pure: given a booking start and "now", how much of paid is refundable?
  function refundFor(startISO, nowISO, paidPaise, settings) {
    const hoursLeft = diffMin(nowISO, startISO) / 60;
    const bands = [...(settings.refundPolicy || [])].sort((a, b) => b.minHoursBefore - a.minHoursBefore);
    const band = bands.find((b) => hoursLeft >= b.minHoursBefore) || { refundPercent: 0, minHoursBefore: 0 };
    return {
      hoursLeft,
      percent: band.refundPercent,
      refundPaise: Math.round((paidPaise * band.refundPercent) / 100),
    };
  }

  // ---------- availability ----------
  const BLOCKING = ["HELD", "PENDING_PAYMENT", "CONFIRMED", "CHECKED_IN", "IN_PROGRESS"];

  /* Returns { slots:[{start,end}], grid: { [stationId]: [{state, price, bookingId}] } }
     States: AVAILABLE HELD BOOKED IN_PROGRESS MAINTENANCE CLOSED PAST BUFFER */
  function availability({ dateStr, stations, stationTypes, bookingStations, bookings, settings, nowISO }) {
    const slots = slotsForDate(dateStr, settings);
    const grid = {};
    const now = nowISO || localISO(new Date());
    const byId = Object.fromEntries(bookings.map((b) => [b.id, b]));

    for (const st of stations) {
      const type = stationTypes.find((t) => t.id === st.stationTypeId);
      grid[st.id] = slots.map((slot) => {
        const price = slotPricePaise(type, slot.start, settings).paise;

        if (slot.end <= now) return { ...slot, state: "PAST", pricePaise: price };
        if (st.status === "MAINTENANCE")
          return { ...slot, state: "MAINTENANCE", pricePaise: price, note: st.maintenanceNote };

        // occupied?
        const hit = bookingStations.find((bs) => {
          if (bs.stationId !== st.id) return false;
          const bk = byId[bs.bookingId];
          if (!bk || !BLOCKING.includes(bk.status)) return false;
          return overlaps(slot.start, slot.end, bs.startAt, bs.endAt);
        });
        if (hit) {
          const bk = byId[hit.bookingId];
          let state = "BOOKED";
          if (bk.status === "HELD" || bk.status === "PENDING_PAYMENT") state = "HELD";
          if (bk.status === "IN_PROGRESS" || bk.status === "CHECKED_IN") state = "IN_PROGRESS";
          return { ...slot, state, pricePaise: price, bookingId: bk.id, code: bk.code, holdExpiresAt: bk.holdExpiresAt };
        }

        // buffer: a session ends inside this slot's cleanup window
        const buf = settings.booking.bufferMinutes;
        if (buf > 0) {
          const inBuffer = bookingStations.some((bs) => {
            if (bs.stationId !== st.id) return false;
            const bk = byId[bs.bookingId];
            if (!bk || !BLOCKING.includes(bk.status)) return false;
            return overlaps(slot.start, slot.end, bs.endAt, addMin(bs.endAt, buf));
          });
          if (inBuffer) return { ...slot, state: "BUFFER", pricePaise: price };
        }
        return { ...slot, state: "AVAILABLE", pricePaise: price };
      });
    }
    return { slots, grid };
  }

  // Contiguous run of free slots for one station, starting at slotStart, length hours.
  function canFit({ stationId, startISO, hours, bookingStations, bookings, settings, stations }) {
    const st = stations.find((s) => s.id === stationId);
    if (!st || st.status === "MAINTENANCE") return false;
    const endISO = addMin(startISO, hours * 60);
    const buf = settings.booking.bufferMinutes;
    const byId = Object.fromEntries(bookings.map((b) => [b.id, b]));
    return !bookingStations.some((bs) => {
      if (bs.stationId !== stationId) return false;
      const bk = byId[bs.bookingId];
      if (!bk || !BLOCKING.includes(bk.status)) return false;
      return overlaps(startISO, endISO, bs.startAt, addMin(bs.endAt, buf));
    });
  }

  // Which stations of a type can take this whole block? (for group bookings)
  function freeStationsFor({ stationTypeId, startISO, hours, stations, bookingStations, bookings, settings }) {
    return stations
      .filter((s) => s.stationTypeId === stationTypeId && s.status !== "MAINTENANCE" && s.active !== false)
      .filter((s) => canFit({ stationId: s.id, startISO, hours, bookingStations, bookings, settings, stations }));
  }

  // ---------- validation ----------
  function validateBooking({ startISO, hours, settings, nowISO }) {
    const errs = [];
    const now = nowISO || localISO(new Date());
    if (startISO <= now) errs.push("That start time is in the past.");
    if (hours < settings.booking.minHours) errs.push(`Minimum booking is ${settings.booking.minHours} hour(s).`);
    if (hours > settings.booking.maxHours) errs.push(`Maximum booking is ${settings.booking.maxHours} hour(s).`);
    const daysAhead = (parseLocal(startISO) - parseLocal(now)) / 86400000;
    if (daysAhead > settings.booking.advanceDays) errs.push(`Bookings open only ${settings.booking.advanceDays} days ahead.`);
    const dateStr = startISO.split("T")[0];
    const day = slotsForDate(dateStr, settings);
    if (!day.length) errs.push("We're closed that day.");
    else {
      const endISO = addMin(startISO, hours * 60);
      if (endISO > day[day.length - 1].end) errs.push("That session runs past closing time.");
      if (startISO < day[0].start) errs.push("That's before we open.");
    }
    return errs;
  }

  g.Engine = {
    rupees, toPaise, fmt, pad, dateKey, localISO, parseLocal, minutesOf, addMin, diffMin, overlaps, hhmm,
    slotsForDate, slotPricePaise, priceBooking, applyCoupon, computeTax, totals, refundFor,
    availability, canFit, freeStationsFor, validateBooking, BLOCKING,
    tierFor, pointsEarned, redeemValuePaise, maxRedeemable,
  };
})(typeof globalThis !== "undefined" ? globalThis : this);
