# Respawn Café — working app (Phase A)

A complete gaming-café + cafeteria booking, ordering and point-of-sale system.
**No installation, no build step, no internet needed.** Open one file and it runs.

---

## 1. Run it right now

Unzip, then **double-click `index.html`**. That's it.

For the full experience (installable app + offline mode), serve it over HTTP instead —
service workers don't run from `file://`:

```bash
cd respawn-cafe-web
python3 -m http.server 8080      # or:  npx serve .
```

Then open **http://localhost:8080**

| Page | What it is |
|---|---|
| `index.html` | Customer site — book stations, order food, manage bookings |
| `admin.html` | Staff console — dashboard, bookings, KDS, POS, reports, settings |

It arrives pre-loaded with **74 days of realistic demo data** (345 bookings, 567 orders,
120 repeat customers) so every report, chart and heatmap has something real in it —
and so some future slots are *already sold out*, which is the state you asked to see.

---

## 2. Install it on your Android phone

There's no `.apk` in this package (see the note at the end), but you get something you can
use today. Serve the folder on your computer, then on your phone — same Wi-Fi:

1. Find your computer's local IP (`ipconfig` on Windows, `ifconfig | grep inet` on Mac/Linux)
2. Open `http://<that-ip>:8080` in **Chrome on Android**
3. Menu **⋮ → Add to Home screen** → **Install**

It installs as a real app: its own icon, no browser chrome, full screen, works offline,
opens instantly. On iOS it's Safari → Share → Add to Home Screen.

---

## 3. Make it yours — one file

Open **`assets/config.js`**. Everything about the business is in there:

```js
brand:        name, address, phone, WhatsApp, UPI ID, GSTIN, FSSAI, invoice prefix
booking:      slot length, min/max hours, cleanup buffer, hold timer, how far ahead
hours:        open/close per weekday, closed days
stationTypes: name, hourly rate, how many units, specs
pricingRules: peak hours, weekend surcharge, happy hour — these stack
menu:         categories and items with price, veg/non-veg, prep time
tax:          GST registered yes/no, food %, gaming %
refundPolicy: refund bands by hours before the session
coupons:      codes, type, caps
```

Change a value, save, refresh. Or change most of it live from **Admin → Settings** —
which is what your staff will use, since it needs no code at all.

**Going live for real:** Admin → Settings → **Wipe everything**. That clears the demo
data and leaves you an empty, correctly configured system.

---

## 4. What's actually built

**Accounts**
- Sign in with **mobile number or email** — no password, a one-time code either way
- 6-digit OTP with auto-advance boxes, paste support, resend, 5-attempt lockout, 10-minute expiry
- In this demo the code is shown on screen instead of being sent; production wires the same
  call to MSG91/Fast2SMS (DLT-registered) or email
- Profile with name, mobile, email, date of birth, marketing consent kept separate from terms
- Download-my-data and delete-my-account, with invoice-linked records anonymised rather than erased

**Respawn Rewards (loyalty)**
- Earn **5 points per ₹100** on food, **double on gaming time**
- Four tiers by lifetime spend — Bronze → Silver → Gold → Platinum — with **automatic 5/10/15% member discounts** and bonus earn rates
- Redeem from 100 points at ₹0.50 a point, **capped at 25% of any single bill** and re-checked server-side
- Signup, birthday and two-sided referral bonuses, each with a shareable referral code
- Append-only points ledger: every earn, redemption, reversal and manual adjustment, with running balance
- Cancelling a booking returns redeemed points and reverses the points it earned
- **Points are spendable in-café only** — never withdrawable as cash, by design
- Admin panel showing outstanding **points liability in rupees**, redemption rate, tier distribution,
  editable thresholds, and manual point adjustments with a reason that shows on the customer's history

**Customer side**
- Four-step booking wizard: station → date → time → pay
- Slot grid where sold-out is unmistakable — greyed, striped, price struck through,
  ✕ marker, `aria-disabled`, and never colour alone (colour-blind safe)
- All eight slot states: available, holding, sold out, in use, under repair, cleanup buffer, closed, past
- Group bookings (5 friends, 5 PCs) that are all-or-nothing — you never get split up
- Live session extension, which checks the *next* slot is free before agreeing
- Menu with veg/non-veg filters, cart, dine-in / takeaway / **deliver to my gaming station**
- My Bookings with check-in code, cancel-with-refund-shown-first, printable GST invoice
- Waitlist when everything's full
- Installable PWA, offline shell, dark UI, bottom tab bar on mobile

**Staff side**
- Dashboard: today's revenue split gaming/food, live occupancy, next arrivals, kitchen queue
- Live floor map — tap any station to block it for repairs
- Bookings: filter by date/status/search, check in/out, extend, no-show, cancel with refund
- Walk-in booking in about 15 seconds
- Kitchen Display: colour-codes by age (green → amber → red), tap to advance
- Counter POS: tap-to-bill, cash/UPI/card, check-in by code
- Menu manager: edit prices inline, one-tap "86 this item"
- Rates: edit hourly rates, plus a **price heatmap** showing what a customer actually pays each hour
- Customers CRM with lifetime spend, visits, no-show count
- Reports: daily revenue chart, **peak-hour heatmap**, top/slow sellers, station utilisation, GST summary
- Payments, refunds, manual-UPI verification queue, full audit log
- Backup / restore as JSON

**Excel export** — the part you specifically asked for
- Every list view exports the *currently filtered* rows
- A full 10-sheet workbook: Bookings · Food Orders · Daily Summary · Payments ·
  Station Utilisation · Menu Performance · Customers · GST Summary · Loyalty Members · Points Ledger
- Frozen header row, auto-filters, ₹ number format, sized columns
- Written by hand in ~200 lines of vanilla JS — **no library, works offline**

**Payments**
- UPI, card, **manual UPI QR + UTR** (staff verifies), and pay-at-counter
- Idempotency keys, so a replayed confirmation never double-charges
- Mock gateway by default. Razorpay needs a server — see the monorepo package

---

## 5. Tests

```bash
node tests/engine.test.js    # 67 tests — pricing, tax, refunds, slots, concurrency, loyalty, auth
node tests/ui.smoke.js       # 33 tests — every screen renders, workbook builds, no dark-on-light text
```

The one that matters most:

```
CONCURRENCY — 50 simultaneous bookings for one slot
  ✓ exactly one wins, 49 get SLOT_TAKEN, zero double-bookings
```

Double-booking is the failure that costs you a customer and an argument at the counter.
It's tested, not assumed.

The loyalty equivalent — points are money, so they get the same treatment:

```
  ✓ cannot redeem more than the cap, even if the client asks
  ✓ discount can never exceed the subtotal
  ✓ points balance never goes negative
  ✓ ledger balanceAfter always matches the running balance
  ✓ referral credits both sides, once only
  ✓ cancelling returns redeemed points and reverses earned ones
```

### Colour and contrast

This is a dark theme, so **no on-screen text is dark**. Accents appear as deepened fills,
tinted washes and borders rather than bright fills with near-black text on top. Every
text/background pair in the design system clears WCAG AA (4.5:1) — the tightest is 4.52:1.
Slot states use one colour per meaning, consistently, everywhere:

| Colour | Meaning |
|---|---|
| Green | Available |
| Cyan | Your selection |
| Red + stripes + strikethrough + ✕ | Sold out |
| Violet | Someone else is mid-checkout |
| Amber | In use right now |
| Grey | Under repair, closed, past, or cleanup buffer |

Sold-out is never signalled by colour alone — there's a stripe pattern, a struck-through
price, a ✕ and `aria-disabled` too, so it reads correctly for colour-blind users and screen
readers. Printing flips the whole theme to black-on-white via a print stylesheet, so
invoices don't burn a cartridge.

---

## 6. Honest limits of this package

| | |
|---|---|
| **Data lives in your browser** | `localStorage`, per device. Two phones don't see each other's bookings. Real multi-device needs the server build. |
| **No real payments** | Mock gateway. Razorpay's secret key can never sit in a browser — it needs a backend. |
| **No SMS / WhatsApp / push** | Those need paid providers and a server. |
| **No `.apk`** | Building an Android package needs the Android SDK, Gradle and a network install — not possible in the sandbox I built this in. The PWA install above gives you a home-screen app today; the monorepo package gives you the real APK path. |
| **Times are local strings** | Fine for one venue in one timezone. Production stores UTC `timestamptz`. |
| **OTP is shown on screen** | There's no SMS gateway in a local file. The login flow, rate limits and expiry are real; only the delivery is stubbed. |

None of these are hand-waves — each one is a specific thing the production build in the
monorepo package solves, and the business logic (slot engine, pricing, tax, refunds)
is written to port across unchanged.

---

## 7. India specifics already wired in

- **Two GST rates in one cart.** Food is 5% without input tax credit; gaming is 18% as a
  recreational service. Tax is computed **per line**, not per cart, with a rate-wise
  invoice breakup and CGST/SGST split. An unregistered mode issues plain bills with no tax.
- **Gapless invoice numbering** per financial year, with your prefix.
- **No money gaming.** No betting, staking, or cash prize pools anywhere, and loyalty
  credit can only be spent in the café. India's Promotion and Regulation of Online Gaming
  Act, 2025 bans online money games — skill or chance — so the product sells hardware
  time and food, which is the safe shape.
- Under-18 curfew setting, no-show grace period, cancellation bands.

Not legal advice — confirm your GST position with a CA and your licences with your
municipal corporation.

---

### Upgrading from the earlier build

If you already opened v1, your saved bookings are safe. The app runs a schema migration
(v1 → v2) that back-fills the loyalty tables, account fields and referral codes without
touching your data. It's covered by a test.

---

Built to the spec in `Gaming-Cafe-Build-Prompt.docx`, Sections 5–11 and 13–16.
