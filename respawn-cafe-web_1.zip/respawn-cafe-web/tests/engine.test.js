/* Zero-dependency test runner.  Run:  node tests/engine.test.js  */
const fs = require("fs");
const path = require("path");
const base = path.join(__dirname, "..", "assets");
eval(fs.readFileSync(path.join(base, "config.js"), "utf8"));
eval(fs.readFileSync(path.join(base, "engine.js"), "utf8"));
eval(fs.readFileSync(path.join(base, "store.js"), "utf8"));
eval(fs.readFileSync(path.join(base, "xlsx.js"), "utf8"));

const E = globalThis.Engine;
let pass = 0, fail = 0;
const t = (name, fn) => {
  try { fn(); console.log("  \x1b[32m✓\x1b[0m " + name); pass++; }
  catch (e) { console.log("  \x1b[31m✗\x1b[0m " + name + "\n      " + e.message); fail++; }
};
const eq = (a, b, m) => { if (JSON.stringify(a) !== JSON.stringify(b)) throw new Error(`${m || ""} expected ${JSON.stringify(b)}, got ${JSON.stringify(a)}`); };
const ok = (c, m) => { if (!c) throw new Error(m || "expected truthy"); };

const S = JSON.parse(JSON.stringify(globalThis.CONFIG));
S.hours = globalThis.CONFIG.hours; S.booking = globalThis.CONFIG.booking;

console.log("\nMONEY");
t("paise conversion never floats", () => {
  eq(E.toPaise(80), 8000);
  eq(E.toPaise(0.1) + E.toPaise(0.2), 30);       // the classic float trap
  eq(E.rupees(8000), 80);
});
t("formats in Indian style", () => { ok(E.fmt(12345600).includes("1,23,456")); });

console.log("\nSLOT GENERATION");
t("generates hourly slots inside opening hours", () => {
  const s = E.slotsForDate("2026-08-12", S);          // Wednesday 11:00–23:00
  eq(s.length, 12);
  eq(s[0].start, "2026-08-12T11:00");
  eq(s[s.length - 1].end, "2026-08-12T23:00");
});
t("respects 30-minute granularity", () => {
  const S30 = JSON.parse(JSON.stringify(S)); S30.booking.slotMinutes = 30;
  eq(E.slotsForDate("2026-08-12", S30).length, 24);
});
t("returns nothing on a closed day", () => {
  const SC = JSON.parse(JSON.stringify(S));
  SC.hours = SC.hours.map(h => h.day === 3 ? { ...h, closed: true } : h);
  eq(E.slotsForDate("2026-08-12", SC).length, 0);    // 2026-08-12 is a Wednesday
});

console.log("\nPRICING");
t("off-peak weekday PC = base rate", () => {
  const pc = S.stationTypes.find(x => x.id === "pc");
  eq(E.slotPricePaise(pc, "2026-08-12T16:00", S).paise, 8000);
});
t("happy hour discounts 30%", () => {
  const pc = S.stationTypes.find(x => x.id === "pc");
  const p = E.slotPricePaise(pc, "2026-08-12T13:00", S);
  eq(p.paise, 5600);
  ok(p.rules.includes("Happy Hour"));
});
t("evening peak adds 25%", () => {
  const pc = S.stationTypes.find(x => x.id === "pc");
  eq(E.slotPricePaise(pc, "2026-08-12T20:00", S).paise, 10000);
});
t("weekend evening stacks both surcharges", () => {
  const pc = S.stationTypes.find(x => x.id === "pc");
  // Saturday 2026-08-15, 20:00 → 80 × 1.15 (wknd, prio 5) × 1.25 (peak, prio 10)
  eq(E.slotPricePaise(pc, "2026-08-15T20:00", S).paise, 11500);
});
t("prices a 3-hour, 2-station booking", () => {
  const pc = S.stationTypes.find(x => x.id === "pc");
  const slots = [
    { start: "2026-08-12T16:00", end: "2026-08-12T17:00" },
    { start: "2026-08-12T17:00", end: "2026-08-12T18:00" },
    { start: "2026-08-12T18:00", end: "2026-08-12T19:00" },
  ];
  const r = E.priceBooking({ stationType: pc, slots, stationCount: 2, addonIds: ["ctrl"], settings: S });
  eq(r.gamingPaise, 8000 * 2 + 8000 * 2 + 10000 * 2);   // last slot is peak
  eq(r.addonPaise, 3000);
});

console.log("\nTAX (the mixed-cart case)");
t("gaming taxed 18%, food 5%, separately", () => {
  const r = E.computeTax(10000, 20000, S);
  eq(r.taxPaise, 1800 + 1000);
  eq(r.breakup.length, 2);
});
t("unregistered venue charges no tax", () => {
  const SU = JSON.parse(JSON.stringify(S)); SU.tax.registered = false;
  eq(E.computeTax(10000, 20000, SU).taxPaise, 0);
});
t("totals spread discount before tax and round to the rupee", () => {
  const r = E.totals({ gamingPaise: 20000, foodPaise: 10000, couponCode: "FIRST50", kind: "BOTH", settings: S });
  eq(r.discountPaise, 10000);                 // 50% of 300 capped at ₹100
  eq(r.totalPaise % 100, 0, "must round to whole rupees");
  ok(r.taxPaise > 0);
});
t("rejects a coupon below minimum spend", () => {
  const r = E.applyCoupon("FOOD30", 10000, "FOOD", S);
  eq(r.discountPaise, 0); ok(r.error);
});
t("rejects a food coupon on gaming", () => {
  ok(E.applyCoupon("FOOD30", 100000, "GAMING", S).error);
});

console.log("\nREFUNDS");
t("full refund more than 4 hours out", () => {
  eq(E.refundFor("2026-08-12T20:00", "2026-08-12T10:00", 50000, S).refundPaise, 50000);
});
t("half refund inside 1–4 hours", () => {
  eq(E.refundFor("2026-08-12T20:00", "2026-08-12T18:00", 50000, S).refundPaise, 25000);
});
t("no refund inside the last hour", () => {
  eq(E.refundFor("2026-08-12T20:00", "2026-08-12T19:30", 50000, S).refundPaise, 0);
});

console.log("\nVALIDATION");
t("blocks past start times", () => {
  ok(E.validateBooking({ startISO: "2026-08-12T10:00", hours: 2, settings: S, nowISO: "2026-08-12T12:00" }).length);
});
t("blocks over-long sessions", () => {
  ok(E.validateBooking({ startISO: "2026-08-12T12:00", hours: 9, settings: S, nowISO: "2026-08-12T09:00" }).length);
});
t("blocks sessions running past closing", () => {
  ok(E.validateBooking({ startISO: "2026-08-12T22:00", hours: 3, settings: S, nowISO: "2026-08-12T09:00" }).length);
});
t("blocks bookings beyond the advance window", () => {
  ok(E.validateBooking({ startISO: "2026-09-30T12:00", hours: 1, settings: S, nowISO: "2026-08-12T09:00" }).length);
});
t("accepts a valid booking", () => {
  eq(E.validateBooking({ startISO: "2026-08-12T16:00", hours: 2, settings: S, nowISO: "2026-08-12T09:00" }), []);
});

console.log("\nAVAILABILITY & SOLD-OUT STATES");
const mkWorld = () => {
  const stations = [
    { id: "PC-01", stationTypeId: "pc", status: "AVAILABLE" },
    { id: "PC-02", stationTypeId: "pc", status: "AVAILABLE" },
    { id: "PC-03", stationTypeId: "pc", status: "MAINTENANCE", maintenanceNote: "GPU swap" },
  ];
  return { stations, bookings: [], bookingStations: [] };
};
t("free grid is all AVAILABLE", () => {
  const w = mkWorld();
  const a = E.availability({ dateStr: "2026-08-12", stations: [w.stations[0]], stationTypes: S.stationTypes,
    bookings: [], bookingStations: [], settings: S, nowISO: "2026-08-12T09:00" });
  ok(a.grid["PC-01"].every(s => s.state === "AVAILABLE"));
});
t("a confirmed booking shows BOOKED", () => {
  const w = mkWorld();
  w.bookings.push({ id: "b1", code: "RC-1", status: "CONFIRMED" });
  w.bookingStations.push({ bookingId: "b1", stationId: "PC-01", startAt: "2026-08-12T16:00", endAt: "2026-08-12T18:00" });
  const a = E.availability({ dateStr: "2026-08-12", stations: w.stations, stationTypes: S.stationTypes,
    bookings: w.bookings, bookingStations: w.bookingStations, settings: S, nowISO: "2026-08-12T09:00" });
  const row = a.grid["PC-01"];
  eq(row.find(s => s.start === "2026-08-12T16:00").state, "BOOKED");
  eq(row.find(s => s.start === "2026-08-12T17:00").state, "BOOKED");
  eq(row.find(s => s.start === "2026-08-12T19:00").state, "AVAILABLE");
});
t("cleanup buffer blocks the following slot", () => {
  const w = mkWorld();
  w.bookings.push({ id: "b1", code: "RC-1", status: "CONFIRMED" });
  w.bookingStations.push({ bookingId: "b1", stationId: "PC-01", startAt: "2026-08-12T16:00", endAt: "2026-08-12T18:00" });
  const a = E.availability({ dateStr: "2026-08-12", stations: w.stations, stationTypes: S.stationTypes,
    bookings: w.bookings, bookingStations: w.bookingStations, settings: S, nowISO: "2026-08-12T09:00" });
  eq(a.grid["PC-01"].find(s => s.start === "2026-08-12T18:00").state, "BUFFER");
});
t("a HELD booking shows HELD, not BOOKED", () => {
  const w = mkWorld();
  w.bookings.push({ id: "b2", code: "RC-2", status: "HELD", holdExpiresAt: "2026-08-12T09:10" });
  w.bookingStations.push({ bookingId: "b2", stationId: "PC-01", startAt: "2026-08-12T16:00", endAt: "2026-08-12T17:00" });
  const a = E.availability({ dateStr: "2026-08-12", stations: w.stations, stationTypes: S.stationTypes,
    bookings: w.bookings, bookingStations: w.bookingStations, settings: S, nowISO: "2026-08-12T09:00" });
  eq(a.grid["PC-01"].find(s => s.start === "2026-08-12T16:00").state, "HELD");
});
t("a cancelled booking frees the slot", () => {
  const w = mkWorld();
  w.bookings.push({ id: "b3", code: "RC-3", status: "CANCELLED" });
  w.bookingStations.push({ bookingId: "b3", stationId: "PC-01", startAt: "2026-08-12T16:00", endAt: "2026-08-12T17:00" });
  const a = E.availability({ dateStr: "2026-08-12", stations: w.stations, stationTypes: S.stationTypes,
    bookings: w.bookings, bookingStations: w.bookingStations, settings: S, nowISO: "2026-08-12T09:00" });
  eq(a.grid["PC-01"].find(s => s.start === "2026-08-12T16:00").state, "AVAILABLE");
});
t("maintenance station is unbookable all day", () => {
  const w = mkWorld();
  const a = E.availability({ dateStr: "2026-08-12", stations: w.stations, stationTypes: S.stationTypes,
    bookings: [], bookingStations: [], settings: S, nowISO: "2026-08-12T09:00" });
  ok(a.grid["PC-03"].every(s => s.state === "MAINTENANCE"));
});
t("past slots are PAST", () => {
  const w = mkWorld();
  const a = E.availability({ dateStr: "2026-08-12", stations: [w.stations[0]], stationTypes: S.stationTypes,
    bookings: [], bookingStations: [], settings: S, nowISO: "2026-08-12T15:00" });
  eq(a.grid["PC-01"].find(s => s.start === "2026-08-12T11:00").state, "PAST");
  eq(a.grid["PC-01"].find(s => s.start === "2026-08-12T16:00").state, "AVAILABLE");
});
t("group booking finds only stations free for the whole block", () => {
  const w = mkWorld();
  w.bookings.push({ id: "b1", status: "CONFIRMED" });
  w.bookingStations.push({ bookingId: "b1", stationId: "PC-01", startAt: "2026-08-12T17:00", endAt: "2026-08-12T18:00" });
  const free = E.freeStationsFor({ stationTypeId: "pc", startISO: "2026-08-12T16:00", hours: 3,
    stations: w.stations, bookingStations: w.bookingStations, bookings: w.bookings, settings: S });
  eq(free.map(s => s.id), ["PC-02"]);   // PC-01 busy, PC-03 in maintenance
});

console.log("\nCONCURRENCY — 50 simultaneous bookings for one slot");
t("exactly one wins, 49 get SLOT_TAKEN, zero double-bookings", () => {
  const db = Store.freshTestDb();
  const station = db.stations.find(s => s.stationTypeId === "pc");
  const start = Store.nextOpenSlot(db, 3);
  const results = [];
  for (let i = 0; i < 50; i++) {
    results.push(Store.holdBooking(db, {
      stationTypeId: "pc", stationCount: 1, startISO: start, hours: 1,
      forceStationId: station.id, name: "Racer " + i, phone: "99999000" + i,
    }));
  }
  const wins = results.filter(r => r.ok);
  const taken = results.filter(r => !r.ok && r.code === "SLOT_TAKEN");
  eq(wins.length, 1, "winners");
  eq(taken.length, 49, "rejections");
  ok(results.every(r => r.ok || r.code === "SLOT_TAKEN"), "no unexpected error codes");
  const rows = db.bookingStations.filter(bs => bs.stationId === station.id && bs.startAt === start);
  const blocking = rows.filter(bs => E.BLOCKING.includes(db.bookings.find(b => b.id === bs.bookingId).status));
  eq(blocking.length, 1, "blocking rows in DB");
});
t("expired holds release the slot", () => {
  const db = Store.freshTestDb();
  const start = Store.nextOpenSlot(db, 3);
  const r1 = Store.holdBooking(db, { stationTypeId: "pc", stationCount: 1, startISO: start, hours: 1, name: "A", phone: "1" });
  ok(r1.ok);
  const bk = db.bookings.find(b => b.id === r1.bookingId);
  bk.holdExpiresAt = E.addMin(E.localISO(new Date()), -1);   // pretend the clock ran out
  Store.expireHolds(db);
  eq(db.bookings.find(b => b.id === r1.bookingId).status, "EXPIRED");
  const r2 = Store.holdBooking(db, { stationTypeId: "pc", stationCount: 1, startISO: start, hours: 1, name: "B", phone: "2" });
  ok(r2.ok, "slot should be bookable again");
});
t("payment idempotency: replaying a confirm changes nothing", () => {
  const db = Store.freshTestDb();
  const start = Store.nextOpenSlot(db, 3);
  const r = Store.holdBooking(db, { stationTypeId: "pc", stationCount: 1, startISO: start, hours: 1, name: "A", phone: "1" });
  const key = "idem-abc-123";
  const a = Store.confirmPayment(db, r.bookingId, { method: "UPI", idempotencyKey: key });
  const b = Store.confirmPayment(db, r.bookingId, { method: "UPI", idempotencyKey: key });
  eq(a.paymentId, b.paymentId, "same payment id");
  eq(db.payments.filter(p => p.idempotencyKey === key).length, 1, "one payment row");
  eq(db.bookings.find(x => x.id === r.bookingId).status, "CONFIRMED");
});
t("group booking of 5 PCs is all-or-nothing", () => {
  const db = Store.freshTestDb();
  const start = Store.nextOpenSlot(db, 3);
  const r = Store.holdBooking(db, { stationTypeId: "pc", stationCount: 5, startISO: start, hours: 2, name: "Squad", phone: "5" });
  ok(r.ok);
  eq(db.bookingStations.filter(bs => bs.bookingId === r.bookingId).length, 5);
  const tooMany = Store.holdBooking(db, { stationTypeId: "pc", stationCount: 5, startISO: start, hours: 2, name: "Squad2", phone: "6" });
  eq(tooMany.ok, false); eq(tooMany.code, "SLOT_TAKEN");
  eq(db.bookingStations.filter(bs => bs.bookingId === tooMany.bookingId || false).length, 0, "no partial rows left behind");
});

console.log("\nEXCEL EXPORT");
t("builds a valid xlsx byte stream", () => {
  const bytes = XlsxWriter.build([{ name: "Bookings", rows: [["Code", "Total"], ["RC-1", 800]] }]);
  ok(bytes.length > 500, "non-trivial file");
  eq([bytes[0], bytes[1]], [0x50, 0x4b], "PK zip magic bytes");
});


console.log("\nLOYALTY — tiers");
t("tier is derived from lifetime spend", () => {
  eq(E.tierFor(0, S).tier.id, "bronze");
  eq(E.tierFor(E.toPaise(3000), S).tier.id, "silver");
  eq(E.tierFor(E.toPaise(10000), S).tier.id, "gold");
  eq(E.tierFor(E.toPaise(99999), S).tier.id, "platinum");
});
t("progress and distance to the next tier are correct", () => {
  const r = E.tierFor(E.toPaise(6500), S);          // halfway bronze→gold band
  eq(r.tier.id, "silver"); eq(r.next.id, "gold");
  eq(r.toNextPaise, E.toPaise(3500));
  ok(r.progress > 49 && r.progress < 51, "progress ~50%, got " + r.progress);
});
t("top tier reports no next tier and 100% progress", () => {
  const r = E.tierFor(E.toPaise(50000), S);
  eq(r.next, null); eq(r.progress, 100); eq(r.toNextPaise, 0);
});

console.log("\nLOYALTY — earning");
t("gaming earns double what food earns", () => {
  const g = E.pointsEarned({ gamingPaise: E.toPaise(1000), settings: S });
  const f = E.pointsEarned({ foodPaise: E.toPaise(1000), settings: S });
  eq(g.points, 100);      // ₹1000 × 5/100 × 2
  eq(f.points, 50);
});
t("tier bonus is added on top", () => {
  const gold = S.loyalty.tiers.find(x => x.id === "gold");
  const r = E.pointsEarned({ gamingPaise: E.toPaise(1000), tier: gold, settings: S });
  eq(r.base, 100); eq(r.bonus, 25); eq(r.points, 125);
});
t("earning nothing on a zero bill", () => { eq(E.pointsEarned({ settings: S }).points, 0); });
t("disabled programme earns nothing", () => {
  const SD = JSON.parse(JSON.stringify(S)); SD.loyalty.enabled = false;
  eq(E.pointsEarned({ gamingPaise: E.toPaise(5000), settings: SD }).points, 0);
});

console.log("\nLOYALTY — redemption limits");
t("100 points is worth ₹50", () => { eq(E.redeemValuePaise(100, S), E.toPaise(50)); });
t("cannot redeem below the minimum balance", () => {
  const r = E.maxRedeemable(50, E.toPaise(1000), S);
  eq(r.points, 0); ok(r.reason);
});
t("redemption is capped at 25% of the bill, not the balance", () => {
  // ₹1000 bill → 25% = ₹250 → at ₹0.50/pt that's 500 points, even with 5000 banked
  const r = E.maxRedeemable(5000, E.toPaise(1000), S);
  eq(r.points, 500); eq(r.valuePaise, E.toPaise(250));
});
t("redemption is capped at the balance when the balance is lower", () => {
  eq(E.maxRedeemable(120, E.toPaise(10000), S).points, 120);
});

console.log("\nLOYALTY — totals stacking");
t("member discount stacks after the coupon, then points", () => {
  const r = E.totals({ gamingPaise: E.toPaise(1000), couponCode: "WEEKDAY20", kind: "GAMING",
                       memberPercent: 10, redeemPoints: 100, settings: S });
  eq(r.couponPaise, E.toPaise(150));                       // 20% of 1000, capped at ₹150
  eq(r.memberPaise, E.toPaise(85));                        // 10% of (1000 − 150)
  eq(r.pointsPaise, E.toPaise(50));                        // 100 pts
  eq(r.discountPaise, E.toPaise(285));
  ok(r.taxPaise > 0, "tax still charged on the reduced value");
  eq(r.totalPaise % 100, 0);
});
t("discount can never exceed the subtotal", () => {
  const r = E.totals({ gamingPaise: E.toPaise(100), memberPercent: 15, redeemPoints: 10000, settings: S });
  ok(r.discountPaise <= r.subtotalPaise, "discount " + r.discountPaise + " > subtotal " + r.subtotalPaise);
  ok(r.totalPaise >= 0, "total went negative");
});

console.log("\nACCOUNTS — login");
t("rejects a bad phone number", () => {
  const db = Store.freshTestDb();
  ok(!Store.startLogin(db, "12345").ok);
});
t("rejects a malformed email", () => {
  const db = Store.freshTestDb();
  ok(!Store.startLogin(db, "notanemail@").ok);
});
t("phone login issues a 6-digit code and signs the user in", () => {
  const db = Store.freshTestDb();
  const r = Store.startLogin(db, "9830012345");
  ok(r.ok); eq(r.code.length, 6);
  const v = Store.verifyLogin(db, r.code, "Arnab Sen");
  ok(v.ok); eq(db.session.userId, v.customer.id);
  eq(v.customer.phone, "9830012345");
});
t("email login works the same way", () => {
  const db = Store.freshTestDb();
  const r = Store.startLogin(db, "Arnab@Example.COM");
  ok(r.ok); ok(r.isEmail);
  eq(r.identifier, "arnab@example.com", "email should be normalised");
  ok(Store.verifyLogin(db, r.code, "Arnab").ok);
});
t("wrong code is rejected and attempts are limited", () => {
  const db = Store.freshTestDb();
  Store.startLogin(db, "9830012345");
  for (let i = 0; i < 5; i++) ok(!Store.verifyLogin(db, "000000").ok);
  const last = Store.verifyLogin(db, "000000");
  ok(!last.ok); ok(/Too many/.test(last.error), "should lock out: " + last.error);
});
t("expired code is rejected", () => {
  const db = Store.freshTestDb();
  const r = Store.startLogin(db, "9830012345");
  db.otp.expiresAt = E.addMin(E.localISO(new Date()), -1);
  ok(!Store.verifyLogin(db, r.code).ok);
});
t("signing in twice returns the same account, not a duplicate", () => {
  const db = Store.freshTestDb();
  const a = Store.startLogin(db, "9830012345"); const va = Store.verifyLogin(db, a.code, "Arnab");
  Store.logout(db);
  const b = Store.startLogin(db, "9830012345"); const vb = Store.verifyLogin(db, b.code);
  eq(va.customer.id, vb.customer.id);
  eq(db.customers.filter(c => c.phone === "9830012345").length, 1);
});
t("new account gets the signup bonus once", () => {
  const db = Store.freshTestDb();
  const r = Store.startLogin(db, "9830012345");
  const v = Store.verifyLogin(db, r.code, "Arnab");
  eq(v.customer.points, S.loyalty.signupBonus);
  eq(db.loyalty.filter(x => x.customerId === v.customer.id && x.delta > 0).length, 1);
});

console.log("\nACCOUNTS — points lifecycle");
const login = (db, phone, name) => {
  const r = Store.startLogin(db, phone);
  return Store.verifyLogin(db, r.code, name).customer;
};
t("a paid booking credits points and logs a ledger row", () => {
  const db = Store.freshTestDb();
  const c = login(db, "9830012345", "Arnab");
  const before = c.points;
  const start = Store.nextOpenSlot(db, 3);
  const h = Store.holdBooking(db, { stationTypeId: "pc", stationCount: 1, startISO: start, hours: 2, customerId: c.id });
  ok(h.ok);
  Store.confirmPayment(db, h.bookingId, { method: "UPI", idempotencyKey: "k1" });
  const b = db.bookings.find(x => x.id === h.bookingId);
  ok(b.pointsEarned > 0, "no points earned");
  eq(c.points, before + b.pointsEarned);
  ok(db.loyalty.some(r => r.refId === b.id && r.delta === b.pointsEarned));
});
t("redeemed points are deducted at hold time", () => {
  const db = Store.freshTestDb();
  const c = login(db, "9830012345", "Arnab");
  Store.addPoints(db, c.id, 4000, "test top-up", null);
  const bal = c.points;
  const start = Store.nextOpenSlot(db, 3);
  // VR at ₹300/hr × 4h gives a bill big enough that 200 points sits under the 25% cap
  const h = Store.holdBooking(db, { stationTypeId: "vr", stationCount: 1, startISO: start, hours: 4, customerId: c.id, redeemPoints: 200 });
  ok(h.ok, (h.errors || []).join(" "));
  const b = db.bookings.find(x => x.id === h.bookingId);
  eq(b.redeemPoints, 200, "200 pts should fit under the cap on a large bill");
  eq(c.points, bal - 200);
  eq(b.pointsPaise, E.toPaise(100), "200 pts = ₹100 off");
});
t("cannot redeem more than the cap, even if the client asks", () => {
  const db = Store.freshTestDb();
  const c = login(db, "9830012345", "Arnab");
  Store.addPoints(db, c.id, 100000, "huge balance", null);
  const start = Store.nextOpenSlot(db, 3);
  // 1 hour PC ≈ ₹80–115; 25% cap is tiny, so a 90,000-point request must be clamped
  const h = Store.holdBooking(db, { stationTypeId: "pc", stationCount: 1, startISO: start, hours: 1, customerId: c.id, redeemPoints: 90000 });
  ok(h.ok);
  const b = db.bookings.find(x => x.id === h.bookingId);
  ok(b.redeemPoints < 90000, "server accepted an over-cap redemption: " + b.redeemPoints);
  ok(b.pointsPaise <= Math.ceil(b.subtotalPaise * 0.25) + 1, "redemption exceeded 25% of the bill");
  ok(b.totalPaise > 0, "bill was wiped to zero by points");
});
t("cancelling returns redeemed points and reverses earned ones", () => {
  const db = Store.freshTestDb();
  const c = login(db, "9830012345", "Arnab");
  Store.addPoints(db, c.id, 4000, "top-up", null);
  const start = Store.nextOpenSlot(db, 6);
  const h = Store.holdBooking(db, { stationTypeId: "vr", stationCount: 1, startISO: start, hours: 4, customerId: c.id, redeemPoints: 200 });
  Store.confirmPayment(db, h.bookingId, { method: "UPI", idempotencyKey: "k2" });
  const b = db.bookings.find(x => x.id === h.bookingId);
  ok(b.redeemPoints > 0 && b.pointsEarned > 0, "need both a redemption and an award to test the unwind");
  const afterPay = c.points;
  Store.cancelBooking(db, b.id, "test");
  eq(c.points, afterPay + b.redeemPoints - b.pointsEarned, "points not correctly unwound");
  // and the ledger records both moves, so the history is auditable
  ok(db.loyalty.some(r => r.refId === b.id && r.delta === b.redeemPoints), "no refund row");
  ok(db.loyalty.some(r => r.refId === b.id && r.delta === -b.pointsEarned), "no reversal row");
});
t("a member's tier discount is applied automatically", () => {
  const db = Store.freshTestDb();
  const c = login(db, "9830012345", "Arnab");
  c.spendPaise = E.toPaise(30000);                    // platinum
  const start = Store.nextOpenSlot(db, 3);
  const h = Store.holdBooking(db, { stationTypeId: "pc", stationCount: 1, startISO: start, hours: 2, customerId: c.id });
  const b = db.bookings.find(x => x.id === h.bookingId);
  eq(b.memberPercent, 15);
  ok(b.memberPaise > 0, "no member discount applied");
});
t("referral credits both sides, once only", () => {
  const db = Store.freshTestDb();
  const a = login(db, "9830011111", "Arnab"); Store.logout(db);
  const bq = login(db, "9830022222", "Bina");
  const r = Store.applyReferral(db, bq.id, a.referralCode);
  ok(r.ok);
  eq(bq.points, S.loyalty.signupBonus + S.loyalty.referralBonus);
  eq(a.points, S.loyalty.signupBonus + S.loyalty.referralBonus);
  ok(!Store.applyReferral(db, bq.id, a.referralCode).ok, "referral should not be reusable");
});
t("you cannot refer yourself", () => {
  const db = Store.freshTestDb();
  const a = login(db, "9830011111", "Arnab");
  ok(!Store.applyReferral(db, a.id, a.referralCode).ok);
});
t("points balance never goes negative", () => {
  const db = Store.freshTestDb();
  const c = login(db, "9830012345", "Arnab");
  Store.addPoints(db, c.id, -99999, "over-deduct", null);
  eq(c.points, 0);
});
t("ledger balanceAfter always matches the running balance", () => {
  const db = Store.freshTestDb();
  const c = login(db, "9830012345", "Arnab");
  Store.addPoints(db, c.id, 300, "a", null);
  Store.addPoints(db, c.id, -120, "b", null);
  Store.addPoints(db, c.id, 40, "c", null);
  const rows = db.loyalty.filter(r => r.customerId === c.id);
  eq(rows[rows.length - 1].balanceAfter, c.points);
  let run = 0;
  for (const r of rows) { run = Math.max(0, run + r.delta); eq(r.balanceAfter, run, "row " + r.reason); }
});

console.log("\nMIGRATION");
t("a v1 database upgrades to v2 without losing bookings", () => {
  const db = Store.freshTestDb();
  const start = Store.nextOpenSlot(db, 3);
  Store.holdBooking(db, { stationTypeId: "pc", stationCount: 1, startISO: start, hours: 1, name: "A", phone: "9800000001" });
  // pretend this came from the previous release
  db.version = 1; delete db.settings.loyalty; delete db.settings.auth; delete db.loyalty;
  db.customers.forEach(c => { delete c.points; delete c.referralCode; });
  const n = db.bookings.length;
  Store.migrate(db, globalThis.CONFIG);
  eq(db.version, 2);
  eq(db.bookings.length, n, "bookings lost during migration");
  ok(db.settings.loyalty && db.settings.auth, "settings not restored");
  ok(Array.isArray(db.loyalty), "ledger not created");
  ok(db.customers.every(c => c.points === 0 && c.referralCode), "customers not upgraded");
});

console.log(`\n${pass} passed, ${fail} failed\n`);
process.exit(fail ? 1 : 0);
