/* Headless smoke test: stubs just enough DOM to load and drive the real UI
   files, so a broken render() is caught here instead of in your browser.
   Run:  node tests/ui.smoke.js                                          */
const fs = require("fs");
const A = require("path").join(__dirname, "..", "assets");

// ---------- minimal DOM ----------
let idSeq = 0;
class El {
  constructor(tag) {
    this.tagName = (tag || "div").toUpperCase(); this.children = []; this.attrs = {};
    this._html = ""; this.style = {}; this.dataset = {}; this.classList = {
      _s: new Set(),
      add: (...c) => c.forEach((x) => this.classList._s.add(x)),
      remove: (...c) => c.forEach((x) => this.classList._s.delete(x)),
      toggle: (c, on) => on ? this.classList._s.add(c) : this.classList._s.delete(c),
      contains: (c) => this.classList._s.has(c),
    };
    this._id = ++idSeq; this.value = ""; this.checked = false; this.type = "text";
  }
  get className() { return [...this.classList._s].join(" "); }
  set className(v) { this.classList._s = new Set(String(v).split(/\s+/).filter(Boolean)); }
  set innerHTML(v) { this._html = String(v); parseInto(this, this._html); }
  get innerHTML() { return this._html; }
  set textContent(v) { this._html = String(v); }
  get textContent() { return this._html; }
  appendChild(c) { this.children.push(c); c.parentNode = this; return c; }
  removeChild(c) { this.children = this.children.filter((x) => x !== c); }
  remove() { if (this.parentNode) this.parentNode.removeChild(this); }
  setAttribute(k, v) { this.attrs[k] = v; }
  getAttribute(k) { return this.attrs[k]; }
  addEventListener() {}
  focus() {} blur() {} click() { this.onclick && this.onclick({ target: this }); }
  setSelectionRange() {}
  querySelector(s) { return q(this, s)[0] || null; }
  querySelectorAll(s) { return q(this, s); }
  get files() { return []; }
}
// crude HTML → element tree, capturing id / class / data-* so selectors work
function parseInto(root, html) {
  root.children = [];
  const re = /<([a-zA-Z][a-zA-Z0-9]*)((?:\s+[^>]*?)?)\/?>/g;
  let m;
  while ((m = re.exec(html))) {
    const el = new El(m[1]);
    const attrs = m[2] || "";
    const ar = /([a-zA-Z_:][-a-zA-Z0-9_:.]*)\s*=\s*"([^"]*)"/g;
    let a;
    while ((a = ar.exec(attrs))) {
      const [, k, v] = a;
      if (k === "id") el.id = v;
      else if (k === "class") el.className = v;
      else if (k.startsWith("data-")) el.dataset[k.slice(5).replace(/-([a-z])/g, (_, c) => c.toUpperCase())] = v;
      else if (k === "value") el.value = v;
      else if (k === "type") el.type = v;
      else el.setAttribute(k, v);
      if (/\bchecked\b/.test(attrs)) el.checked = true;
    }
    el.parentNode = root;
    root.children.push(el);
  }
}
function walk(root, out = []) { for (const c of root.children) { out.push(c); walk(c, out); } return out; }
function q(root, sel) {
  const all = walk(root);
  return sel.split(",").map((s) => s.trim()).flatMap((s) => {
    if (s.startsWith("#")) return all.filter((e) => e.id === s.slice(1));
    if (s.startsWith("[")) {
      const mm = s.match(/^\[([^\]=]+)(?:=["']?([^\]"']*)["']?)?\]$/);
      if (!mm) return [];
      const key = mm[1].startsWith("data-") ? mm[1].slice(5).replace(/-([a-z])/g, (_, c) => c.toUpperCase()) : mm[1];
      return all.filter((e) => (mm[1].startsWith("data-") ? e.dataset[key] !== undefined && (mm[2] === undefined || e.dataset[key] === mm[2]) : e.attrs[mm[1]] !== undefined));
    }
    if (s.startsWith(".")) return all.filter((e) => e.classList.contains(s.slice(1)));
    return all.filter((e) => e.tagName === s.toUpperCase());
  });
}

const doc = new El("body");
doc.body = doc;
doc.createElement = (t) => new El(t);
doc.addEventListener = () => {};
const store = {};
globalThis.localStorage = {
  getItem: (k) => (k in store ? store[k] : null),
  setItem: (k, v) => (store[k] = String(v)),
  removeItem: (k) => delete store[k],
};
globalThis.document = doc;
globalThis.window = globalThis;
globalThis.location = { hash: "#home", protocol: "http:", reload: () => {} };
globalThis.setInterval = () => 0;
globalThis.setTimeout = (f) => { try { typeof f === "function" && f(); } catch (e) {} return 0; };
globalThis.clearTimeout = () => {};
globalThis.addEventListener = () => {};
globalThis.scrollTo = () => {};
globalThis.matchMedia = () => ({ matches: false, addEventListener(){} });
globalThis.confirm = () => true;
globalThis.alert = () => {};
globalThis.Blob = class { constructor(p) { this.parts = p; } };
globalThis.URL = { createObjectURL: () => "blob:x", revokeObjectURL: () => {} };
globalThis.navigator = { serviceWorker: undefined };
globalThis.FileReader = class { readAsText() {} };
globalThis.TextEncoder = require("util").TextEncoder;

// containers the apps expect
const app = new El("div"); app.id = "app"; doc.appendChild(app);
const toasts = new El("div"); toasts.id = "toasts"; doc.appendChild(toasts);
const cartbar = new El("div"); cartbar.id = "cartbar"; doc.appendChild(cartbar);
const side = new El("aside"); side.id = "side"; doc.appendChild(side);
const main = new El("main"); main.id = "main"; doc.appendChild(main);

let pass = 0, fail = 0;
const t = (name, fn) => {
  try { fn(); console.log("  \x1b[32m✓\x1b[0m " + name); pass++; }
  catch (e) { console.log("  \x1b[31m✗\x1b[0m " + name + "\n      " + (e.stack || e.message).split("\n").slice(0, 3).join("\n      ")); fail++; }
};

eval(fs.readFileSync(A + "/config.js", "utf8"));
eval(fs.readFileSync(A + "/engine.js", "utf8"));
eval(fs.readFileSync(A + "/store.js", "utf8"));
eval(fs.readFileSync(A + "/xlsx.js", "utf8"));

console.log("\nCUSTOMER APP");
t("boots and renders home without throwing", () => {
  eval(fs.readFileSync(A + "/app.js", "utf8"));
  if (!app.innerHTML.length) throw new Error("#app is empty after boot");
  if (!/Respawn|Book a station/.test(app.innerHTML)) throw new Error("home content missing");
});
const views = ["book", "menu", "mine", "login", "rewards", "profile", "info", "home"];
for (const v of views) {
  t(`renders #${v}`, () => {
    globalThis.location.hash = "#" + v;
    // app.js listens on hashchange via window.addEventListener, which our stub
    // swallows, so drive it the same way a click would: re-dispatch by reload.
    const before = app.innerHTML;
    eval(fs.readFileSync(A + "/app.js", "utf8"));
    if (!app.innerHTML.length) throw new Error("empty render for " + v);
  });
}
t("booking wizard steps render for every station type", () => {
  for (const st of CONFIG.stationTypes) {
    globalThis.location.hash = "#book";
    eval(fs.readFileSync(A + "/app.js", "utf8"));
    const btn = app.querySelectorAll("[data-type]").find((b) => b.dataset.type === st.id);
    if (!btn) throw new Error("no selector button for " + st.id);
  }
});
t("seeded demo data is substantial", () => {
  const db = Store.load(CONFIG);
  if (db.bookings.length < 100) throw new Error("only " + db.bookings.length + " bookings seeded");
  if (db.orders.length < 100) throw new Error("only " + db.orders.length + " orders seeded");
  if (db.menuItems.length < 20) throw new Error("menu too small");
  if (db.customers.length < 20) throw new Error("too few customers");
  console.log(`      → ${db.bookings.length} bookings, ${db.orders.length} orders, ${db.menuItems.length} menu items, ${db.customers.length} customers`);
});
t("some future slots are genuinely sold out (so the state is visible)", () => {
  const db = Store.load(CONFIG);
  const n = Engine.localISO(new Date());
  const future = db.bookingStations.filter((r) => r.startAt > n);
  if (future.length < 10) throw new Error("not enough future bookings to demo sold-out");
  console.log(`      → ${future.length} future station-slots already taken`);
});

console.log("\nADMIN CONSOLE");
const adminViews = ["dash", "floor", "bookings", "orders", "kds", "pos", "menu", "stations", "customers", "loyalty", "reports", "payments", "audit", "settings"];
for (const v of adminViews) {
  t(`renders /admin #${v}`, () => {
    globalThis.location.hash = "#" + v;
    eval(fs.readFileSync(A + "/admin.js", "utf8"));
    if (!main.innerHTML.length) throw new Error("empty render");
    if (/undefined/.test(main.innerHTML.replace(/data-[a-z]+="undefined"/g, ""))) {
      const i = main.innerHTML.indexOf("undefined");
      throw new Error("literal 'undefined' leaked into output near: " + main.innerHTML.slice(Math.max(0, i - 70), i + 40));
    }
  });
}
t("sidebar navigation renders every section", () => {
  globalThis.location.hash = "#dash";
  eval(fs.readFileSync(A + "/admin.js", "utf8"));
  const links = side.querySelectorAll("a").length;
  if (links < 14) throw new Error("only " + links + " nav links");
});


console.log("\nACCOUNTS & LOYALTY UI");
t("login screen offers both phone and email", () => {
  const db = Store.load(CONFIG);
  Store.logout(db); Store.save(db);
  globalThis.location.hash = "#login";
  eval(fs.readFileSync(A + "/app.js", "utf8"));
  const modes = app.querySelectorAll("[data-lmode]").map((b) => b.dataset.lmode);
  if (!modes.includes("phone") || !modes.includes("email"))
    throw new Error("missing login modes: " + modes.join(","));
  if (!app.querySelectorAll("[data-sendotp]").length) throw new Error("no send-code button");
});
t("signed-out visitors are pushed to sign in, not shown a stub", () => {
  const db = Store.load(CONFIG); Store.logout(db); Store.save(db);
  globalThis.location.hash = "#mine";
  eval(fs.readFileSync(A + "/app.js", "utf8"));
  if (!/Sign in/i.test(app.innerHTML)) throw new Error("no sign-in prompt on #mine");
});
t("rewards page renders a tier, balance and ledger for a signed-in member", () => {
  const db = Store.load(CONFIG);
  const c = db.customers.sort((a, b) => b.spendPaise - a.spendPaise)[0];
  db.session = { role: "CUSTOMER", userId: c.id, name: c.name, phone: c.phone };
  Store.save(db);
  globalThis.location.hash = "#rewards";
  eval(fs.readFileSync(A + "/app.js", "utf8"));
  const h = app.innerHTML;
  for (const need of ["loyaltycard", "tierpill", "refcode", "Points history"])
    if (!h.includes(need)) throw new Error("rewards page missing " + need);
  const m = Store.memberInfo(db, c.id);
  console.log(`      → ${c.name}: ${m.tier.name}, ${m.points} pts, spend ${Engine.fmt(c.spendPaise)}`);
});
t("demo seed spreads members across more than one tier", () => {
  const db = Store.load(CONFIG);
  const tiers = new Set(db.customers.map((c) => Engine.tierFor(c.spendPaise || 0, db.settings).tier.id));
  if (tiers.size < 3) throw new Error("only " + tiers.size + " tier(s) present: " + [...tiers].join(","));
  console.log(`      → tiers present: ${[...tiers].join(", ")}`);
});
t("no dark-on-light text leaks into rendered markup", () => {
  const db = Store.load(CONFIG);
  const offenders = [];
  for (const view of ["home", "book", "menu", "mine", "rewards", "profile", "login", "info"]) {
    globalThis.location.hash = "#" + view;
    eval(fs.readFileSync(A + "/app.js", "utf8"));
    const h = app.innerHTML;
    for (const bad of ["background:#fff", "color:#000", "color:#111", "color:#03161b", "color:#241500"])
      if (h.includes(bad)) offenders.push(`${view} → ${bad}`);
  }
  for (const view of ["dash", "reports", "stations", "loyalty"]) {
    globalThis.location.hash = "#" + view;
    eval(fs.readFileSync(A + "/admin.js", "utf8"));
    const h = main.innerHTML;
    for (const bad of ["background:#fff", "color:#000", "color:#111", "color:#03161b"])
      if (h.includes(bad)) offenders.push(`admin/${view} → ${bad}`);
  }
  if (offenders.length) throw new Error(offenders.join("; "));
});

console.log("\nEXCEL WORKBOOK");
t("full workbook builds with all 8 sheets and real rows", () => {
  const db = Store.load(CONFIG);
  // rebuild the sheet set the same way admin.js does, via a download shim
  let captured = null;
  const realDl = XlsxWriter.download;
  XlsxWriter.download = (name, sheets) => { captured = { name, sheets }; };
  globalThis.location.hash = "#reports";
  eval(fs.readFileSync(A + "/admin.js", "utf8"));
  const btn = main.querySelectorAll("[data-xls]").find((b) => b.dataset.xls === "workbook");
  if (!btn) throw new Error("no workbook export button");
  btn.onclick();
  XlsxWriter.download = realDl;
  if (!captured) throw new Error("export did not fire");
  if (captured.sheets.length !== 10) throw new Error("expected 10 sheets, got " + captured.sheets.length);
  for (const s of captured.sheets) {
    if (!s.rows || s.rows.length < 2) throw new Error(`sheet "${s.name}" has no data rows`);
  }
  const bytes = XlsxWriter.build(captured.sheets);
  if (bytes[0] !== 0x50 || bytes[1] !== 0x4b) throw new Error("not a zip");
  fs.writeFileSync("/tmp/workbook.xlsx", Buffer.from(bytes));
  console.log(`      → ${captured.name}, ${captured.sheets.length} sheets, ${(bytes.length / 1024).toFixed(0)} KB`);
  captured.sheets.forEach((s) => console.log(`         · ${s.name}: ${s.rows.length - 1} rows`));
});

console.log(`\n${pass} passed, ${fail} failed\n`);
process.exit(fail ? 1 : 0);
