/* Offline shell: cache-first for app files, so the menu and your bookings
   still open with no signal. Bump CACHE when you change any asset. */
const CACHE = "respawn-v2";
const ASSETS = [
  "index.html", "admin.html", "manifest.webmanifest",
  "assets/styles.css", "assets/config.js", "assets/engine.js",
  "assets/store.js", "assets/xlsx.js", "assets/app.js", "assets/admin.js",
  "assets/icon-192.png", "assets/icon-512.png"
];
self.addEventListener("install", (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(ASSETS)).then(() => self.skipWaiting()));
});
self.addEventListener("activate", (e) => {
  e.waitUntil(caches.keys().then((ks) => Promise.all(ks.filter((k) => k !== CACHE).map((k) => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener("fetch", (e) => {
  if (e.request.method !== "GET") return;
  e.respondWith(
    caches.match(e.request).then((hit) => hit || fetch(e.request).then((res) => {
      const copy = res.clone();
      caches.open(CACHE).then((c) => c.put(e.request, copy)).catch(() => {});
      return res;
    }).catch(() => caches.match("index.html")))
  );
});
